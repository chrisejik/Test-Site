
import React, { createContext, useContext, useState, useEffect } from 'react';

// Static Data for the website
const initialArticles = [
  {
    id: '1',
    slug: 'pharmaceutical-expansion',
    title: "Chris-Ejik Group Expands Pharmaceutical Operations",
    date: "January 10, 2024",
    category: "News",
    image: "https://images.unsplash.com/photo-1585435557343-3b092031a831?w=800&h=600&fit=crop",
    author: "Corporate Communications",
    excerpt: "New manufacturing facility to increase production capacity by 200% and create over 500 jobs.",
    content: "<p>In a major move to bolster healthcare accessibility across West Africa, Chris-Ejik Group has announced a significant expansion of its pharmaceutical manufacturing division. The new facility, located in Ogun State, is set to increase production capacity by 200%.</p><p>The expansion includes state-of-the-art machinery for the production of essential medicines, including antibiotics, antimalarials, and multivitamins. This investment underscores our commitment to reducing reliance on imported drugs and strengthening local healthcare infrastructure.</p><h3>Impact on Local Economy</h3><p>Beyond healthcare, this project is a boost for the local economy. We estimate the creation of over 500 direct jobs and thousands of indirect opportunities within the supply chain. Training programs will also be established to equip local talent with necessary pharmaceutical manufacturing skills.</p>"
  },
  {
    id: '2',
    slug: 'sustainable-energy-future',
    title: "Sustainable Energy: The Future of African Development",
    date: "January 8, 2024",
    category: "Insights",
    image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800&h=600&fit=crop",
    author: "Grace Mwangi, CEO CE-Energy",
    excerpt: "Exploring how renewable energy solutions can drive economic growth and industrialization.",
    content: "<p>As Africa's population continues to grow, the demand for reliable and clean energy has never been more critical. The transition to sustainable energy is not just an environmental imperative but an economic one.</p><h3>The Role of Solar Power</h3><p>Solar energy presents a unique opportunity for decentralized power generation. At CE-Energy and Heliohm, we are deploying hybrid systems that ensure businesses can operate without the interruptions caused by grid instability.</p><p>Investing in renewable infrastructure reduces long-term operational costs and attracts foreign investment, creating a virtuous cycle of growth and development.</p>"
  },
  {
    id: '3',
    slug: 'global-health-partnership',
    title: "Partnership Announcement with Global Health Initiative",
    date: "January 5, 2024",
    category: "News",
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&h=600&fit=crop",
    author: "Press Office",
    excerpt: "Strategic partnership to improve healthcare accessibility across West Africa.",
    content: "<p>Chris-Ejik Group is proud to announce a strategic partnership with the Global Health Initiative (GHI) to improve last-mile delivery of life-saving medical supplies to remote communities in Nigeria.</p><p>This collaboration leverages our extensive logistics network and GHI's expertise in public health interventions. Together, we aim to reach over 2 million additional beneficiaries in the next 18 months.</p>"
  },
  {
    id: '4',
    slug: 'technology-agriculture',
    title: "The Role of Technology in Modern Agriculture",
    date: "December 15, 2023",
    category: "Insights",
    image: "https://images.unsplash.com/photo-1625246333195-58405079a490?w=800&h=600&fit=crop",
    author: "Strategy Team",
    excerpt: "How innovative tech solutions are transforming the agricultural landscape in Nigeria.",
    content: "<p>Agriculture is the backbone of many African economies, yet it remains largely subsistence-based. Technology holds the key to unlocking the sector's full potential and ensuring food security.</p><p>From drone-assisted monitoring to data-driven soil analysis, we are exploring how engineering solutions can be adapted to support agro-allied industries, ensuring sustainability and higher yields.</p>"
  }
];

interface Article {
  id: string;
  slug: string;
  title: string;
  date: string;
  category: string;
  image: string;
  author: string;
  excerpt: string;
  content: string;
}

interface CMSContextType {
  articles: Article[];
  loading: boolean;
  error?: string | null;
  isAuthenticated: boolean;
  login: (password: string) => boolean;
  logout: () => void;
}

const CMSContext = createContext<CMSContextType | undefined>(undefined);

export const CMSProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [articles] = useState<Article[]>(initialArticles);
  const [loading] = useState(false);
  
  // Legacy Auth State (Retained for compatibility but no longer functional)
  const [isAuthenticated] = useState(false);

  // No-op functions
  const login = (password: string) => false;
  const logout = () => {};

  return (
    <CMSContext.Provider value={{ articles, loading, error: null, isAuthenticated, login, logout }}>
      {children}
    </CMSContext.Provider>
  );
};

export const useCMS = () => {
  const context = useContext(CMSContext);
  if (!context) {
    throw new Error('useCMS must be used within a CMSProvider');
  }
  return context;
};
