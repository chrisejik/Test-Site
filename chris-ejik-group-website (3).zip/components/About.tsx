
import React from 'react';
import { Link } from 'react-router-dom';

const About: React.FC = () => {
  return (
    <section id="about-us" className="py-24 bg-black relative overflow-hidden">
      {/* Gradient overlay removed as requested "background be black only" */}
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-[2px] bg-red-600"></div>
              <span className="text-red-600 uppercase tracking-widest text-sm font-medium">About Us</span>
            </div>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-6 leading-tight">
              Building a Legacy of <span className="text-red-600">Impact</span>
            </h2>
            <p className="text-neutral-400 text-lg leading-relaxed mb-8">
              Since 1990, Chris-Ejik Group has grown from a single vision into a diversified conglomerate touching millions of lives. Our journey is marked by strategic investments, innovative solutions, and an unwavering commitment to improving the quality of life across Africa.
            </p>
            <p className="text-neutral-400 leading-relaxed mb-8">
              Today, we operate through multiple subsidiaries spanning pharmaceuticals, energy, and large-scale electrical infrastructure. Each company within our group upholds our founding principles of excellence, integrity, and sustainable growth.
            </p>
            <Link to="/about">
              <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-white h-10 px-4 py-2 bg-red-600 hover:bg-red-700 gap-2 group">
                Learn Our Full Story
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4 group-hover:translate-x-1 transition-transform">
                  <path d="M5 12h14"></path>
                  <path d="m12 5 7 7-7 7"></path>
                </svg>
              </button>
            </Link>
          </div>
          <div className="space-y-6">
            <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-6 flex gap-6 hover:border-red-600/50 transition-colors group">
              <div className="w-14 h-14 bg-red-600/10 rounded-lg flex items-center justify-center shrink-0 group-hover:bg-red-600/20 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-target w-7 h-7 text-red-600">
                  <circle cx="12" cy="12" r="10"></circle>
                  <circle cx="12" cy="12" r="6"></circle>
                  <circle cx="12" cy="12" r="2"></circle>
                </svg>
              </div>
              <div>
                <h3 className="font-display text-xl font-semibold text-white mb-2">Vision</h3>
                <p className="text-neutral-400 text-sm leading-relaxed">
                  To be Africa's most trusted conglomerate, setting standards of excellence in every industry we operate.
                </p>
              </div>
            </div>
            <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-6 flex gap-6 hover:border-red-600/50 transition-colors group">
              <div className="w-14 h-14 bg-red-600/10 rounded-lg flex items-center justify-center shrink-0 group-hover:bg-red-600/20 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-users w-7 h-7 text-red-600">
                  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                  <circle cx="9" cy="7" r="4"></circle>
                  <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                  <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                </svg>
              </div>
              <div>
                <h3 className="font-display text-xl font-semibold text-white mb-2">People First</h3>
                <p className="text-neutral-400 text-sm leading-relaxed">
                  Our success is built on the dedication and expertise of our people across all our subsidiaries.
                </p>
              </div>
            </div>
            <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-6 flex gap-6 hover:border-red-600/50 transition-colors group">
              <div className="w-14 h-14 bg-red-600/10 rounded-lg flex items-center justify-center shrink-0 group-hover:bg-red-600/20 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-globe w-7 h-7 text-red-600">
                  <circle cx="12" cy="12" r="10"></circle>
                  <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"></path>
                  <path d="M2 12h20"></path>
                </svg>
              </div>
              <div>
                <h3 className="font-display text-xl font-semibold text-white mb-2">Global Reach</h3>
                <p className="text-neutral-400 text-sm leading-relaxed">
                  Operating across borders to bring world-class products and services to African markets.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
