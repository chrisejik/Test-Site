
import React from 'react';

const caseStudies = [
  {
    id: '01',
    title: 'PHARMACEUTICALS',
    image: 'https://ejik.vercel.app/_next/image?url=%2Fimages%2Fgrid1.png&w=3840&q=75',
    category: 'Healthcare',
    span: 'col-span-full lg:col-span-8'
  },
  {
    id: '02',
    title: 'HEALTHCARE DEPLOYMENT',
    image: 'https://ejik.vercel.app/_next/image?url=%2Fimages%2Fgrid2.webp&w=3840&q=75',
    category: 'Logistics',
    span: 'lg:col-span-4'
  },
  {
    id: '03',
    title: 'POWER SOLUTIONS',
    image: 'https://ejik.vercel.app/_next/image?url=%2Fimages%2Fgrid4.webp&w=3840&q=75',
    category: 'Engineering',
    span: 'lg:col-span-4'
  },
  {
    id: '04',
    title: 'COMMUNITY OUTREACH',
    image: 'https://ejik.vercel.app/_next/image?url=%2Fimages%2Fgrid3.webp&w=3840&q=75',
    category: 'Social Impact',
    span: 'lg:col-span-8'
  }
];

const CaseStudies: React.FC = () => {
  return (
    <section id="projects" className="py-32 bg-neutral-50">
      <div className="container mx-auto px-6 md:px-12">
        <div className="flex flex-col md:flex-row justify-between items-end mb-24 gap-8">
          <div className="max-w-xl space-y-6">
            <h3 className="text-[10px] font-bold uppercase tracking-[0.5em] text-accent">Selected Works</h3>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Our Case Studies</h2>
          </div>
          <p className="text-[10px] uppercase tracking-[0.3em] font-bold text-neutral-400">View All Projects</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {caseStudies.map((item) => (
            <div 
              key={item.id} 
              className={`group relative overflow-hidden bg-primary aspect-video lg:aspect-auto h-[400px] lg:h-[600px] ${item.span}`}
            >
              <img 
                src={item.image} 
                alt={item.title}
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110 opacity-60 grayscale group-hover:grayscale-0 group-hover:opacity-80"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/80 via-transparent to-transparent opacity-80" />
              
              <div className="absolute inset-0 p-12 flex flex-col justify-between z-10">
                <span className="text-white/50 font-bold text-xs tracking-widest">{item.id}</span>
                <div className="space-y-4">
                  <span className="text-accent text-[10px] uppercase tracking-[0.3em] font-bold">{item.category}</span>
                  <h4 className="text-white text-3xl font-bold tracking-tight">{item.title}</h4>
                  <div className="overflow-hidden h-0 group-hover:h-8 transition-all duration-500">
                    <p className="text-white/70 text-xs tracking-widest uppercase">Explore Case Study</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CaseStudies;
