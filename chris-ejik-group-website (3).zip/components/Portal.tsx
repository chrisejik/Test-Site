
import React from 'react';

const Portal: React.FC = () => {
  return (
    <section id="careers" className="relative py-32 md:py-64 bg-primary text-white overflow-hidden">
      <div className="absolute inset-0 opacity-20 bg-[url('https://ejik.vercel.app/images/portal-bg.webp')] bg-cover bg-fixed bg-center"></div>
      
      <div className="container mx-auto px-6 md:px-12 relative z-10 text-center space-y-12">
        <h2 className="text-4xl md:text-7xl font-bold tracking-tight max-w-4xl mx-auto leading-none text-balance">
          The Portal for <br />
          <span className="font-serif italic text-accent">Unlimited</span> Possibilities.
        </h2>
        <p className="text-white/60 text-sm md:text-lg font-light tracking-wide max-w-2xl mx-auto leading-relaxed">
          Join a team dedicated to engineering a better future and providing world-class healthcare.
        </p>
        <div className="pt-12">
          <a href="/careers" className="inline-block group">
            <div className="flex items-center gap-6 px-12 py-6 border border-white/20 hover:border-accent transition-all duration-500 rounded-full">
              <span className="text-[10px] font-bold uppercase tracking-[0.5em]">View Career Opportunities</span>
              <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center text-primary transition-transform group-hover:translate-x-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14m-7-7 7 7-7 7"/></svg>
              </div>
            </div>
          </a>
        </div>
      </div>
    </section>
  );
};

export default Portal;
