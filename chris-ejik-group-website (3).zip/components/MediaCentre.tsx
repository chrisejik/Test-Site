
import React from 'react';
import { Link } from 'react-router-dom';

const MediaCentre: React.FC = () => {
  return (
    <section className="py-24 bg-black">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-[2px] bg-red-600"></div>
              <span className="text-red-600 uppercase tracking-widest text-sm font-medium">Media Centre</span>
            </div>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-white">
              Latest <span className="text-red-600">Updates</span>
            </h2>
          </div>
          <Link className="mt-6 md:mt-0" to="/media">
            <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-red-600 bg-transparent text-red-600 hover:bg-red-600 hover:text-white h-10 px-4 py-2 gap-2 group">
              View All Articles
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4 group-hover:translate-x-1 transition-transform">
                <path d="M5 12h14" />
                <path d="m12 5 7 7-7 7" />
              </svg>
            </button>
          </Link>
        </div>
        <div className="grid lg:grid-cols-3 gap-6">
          <Link className="lg:col-span-2 group relative rounded-lg overflow-hidden border border-neutral-800" to="/media/pharmaceutical-expansion">
            <div className="aspect-[16/10] relative">
              <img 
                src="https://images.unsplash.com/photo-1585435557343-3b092031a831?w=800&h=600&fit=crop" 
                alt="Chris-Ejik Group Expands Pharmaceutical Operations" 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent"></div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <span className="inline-block px-3 py-1 bg-red-600 text-white text-xs uppercase tracking-wider rounded mb-4">news</span>
              <h3 className="font-display text-2xl md:text-3xl font-bold text-white mb-3 group-hover:text-red-600 transition-colors">Chris-Ejik Group Expands Pharmaceutical Operations</h3>
              <p className="text-neutral-300 mb-4 line-clamp-2">New manufacturing facility to increase production capacity by 200% and create over 500 jobs.</p>
              <div className="flex items-center gap-2 text-neutral-400 text-sm">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-calendar w-4 h-4 text-red-600">
                  <path d="M8 2v4" />
                  <path d="M16 2v4" />
                  <rect width="18" height="18" x="3" y="4" rx="2" />
                  <path d="M3 10h18" />
                </svg>
                <span>January 10, 2024</span>
              </div>
            </div>
          </Link>
          <div className="flex flex-col gap-6">
            <Link className="group flex gap-4 bg-neutral-900 rounded-lg overflow-hidden border border-neutral-800 hover:border-red-600/50 transition-colors" to="/media/sustainable-energy-future">
              <div className="w-32 h-32 shrink-0">
                <img 
                  src="https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800&h=600&fit=crop" 
                  alt="Sustainable Energy: The Future of African Development" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                />
              </div>
              <div className="flex-1 p-4 flex flex-col justify-center">
                <span className="text-red-600 text-xs uppercase tracking-wider mb-2">insights</span>
                <h4 className="font-display font-semibold text-white group-hover:text-red-600 transition-colors line-clamp-2 mb-2">Sustainable Energy: The Future of African Development</h4>
                <div className="flex items-center gap-2 text-neutral-400 text-xs">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-calendar w-3 h-3 text-red-600">
                    <path d="M8 2v4" />
                    <path d="M16 2v4" />
                    <rect width="18" height="18" x="3" y="4" rx="2" />
                    <path d="M3 10h18" />
                  </svg>
                  <span>Jan 8</span>
                </div>
              </div>
            </Link>
            <Link className="group flex gap-4 bg-neutral-900 rounded-lg overflow-hidden border border-neutral-800 hover:border-red-600/50 transition-colors" to="/media/global-health-partnership">
              <div className="w-32 h-32 shrink-0">
                <img 
                  src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&h=600&fit=crop" 
                  alt="Partnership Announcement with Global Health Initiative" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                />
              </div>
              <div className="flex-1 p-4 flex flex-col justify-center">
                <span className="text-red-600 text-xs uppercase tracking-wider mb-2">news</span>
                <h4 className="font-display font-semibold text-white group-hover:text-red-600 transition-colors line-clamp-2 mb-2">Partnership Announcement with Global Health Initiative</h4>
                <div className="flex items-center gap-2 text-neutral-400 text-xs">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-calendar w-3 h-3 text-red-600">
                    <path d="M8 2v4" />
                    <path d="M16 2v4" />
                    <rect width="18" height="18" x="3" y="4" rx="2" />
                    <path d="M3 10h18" />
                  </svg>
                  <span>Jan 5</span>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MediaCentre;
