
import React, { useEffect, useState, useRef } from 'react';

const stats = [
  { label: 'Years Experience', value: 30, suffix: '+' },
  { label: 'Subsidiaries', value: 5, suffix: '+' },
  { label: 'Employees', value: 500, suffix: '+' },
  { label: 'Global Partners', value: 20, suffix: '+' },
];

const StatItem = ({ item }: { item: typeof stats[0] }) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          const duration = 2000;
          const start = 0;
          const end = item.value;
          const startTime = performance.now();

          const animate = (currentTime: number) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const easeOut = 1 - Math.pow(1 - progress, 3);
            
            setCount(Math.floor(start + (end - start) * easeOut));

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setCount(end);
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [item.value]);

  return (
    <div ref={ref} className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-red-600/30 transition-colors group">
      <div className="text-4xl font-display font-bold text-red-600 mb-1 tabular-nums">
        {count}{item.suffix}
      </div>
      <div className="text-neutral-400 text-sm uppercase tracking-wider">{item.label}</div>
    </div>
  );
};

const Stats: React.FC = () => {
  return (
    <section className="py-12 bg-black border-y border-neutral-900 relative z-20">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {stats.map((stat, index) => (
            <StatItem key={index} item={stat} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;
