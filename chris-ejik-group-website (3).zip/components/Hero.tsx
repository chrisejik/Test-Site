
import React from 'react';
import { Link } from 'react-router-dom';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex flex-col overflow-hidden bg-neutral-900 justify-center">
      {/* Background with dark gradients on left and right side */}
      <div className="absolute inset-0 z-0">
        <div 
          className="absolute inset-0 bg-[url('https://ejik.vercel.app/images/Ejik_group_hero.webp')] bg-cover bg-center animate-scale-in"
          aria-hidden="true"
        />
        {/* Dark gradients - Left side only */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/75 via-black/20 to-transparent" />
      </div>

      {/* Decorative Blur Elements */}
      <div className="absolute top-20 right-20 w-96 h-96 bg-red-600/10 rounded-full blur-3xl z-10 pointer-events-none"></div>
      <div className="absolute bottom-20 left-20 w-64 h-64 bg-red-600/5 rounded-full blur-2xl z-10 pointer-events-none"></div>
      <div className="absolute left-0 top-1/3 w-1 h-32 bg-red-600 z-10 pointer-events-none"></div>

      {/* Main Content */}
      <div className="flex-1 flex items-center container mx-auto px-4 relative z-10">
        <div className="max-w-4xl">
          <div className="flex items-center gap-4 mb-8 animate-fade-up">
            <div className="w-12 h-[2px] bg-red-600"></div>
            <span className="text-red-600 uppercase tracking-widest text-sm font-medium">Since 1990</span>
          </div>
          
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold text-white leading-tight mb-8 animate-fade-up" style={{ animationDelay: '0.1s' }}>
            Improving the <span className="text-red-600">quality of life</span>
          </h1>
          
          <p className="text-lg md:text-xl text-neutral-200 max-w-2xl mb-12 leading-relaxed animate-fade-up" style={{ animationDelay: '0.2s' }}>
            For over 30 years, Chris-Ejik Group has played a leading role in improving lives and powering industries across Africa through pharmaceuticals, energy solutions, and large-scale electrical infrastructure.
          </p>
          
          <div className="flex flex-wrap gap-4 animate-fade-up" style={{ animationDelay: '0.3s' }}>
            <Link to="/about">
              <button className="inline-flex items-center justify-center whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-11 rounded-md px-8 bg-red-600 hover:bg-red-700 text-white gap-2 group">
                Discover Our Story
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4 group-hover:translate-x-1 transition-transform">
                  <path d="M5 12h14"></path>
                  <path d="m12 5 7 7-7 7"></path>
                </svg>
              </button>
            </Link>
            <Link to="/portfolio">
              <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-white/20 bg-black hover:bg-neutral-900 text-white h-11 rounded-md px-8">
                View Our Portfolio
              </button>
            </Link>
          </div>
        </div>
      </div>

      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white animate-bounce z-20">
        <span className="text-xs uppercase tracking-widest text-white">Scroll</span>
        <div className="w-[1px] h-8 bg-gradient-to-b from-white to-transparent"></div>
      </div>
    </section>
  );
};

export default Hero;
