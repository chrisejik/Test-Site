
import React from 'react';
import { Link } from 'react-router-dom';

const Subsidiaries: React.FC = () => {
  return (
    <section className="py-24 bg-black">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16">
          <div>
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-[2px] bg-red-600"></div>
              <span className="text-red-600 uppercase tracking-widest text-sm font-medium">Our Companies</span>
            </div>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-white">
              A Portfolio of <span className="text-red-600">Excellence</span>
            </h2>
          </div>
          <p className="text-neutral-400 max-w-md mt-6 md:mt-0">
            Our subsidiaries span diverse industries, each committed to innovation and sustainable growth.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Link className="group relative bg-neutral-900 border border-neutral-800 rounded-lg p-8 hover:border-red-600/50 transition-all duration-300 overflow-hidden" to="/subsidiaries/pharmaceuticals">
            <span className="absolute top-4 right-4 font-display text-8xl font-bold text-white/5 group-hover:text-red-600/10 transition-colors">01</span>
            <div className="relative z-10">
              <span className="text-red-600 font-medium">01</span>
              <h3 className="font-display text-2xl font-semibold text-white mt-2 mb-4 group-hover:text-red-600 transition-colors">Chris-Ejik Pharmaceuticals</h3>
              <p className="text-neutral-400 mb-6 max-w-sm">Leading pharmaceutical manufacturing and distribution across Africa.</p>
              <div className="flex items-center gap-2 text-red-600">
                <span className="text-sm font-medium">Learn More</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-up-right w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform">
                  <path d="M7 7h10v10"></path>
                  <path d="M7 17 17 7"></path>
                </svg>
              </div>
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-red-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          </Link>

          <Link className="group relative bg-neutral-900 border border-neutral-800 rounded-lg p-8 hover:border-red-600/50 transition-all duration-300 overflow-hidden" to="/subsidiaries/international">
            <span className="absolute top-4 right-4 font-display text-8xl font-bold text-white/5 group-hover:text-red-600/10 transition-colors">02</span>
            <div className="relative z-10">
              <span className="text-red-600 font-medium">02</span>
              <h3 className="font-display text-2xl font-semibold text-white mt-2 mb-4 group-hover:text-red-600 transition-colors">Chris-Ejik International</h3>
              <p className="text-neutral-400 mb-6 max-w-sm">Delivering large-scale electrical infrastructure and EPC projects.</p>
              <div className="flex items-center gap-2 text-red-600">
                <span className="text-sm font-medium">Learn More</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-up-right w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform">
                  <path d="M7 7h10v10"></path>
                  <path d="M7 17 17 7"></path>
                </svg>
              </div>
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-red-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          </Link>

          <Link className="group relative bg-neutral-900 border border-neutral-800 rounded-lg p-8 hover:border-red-600/50 transition-all duration-300 overflow-hidden" to="/subsidiaries/engineering">
            <span className="absolute top-4 right-4 font-display text-8xl font-bold text-white/5 group-hover:text-red-600/10 transition-colors">03</span>
            <div className="relative z-10">
              <span className="text-red-600 font-medium">03</span>
              <h3 className="font-display text-2xl font-semibold text-white mt-2 mb-4 group-hover:text-red-600 transition-colors">Chris-Ejik Engineering</h3>
              <p className="text-neutral-400 mb-6 max-w-sm">Meter assembly and power infrastructure solutions.</p>
              <div className="flex items-center gap-2 text-red-600">
                <span className="text-sm font-medium">Learn More</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-up-right w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform">
                  <path d="M7 7h10v10"></path>
                  <path d="M7 17 17 7"></path>
                </svg>
              </div>
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-red-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          </Link>

          <Link className="group relative bg-neutral-900 border border-neutral-800 rounded-lg p-8 hover:border-red-600/50 transition-all duration-300 overflow-hidden" to="/subsidiaries/ce-energy">
            <span className="absolute top-4 right-4 font-display text-8xl font-bold text-white/5 group-hover:text-red-600/10 transition-colors">04</span>
            <div className="relative z-10">
              <span className="text-red-600 font-medium">04</span>
              <h3 className="font-display text-2xl font-semibold text-white mt-2 mb-4 group-hover:text-red-600 transition-colors">CE-Energy</h3>
              <p className="text-neutral-400 mb-6 max-w-sm">Powering Africa through sustainable energy solutions.</p>
              <div className="flex items-center gap-2 text-red-600">
                <span className="text-sm font-medium">Learn More</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-up-right w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform">
                  <path d="M7 7h10v10"></path>
                  <path d="M7 17 17 7"></path>
                </svg>
              </div>
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-red-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          </Link>

          <Link className="group relative bg-neutral-900 border border-neutral-800 rounded-lg p-8 hover:border-red-600/50 transition-all duration-300 overflow-hidden" to="/subsidiaries/heliohm">
            <span className="absolute top-4 right-4 font-display text-8xl font-bold text-white/5 group-hover:text-red-600/10 transition-colors">05</span>
            <div className="relative z-10">
              <span className="text-red-600 font-medium">05</span>
              <h3 className="font-display text-2xl font-semibold text-white mt-2 mb-4 group-hover:text-red-600 transition-colors">Heliohm</h3>
              <p className="text-neutral-400 mb-6 max-w-sm">Innovative solar technology for a brighter future.</p>
              <div className="flex items-center gap-2 text-red-600">
                <span className="text-sm font-medium">Learn More</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-up-right w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform">
                  <path d="M7 7h10v10"></path>
                  <path d="M7 17 17 7"></path>
                </svg>
              </div>
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-red-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default Subsidiaries;
