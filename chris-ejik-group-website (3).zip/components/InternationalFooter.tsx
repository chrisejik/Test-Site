
import React from 'react';
import { Link } from 'react-router-dom';

const InternationalFooter: React.FC = () => {
  return (
    <footer className="bg-black border-t border-neutral-800">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <img 
                src="https://image2url.com/r2/default/images/1769499585071-b0427ed4-cfc2-478f-8732-9aae224efd6b.png" 
                alt="Chris-Ejik International" 
                className="h-14 w-auto object-contain" 
              />
            </div>
            <p className="text-neutral-400 text-sm leading-relaxed">
              Chris-Ejik International: Bridging markets and fostering global trade with integrity and excellence for over three decades.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 bg-neutral-900 rounded-full flex items-center justify-center text-neutral-400 hover:bg-neutral-600 hover:text-white transition-colors" aria-label="Facebook">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-facebook w-5 h-5"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
              </a>
              <a href="#" className="w-10 h-10 bg-neutral-900 rounded-full flex items-center justify-center text-neutral-400 hover:bg-neutral-600 hover:text-white transition-colors" aria-label="Twitter">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-twitter w-5 h-5"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path></svg>
              </a>
              <a href="#" className="w-10 h-10 bg-neutral-900 rounded-full flex items-center justify-center text-neutral-400 hover:bg-neutral-600 hover:text-white transition-colors" aria-label="LinkedIn">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-linkedin w-5 h-5"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect width="4" height="12" x="2" y="9"></rect><circle cx="4" cy="4" r="2"></circle></svg>
              </a>
            </div>
          </div>
          <div>
            <h4 className="font-display text-lg font-semibold text-white mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><Link className="text-neutral-400 hover:text-neutral-200 transition-colors text-sm" to="/subsidiaries/international">About Us</Link></li>
              <li><Link className="text-neutral-400 hover:text-neutral-200 transition-colors text-sm" to="/subsidiaries/international/services">Services</Link></li>
              <li><Link className="text-neutral-400 hover:text-neutral-200 transition-colors text-sm" to="/subsidiaries/international/projects">Projects</Link></li>
              <li><Link className="text-neutral-400 hover:text-neutral-200 transition-colors text-sm" to="/media">Media</Link></li>
              <li><Link className="text-neutral-400 hover:text-neutral-200 transition-colors text-sm" to="/contact">Contact</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-display text-lg font-semibold text-white mb-6">Our Companies</h4>
            <ul className="space-y-3">
              <li><Link className="text-neutral-400 hover:text-neutral-200 transition-colors text-sm" to="/subsidiaries/pharmaceuticals">Chris-Ejik Pharmaceuticals</Link></li>
              <li><Link className="text-neutral-400 hover:text-neutral-200 transition-colors text-sm" to="/subsidiaries/international">Chris-Ejik International</Link></li>
              <li><Link className="text-neutral-400 hover:text-neutral-200 transition-colors text-sm" to="/subsidiaries/engineering">Chris-Ejik Engineering</Link></li>
              <li><Link className="text-neutral-400 hover:text-neutral-200 transition-colors text-sm" to="/subsidiaries/ce-energy">CE-Energy</Link></li>
              <li><Link className="text-neutral-400 hover:text-neutral-200 transition-colors text-sm" to="/subsidiaries/heliohm">Heliohm</Link></li>
            </ul>
          </div>
          <div className="space-y-6">
            <div>
              <h4 className="font-display text-lg font-semibold text-white mb-4">Newsletter</h4>
              <p className="text-neutral-400 text-sm mb-4">Stay updated with global trade insights.</p>
              <div className="flex gap-2">
                <input type="email" className="flex h-10 w-full rounded-md border px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-neutral-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm bg-neutral-900 border-neutral-800 text-white" placeholder="Your email" />
                <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-white h-10 px-4 py-2 bg-neutral-600 hover:bg-neutral-700">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-mail w-4 h-4"><rect width="20" height="16" x="2" y="4" rx="2"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path></svg>
                </button>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-neutral-400 text-sm">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-phone w-4 h-4 text-neutral-500"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                <span>+234 800 000 0000</span>
              </div>
              <div className="flex items-center gap-3 text-neutral-400 text-sm">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-mail w-4 h-4 text-neutral-500"><rect width="20" height="16" x="2" y="4" rx="2"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path></svg>
                <span>info@chrisejikgroup.com</span>
              </div>
              <div className="flex items-start gap-3 text-neutral-400 text-sm">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-map-pin w-4 h-4 text-neutral-500 mt-1"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"></path><circle cx="12" cy="10" r="3"></circle></svg>
                <span>Lagos, Nigeria</span>
              </div>
            </div>
          </div>
        </div>
        <div className="border-t border-neutral-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-neutral-400 text-sm">© 2026 Chris-Ejik Group. All rights reserved.</p>
          <div className="flex gap-6 text-sm">
            <Link className="text-neutral-400 hover:text-neutral-200 transition-colors" to="/privacy">Privacy Policy</Link>
            <Link className="text-neutral-400 hover:text-neutral-200 transition-colors" to="/terms">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default InternationalFooter;
