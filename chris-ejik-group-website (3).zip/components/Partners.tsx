
import React from 'react';

const Partners: React.FC = () => {
  const partners = [
    { 
      id: 1,
      name: 'TCN', 
      logo: 'https://tcn.org.ng/images/demo/tcnLogo.png',
    },
    { 
      id: 2,
      name: 'NAFDAC', 
      logo: 'https://nafdac.gov.ng/wp-content/uploads/2023/09/NAFDAC-Logo-2.png',
    },
    { 
      id: 3,
      name: 'MAN', 
      logo: 'https://res.cloudinary.com/du9oqsosk/image/upload/v1/media/manlogo2_ayq51z_agtzjs', 
    },
    { 
      id: 4,
      name: 'SON', 
      logo: 'https://son.gov.ng/wp-content/uploads/2022/03/son_png.png',
    },
    {
      id: 5,
      name: 'NERDC',
      logo: 'https://nerc.gov.ng/wp-content/uploads/2024/03/nerc-logo1.png'
    },
    {
      id: 6,
      name: 'NEMSA',
      logo: 'https://nemsa.gov.ng/wp-content/uploads/2021/08/logo-GREEN.png'
    }
  ];

  return (
    <section className="py-24 bg-black border-t border-neutral-900 overflow-hidden">
      <div className="container mx-auto px-4 mb-16">
        <div className="text-center">
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="w-12 h-[2px] bg-red-600"></div>
            <span className="text-red-600 uppercase tracking-widest text-sm font-medium">Trusted By</span>
            <div className="w-12 h-[2px] bg-red-600"></div>
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-bold text-white">Our Partners</h2>
        </div>
      </div>
      
      <div className="relative w-full">
        <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-black to-transparent z-10"></div>
        <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-black to-transparent z-10"></div>
        
        <div className="flex animate-marquee whitespace-nowrap items-center">
          {/* First set of logos */}
          {partners.map((partner) => (
            <div 
              key={partner.id}
              className="mx-12 w-48 h-24 flex items-center justify-center flex-shrink-0 grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all duration-500"
            >
              <img 
                src={partner.logo} 
                alt={`${partner.name} Logo`}
                className="max-w-full max-h-full object-contain"
              />
            </div>
          ))}
          
          {/* Duplicate set for infinite scroll */}
          {partners.map((partner) => (
            <div 
              key={`${partner.id}-dup`}
              className="mx-12 w-48 h-24 flex items-center justify-center flex-shrink-0 grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all duration-500"
            >
              <img 
                src={partner.logo} 
                alt={`${partner.name} Logo`}
                className="max-w-full max-h-full object-contain"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Partners;
