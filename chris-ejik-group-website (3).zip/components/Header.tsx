
import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isMobileMediaOpen, setIsMobileMediaOpen] = useState(false);
  const [isMobileSubsidiariesOpen, setIsMobileSubsidiariesOpen] = useState(false);

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-md border-b border-white/10">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-24">
            <Link className="flex items-center gap-3" to="/">
              <img 
                src="https://image2url.com/r2/default/images/1769497869081-27d59524-cebf-4992-ac6f-16bee4139a84.png" 
                alt="Chris-Ejik Group" 
                className="h-14 w-auto object-contain" 
              />
            </Link>
            
            <nav className="hidden lg:flex items-center gap-8">
              <Link className="text-neutral-400 hover:text-red-600 transition-colors" to="/about">About Us</Link>
              <Link className="text-neutral-400 hover:text-red-600 transition-colors" to="/portfolio">Portfolio</Link>
              
              <div className="relative group">
                <button type="button" className="flex items-center gap-1 text-neutral-400 group-hover:text-red-600 transition-colors py-4">
                  Media
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-down w-4 h-4 transition-transform duration-300 group-hover:rotate-180"><path d="m6 9 6 6 6-6"></path></svg>
                </button>
                
                <div className="absolute top-full left-1/2 -translate-x-1/2 pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 transform translate-y-2 group-hover:translate-y-0 w-48">
                  <div className="bg-neutral-900 border border-neutral-800 rounded-lg shadow-xl overflow-hidden flex flex-col">
                    <Link to="/media/news" className="px-6 py-3 text-sm text-neutral-400 hover:bg-red-600 hover:text-white transition-colors text-left">
                      News
                    </Link>
                    <Link to="/media/insights" className="px-6 py-3 text-sm text-neutral-400 hover:bg-red-600 hover:text-white transition-colors text-left border-t border-neutral-800">
                      Insights
                    </Link>
                  </div>
                </div>
              </div>

              <Link className="text-neutral-400 hover:text-red-600 transition-colors" to="/careers">Careers</Link>
              <Link className="text-neutral-400 hover:text-red-600 transition-colors" to="/contact">Contact Us</Link>
            </nav>
            
            <div className="hidden lg:flex items-center gap-4">
              <div className="relative group">
                <button className="inline-flex items-center justify-center whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-white/20 bg-black text-white hover:bg-red-600 hover:text-white h-9 rounded-md px-3 gap-2" type="button">
                  Subsidiaries
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-down w-4 h-4 transition-transform duration-300 group-hover:rotate-180"><path d="m6 9 6 6 6-6"></path></svg>
                </button>

                <div className="absolute top-full right-0 pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 transform translate-y-2 group-hover:translate-y-0 w-64">
                  <div className="bg-neutral-900 border border-neutral-800 rounded-lg shadow-xl overflow-hidden flex flex-col">
                    <Link to="/subsidiaries/pharmaceuticals" className="px-6 py-3 text-sm text-neutral-400 hover:bg-red-600 hover:text-white transition-colors text-left">
                      Chris-Ejik Pharmaceuticals
                    </Link>
                    <Link to="/subsidiaries/international" className="px-6 py-3 text-sm text-neutral-400 hover:bg-red-600 hover:text-white transition-colors text-left border-t border-neutral-800">
                      Chris-Ejik International
                    </Link>
                    <Link to="/subsidiaries/engineering" className="px-6 py-3 text-sm text-neutral-400 hover:bg-red-600 hover:text-white transition-colors text-left border-t border-neutral-800">
                      Chris-Ejik Engineering
                    </Link>
                    <Link to="/subsidiaries/ce-energy" className="px-6 py-3 text-sm text-neutral-400 hover:bg-red-600 hover:text-white transition-colors text-left border-t border-neutral-800">
                      CE-Energy
                    </Link>
                    <Link to="/subsidiaries/heliohm" className="px-6 py-3 text-sm text-neutral-400 hover:bg-red-600 hover:text-white transition-colors text-left border-t border-neutral-800">
                      Heliohm
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            
            <button className="lg:hidden text-white hover:text-red-600 transition-colors" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-menu w-6 h-6"><line x1="4" x2="20" y1="12" y2="12"></line><line x1="4" x2="20" y1="6" y2="6"></line><line x1="4" x2="20" y1="18" y2="18"></line></svg>
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <div className={`fixed inset-0 bg-black z-40 flex flex-col pt-24 transition-transform duration-300 ease-in-out lg:hidden ${isMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}>
          <div className="container mx-auto px-4 py-6 flex flex-col gap-4 overflow-y-auto max-h-[calc(100vh-6rem)]">
            <Link to="/about" onClick={() => setIsMenuOpen(false)} className="text-xl font-medium text-neutral-400 hover:text-red-600">About Us</Link>
            <Link to="/portfolio" onClick={() => setIsMenuOpen(false)} className="text-xl font-medium text-neutral-400 hover:text-red-600">Portfolio</Link>
            
            <div>
              <button 
                onClick={() => setIsMobileMediaOpen(!isMobileMediaOpen)}
                className="flex items-center justify-between w-full text-xl font-medium text-neutral-400 hover:text-red-600"
              >
                Media
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`lucide lucide-chevron-down w-5 h-5 transition-transform ${isMobileMediaOpen ? 'rotate-180' : ''}`}><path d="m6 9 6 6 6-6"></path></svg>
              </button>
              {isMobileMediaOpen && (
                <div className="flex flex-col gap-3 pl-4 mt-3 border-l border-neutral-800">
                  <Link to="/media/news" onClick={() => setIsMenuOpen(false)} className="text-lg text-neutral-500 hover:text-white">News</Link>
                  <Link to="/media/insights" onClick={() => setIsMenuOpen(false)} className="text-lg text-neutral-500 hover:text-white">Insights</Link>
                </div>
              )}
            </div>

            <Link to="/careers" onClick={() => setIsMenuOpen(false)} className="text-xl font-medium text-neutral-400 hover:text-red-600">Careers</Link>
            <Link to="/contact" onClick={() => setIsMenuOpen(false)} className="text-xl font-medium text-neutral-400 hover:text-red-600">Contact Us</Link>
            
            <div className="mt-4 border-t border-neutral-800 pt-4">
               <button 
                 onClick={() => setIsMobileSubsidiariesOpen(!isMobileSubsidiariesOpen)}
                 className="flex items-center justify-between w-full text-xl font-medium text-neutral-400 mb-4 hover:text-red-600"
               >
                 Subsidiaries
                 <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`lucide lucide-chevron-down w-5 h-5 transition-transform ${isMobileSubsidiariesOpen ? 'rotate-180' : ''}`}><path d="m6 9 6 6 6-6"></path></svg>
               </button>
               
               {isMobileSubsidiariesOpen && (
                 <div className="flex flex-col gap-3 pl-4 border-l border-neutral-800">
                   <Link to="/subsidiaries/pharmaceuticals" onClick={() => setIsMenuOpen(false)} className="text-lg text-neutral-500 hover:text-white">Chris-Ejik Pharmaceuticals</Link>
                   <Link to="/subsidiaries/international" onClick={() => setIsMenuOpen(false)} className="text-lg text-neutral-500 hover:text-white">Chris-Ejik International</Link>
                   <Link to="/subsidiaries/engineering" onClick={() => setIsMenuOpen(false)} className="text-lg text-neutral-500 hover:text-white">Chris-Ejik Engineering</Link>
                   <Link to="/subsidiaries/ce-energy" onClick={() => setIsMenuOpen(false)} className="text-lg text-neutral-500 hover:text-white">CE-Energy</Link>
                   <Link to="/subsidiaries/heliohm" onClick={() => setIsMenuOpen(false)} className="text-lg text-neutral-500 hover:text-white">Heliohm</Link>
                 </div>
               )}
            </div>
          </div>
        </div>
      </header>
      <div className="h-24"></div>
    </>
  );
};

export default Header;
