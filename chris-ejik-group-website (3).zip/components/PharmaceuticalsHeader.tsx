
import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const PharmaceuticalsHeader: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSubsidiariesOpen, setIsSubsidiariesOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-md border-b border-neutral-800">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          <Link className="flex items-center gap-3" to="/subsidiaries/pharmaceuticals">
            <img 
              src="https://image2url.com/r2/default/images/1769498218341-a9a5a060-2645-4597-a292-ca98a4f2f476.png" 
              alt="Chris-Ejik Pharmaceuticals" 
              className="h-14 w-auto object-contain" 
            />
          </Link>
          
          <nav className="hidden lg:flex items-center gap-8">
            <Link className="hover:text-blue-500 transition-colors text-blue-500 font-medium" to="/subsidiaries/pharmaceuticals">About Us</Link>
            <Link className="text-neutral-400 hover:text-white transition-colors" to="/subsidiaries/pharmaceuticals/products">Products</Link>
            <Link className="text-neutral-400 hover:text-white transition-colors" to="/media">Media</Link>
            <Link className="text-neutral-400 hover:text-white transition-colors" to="/careers">Careers</Link>
            <Link className="text-neutral-400 hover:text-white transition-colors" to="/contact">Contact Us</Link>
          </nav>
          
          <div className="hidden lg:flex items-center gap-4">
            <div className="relative group">
              <button 
                className="inline-flex items-center justify-center whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 hover:bg-neutral-800 hover:text-white h-9 rounded-md px-3 gap-2 text-neutral-400" 
                type="button"
              >
                Other Subsidiaries
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-down w-4 h-4"><path d="m6 9 6 6 6-6"></path></svg>
              </button>

              <div className="absolute top-full right-0 pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 transform translate-y-2 group-hover:translate-y-0 w-64">
                <div className="bg-neutral-900 border border-neutral-800 rounded-lg shadow-xl overflow-hidden flex flex-col">
                  <Link to="/" className="px-6 py-3 text-sm text-neutral-400 hover:bg-blue-900/20 hover:text-blue-500 transition-colors text-left">
                    Group Home
                  </Link>
                  <Link to="/subsidiaries/international" className="px-6 py-3 text-sm text-neutral-400 hover:bg-blue-900/20 hover:text-blue-500 transition-colors text-left border-t border-neutral-800">
                    Chris-Ejik International
                  </Link>
                  <Link to="/subsidiaries/engineering" className="px-6 py-3 text-sm text-neutral-400 hover:bg-blue-900/20 hover:text-blue-500 transition-colors text-left border-t border-neutral-800">
                    Chris-Ejik Engineering
                  </Link>
                  <Link to="/subsidiaries/ce-energy" className="px-6 py-3 text-sm text-neutral-400 hover:bg-blue-900/20 hover:text-blue-500 transition-colors text-left border-t border-neutral-800">
                    CE-Energy
                  </Link>
                  <Link to="/subsidiaries/heliohm" className="px-6 py-3 text-sm text-neutral-400 hover:bg-blue-900/20 hover:text-blue-500 transition-colors text-left border-t border-neutral-800">
                    Heliohm
                  </Link>
                </div>
              </div>
            </div>
          </div>
          
          <button className="lg:hidden text-white hover:text-blue-500 transition-colors" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-menu w-6 h-6"><line x1="4" x2="20" y1="12" y2="12"></line><line x1="4" x2="20" y1="6" y2="6"></line><line x1="4" x2="20" y1="18" y2="18"></line></svg>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`fixed inset-0 bg-black z-40 flex flex-col pt-20 transition-transform duration-300 ease-in-out lg:hidden ${isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="container mx-auto px-4 py-6 flex flex-col gap-4">
          <Link to="/subsidiaries/pharmaceuticals" onClick={() => setIsMobileMenuOpen(false)} className="text-xl font-medium text-blue-500">About Us</Link>
          <Link to="/subsidiaries/pharmaceuticals/products" onClick={() => setIsMobileMenuOpen(false)} className="text-xl font-medium text-neutral-400 hover:text-white">Products</Link>
          <Link to="/media" onClick={() => setIsMobileMenuOpen(false)} className="text-xl font-medium text-neutral-400 hover:text-white">Media</Link>
          <Link to="/careers" onClick={() => setIsMobileMenuOpen(false)} className="text-xl font-medium text-neutral-400 hover:text-white">Careers</Link>
          <Link to="/contact" onClick={() => setIsMobileMenuOpen(false)} className="text-xl font-medium text-neutral-400 hover:text-white">Contact Us</Link>
          
          <div className="mt-4 border-t border-neutral-800 pt-4">
             <button 
               onClick={() => setIsSubsidiariesOpen(!isSubsidiariesOpen)}
               className="flex items-center justify-between w-full text-xl font-medium text-neutral-400 mb-4 hover:text-white"
             >
               Other Subsidiaries
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`lucide lucide-chevron-down w-5 h-5 transition-transform ${isSubsidiariesOpen ? 'rotate-180' : ''}`}><path d="m6 9 6 6 6-6"></path></svg>
             </button>
             
             {isSubsidiariesOpen && (
               <div className="flex flex-col gap-3 pl-4">
                 <Link to="/" onClick={() => setIsMobileMenuOpen(false)} className="text-lg text-neutral-500 hover:text-white">Group Home</Link>
                 <Link to="/subsidiaries/international" onClick={() => setIsMobileMenuOpen(false)} className="text-lg text-neutral-500 hover:text-white">Chris-Ejik International</Link>
                 <Link to="/subsidiaries/engineering" onClick={() => setIsMobileMenuOpen(false)} className="text-lg text-neutral-500 hover:text-white">Chris-Ejik Engineering</Link>
                 <Link to="/subsidiaries/ce-energy" onClick={() => setIsMobileMenuOpen(false)} className="text-lg text-neutral-500 hover:text-white">CE-Energy</Link>
                 <Link to="/subsidiaries/heliohm" onClick={() => setIsMobileMenuOpen(false)} className="text-lg text-neutral-500 hover:text-white">Heliohm</Link>
               </div>
             )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default PharmaceuticalsHeader;
