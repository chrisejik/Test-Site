
import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { CMSProvider } from './context/CMSContext';
import Home from './pages/Home';
import About from './pages/About';
import Portfolio from './pages/Portfolio';
import MediaCentre from './pages/MediaCentre';
import Article from './pages/Article';
import Careers from './pages/Careers';
import JobDetail from './pages/JobDetail';
import Contact from './pages/Contact';
import Pharmaceuticals from './pages/subsidiaries/Pharmaceuticals';
import PharmaceuticalsProducts from './pages/subsidiaries/PharmaceuticalsProducts';
import Impilin from './pages/subsidiaries/products/Impilin';
import Euroclox from './pages/subsidiaries/products/Euroclox';
import Imox from './pages/subsidiaries/products/Imox';
import Imoxclav from './pages/subsidiaries/products/Imoxclav';
import Euromether from './pages/subsidiaries/products/Euromether';
import International from './pages/subsidiaries/International';
import InternationalServices from './pages/subsidiaries/InternationalServices';
import InternationalProjects from './pages/subsidiaries/InternationalProjects';
import Engineering from './pages/subsidiaries/Engineering';
import EngineeringServices from './pages/subsidiaries/EngineeringServices';
import EngineeringProjects from './pages/subsidiaries/EngineeringProjects';
import CEEnergy from './pages/subsidiaries/CEEnergy';
import Heliohm from './pages/subsidiaries/Heliohm';

const App: React.FC = () => {
  return (
    <CMSProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/portfolio" element={<Portfolio />} />
          <Route path="/careers" element={<Careers />} />
          <Route path="/careers/:slug" element={<JobDetail />} />
          <Route path="/contact" element={<Contact />} />
          
          {/* Media routes */}
          <Route path="/media" element={<MediaCentre />} />
          <Route path="/media/news" element={<MediaCentre />} />
          <Route path="/media/insights" element={<MediaCentre />} />
          <Route path="/media/:slug" element={<Article />} />

          {/* Subsidiaries */}
          <Route path="/subsidiaries/pharmaceuticals" element={<Pharmaceuticals />} />
          <Route path="/subsidiaries/pharmaceuticals/products" element={<PharmaceuticalsProducts />} />
          <Route path="/subsidiaries/pharmaceuticals/products/impilin" element={<Impilin />} />
          <Route path="/subsidiaries/pharmaceuticals/products/euroclox" element={<Euroclox />} />
          <Route path="/subsidiaries/pharmaceuticals/products/imox" element={<Imox />} />
          <Route path="/subsidiaries/pharmaceuticals/products/imoxclav" element={<Imoxclav />} />
          <Route path="/subsidiaries/pharmaceuticals/products/euromether" element={<Euromether />} />
          
          <Route path="/subsidiaries/international" element={<International />} />
          <Route path="/subsidiaries/international/services" element={<InternationalServices />} />
          <Route path="/subsidiaries/international/projects" element={<InternationalProjects />} />

          <Route path="/subsidiaries/engineering" element={<Engineering />} />
          <Route path="/subsidiaries/engineering/services" element={<EngineeringServices />} />
          <Route path="/subsidiaries/engineering/projects" element={<EngineeringProjects />} />

          <Route path="/subsidiaries/ce-energy" element={<CEEnergy />} />
          <Route path="/subsidiaries/heliohm" element={<Heliohm />} />
          
          {/* Fallback to Home */}
          <Route path="*" element={<Home />} />
        </Routes>
      </Router>
    </CMSProvider>
  );
};

export default App;
