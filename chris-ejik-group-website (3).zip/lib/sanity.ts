
// Sanity integration has been removed.
// This file is kept as a placeholder to prevent import errors in any remaining references.

export const client = {
  fetch: async () => [],
  config: () => ({ projectId: null })
};

export function urlFor(source: any) {
  return {
    width: () => ({ url: () => '' })
  };
}
