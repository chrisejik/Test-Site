
export interface Job {
  id: string;
  slug: string;
  title: string;
  department: string;
  location: string;
  type: string;
  description: string;
  responsibilities: string[];
  requirements: string[];
  applyLink: string;
}

export const jobs: Job[] = [
  {
    id: 'driver',
    slug: 'company-driver',
    title: 'Company Driver',
    department: 'Logistics',
    location: 'Lagos, Nigeria',
    type: 'Full-time',
    description: 'We are seeking a reliable and experienced Company Driver to join our team. The ideal candidate will be responsible for transporting staff and goods safely and timely to their destinations while maintaining the highest standards of safety and vehicle care.',
    responsibilities: [
      'Safely transport staff, clients, and goods to designated locations in a timely manner.',
      'Perform routine vehicle checks (oil, water, tires, etc.) and maintain vehicle cleanliness.',
      'Plan routes effectively to avoid traffic and ensure punctuality.',
      'Keep accurate records of vehicle maintenance, fuel consumption, and trips.',
      'Report any vehicle malfunctions or accidents to management immediately.',
      'Adhere to all traffic laws and company transportation policies.'
    ],
    requirements: [
      'Valid Driver’s License and clean driving record.',
      'Minimum of 3-5 years of proven driving experience in a corporate environment.',
      'Excellent knowledge of Lagos road networks and traffic regulations.',
      'Basic mechanical knowledge for minor vehicle troubleshooting.',
      'Good communication skills and professional demeanor.',
      'Ability to work flexible hours when required.'
    ],
    applyLink: 'https://forms.office.com/'
  },
  {
    id: 'cleaner',
    slug: 'office-cleaner',
    title: 'Office Cleaner',
    department: 'Operations',
    location: 'Lagos, Nigeria',
    type: 'Contract',
    description: 'We are looking for a diligent and detail-oriented Office Cleaner to ensure our facilities remain clean, organized, and welcoming. You will play a key role in maintaining a healthy and productive work environment for our staff.',
    responsibilities: [
      'Clean, dust, and mop all office areas, restrooms, hallways, and common areas.',
      'Empty trash bins and transport waste to designated disposal areas.',
      'Restock restroom supplies and breakroom consumables.',
      'Monitor cleaning supplies and notify management when restocking is needed.',
      'Perform deep cleaning tasks and special projects as assigned.',
      'Ensure all cleaning equipment is maintained and stored correctly.'
    ],
    requirements: [
      'Proven experience as a cleaner or housekeeper in a corporate setting.',
      'Knowledge of cleaning chemicals, proper storage, and disposal methods.',
      'Ability to handle heavy cleaning equipment and machinery.',
      'Punctual, reliable, and trustworthy.',
      'Good physical health and stamina.',
      'Ability to follow verbal and written instructions.'
    ],
    applyLink: 'https://forms.office.com/'
  }
];
