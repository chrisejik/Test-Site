
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { jobs } from '../lib/jobs';

const Careers: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('');

  // Filter jobs based on search query and department
  const filteredJobs = jobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          job.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDept = departmentFilter ? job.department.toLowerCase() === departmentFilter.toLowerCase() : true;
    
    return matchesSearch && matchesDept;
  });

  // Get unique departments for filter
  const departments = Array.from(new Set(jobs.map(job => job.department)));

  return (
    <div className="min-h-screen flex flex-col bg-black font-sans text-white">
      <Header />

      <main className="flex-1 pt-20">
        {/* Hero Section */}
        <section className="relative py-24 lg:py-32 overflow-hidden">
          <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1521737604893-d14cc237f11d?q=80&w=2070&auto=format&fit=crop")' }}></div>
          <div className="absolute inset-0 bg-black/80"></div>
          
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold text-white mb-6">
                Join Our <span className="text-red-600">Team</span>
              </h1>
              <p className="text-lg md:text-xl text-neutral-400 leading-relaxed max-w-2xl mx-auto">
                Build your career with Chris-Ejik Group. We're looking for talented individuals who share our passion for excellence and innovation.
              </p>
            </div>
          </div>
        </section>

        {/* Why Join Us Section */}
        <section className="py-20 bg-neutral-900/30 border-y border-neutral-900">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Why Join Us?</h2>
              <p className="text-neutral-400">We invest in our people and provide an environment where you can thrive</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-red-600/30 transition-colors">
                <h3 className="text-lg font-display font-semibold text-white mb-2">Competitive Salary</h3>
                <p className="text-neutral-400 text-sm leading-relaxed">Industry-leading compensation packages with performance bonuses.</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-red-600/30 transition-colors">
                <h3 className="text-lg font-display font-semibold text-white mb-2">Health Insurance</h3>
                <p className="text-neutral-400 text-sm leading-relaxed">Comprehensive medical, dental, and vision coverage for you and your family.</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-red-600/30 transition-colors">
                <h3 className="text-lg font-display font-semibold text-white mb-2">Professional Development</h3>
                <p className="text-neutral-400 text-sm leading-relaxed">Training programs, conferences, and educational support.</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-red-600/30 transition-colors">
                <h3 className="text-lg font-display font-semibold text-white mb-2">Work-Life Balance</h3>
                <p className="text-neutral-400 text-sm leading-relaxed">Flexible working arrangements and generous paid time off.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Open Positions Section */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Open Positions</h2>
              <p className="text-neutral-400">Find your next opportunity with us</p>
            </div>

            <div className="flex flex-col md:flex-row gap-4 mb-8 max-w-4xl mx-auto">
              <div className="relative flex-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-neutral-500">
                  <circle cx="11" cy="11" r="8"></circle>
                  <path d="m21 21-4.3-4.3"></path>
                </svg>
                <input 
                  className="flex h-10 w-full rounded-md border border-neutral-800 bg-neutral-900 px-3 py-2 text-sm text-white placeholder:text-neutral-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-600 focus-visible:border-transparent pl-10" 
                  placeholder="Search jobs..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="relative w-full md:w-48">
                 <select 
                    className="flex h-10 w-full rounded-md border border-neutral-800 bg-neutral-900 px-3 py-2 text-sm text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-600 focus-visible:border-transparent appearance-none"
                    value={departmentFilter}
                    onChange={(e) => setDepartmentFilter(e.target.value)}
                 >
                    <option value="">All Departments</option>
                    {departments.map(dept => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                 </select>
                 <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-down h-4 w-4 text-neutral-500 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" aria-hidden="true"><path d="m6 9 6 6 6-6"></path></svg>
              </div>
            </div>

            <div className="max-w-4xl mx-auto space-y-6">
              {filteredJobs.length > 0 ? (
                filteredJobs.map((job) => (
                  <div key={job.id} className="group bg-neutral-900 border border-neutral-800 rounded-xl p-6 hover:border-red-600/50 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div>
                      <h3 className="text-xl font-bold text-white mb-2 group-hover:text-red-600 transition-colors">{job.title}</h3>
                      <div className="flex flex-wrap gap-3 text-sm text-neutral-400">
                        <span className="flex items-center gap-1.5">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="14" x="2" y="3" rx="2"/><line x1="8" x2="16" y1="21" y2="21"/><line x1="12" x2="12" y1="17" y2="21"/></svg>
                          {job.department}
                        </span>
                        <span className="flex items-center gap-1.5">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/></svg>
                          {job.location}
                        </span>
                        <span className="flex items-center gap-1.5">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                          {job.type}
                        </span>
                      </div>
                    </div>
                    <Link to={`/careers/${job.slug}`} className="shrink-0">
                      <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-10 px-6 bg-white text-black hover:bg-neutral-200 group-hover:bg-red-600 group-hover:text-white">
                        View Role
                      </button>
                    </Link>
                  </div>
                ))
              ) : (
                <div className="text-center py-20 bg-neutral-900 rounded-xl border border-neutral-800">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-black border border-neutral-800 mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-8 h-8 text-neutral-500"><path d="M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path><rect width="20" height="14" x="2" y="6" rx="2"></rect></svg>
                  </div>
                  <p className="text-neutral-400 text-lg">No positions found matching your criteria.</p>
                  <button onClick={() => {setSearchQuery(''); setDepartmentFilter('');}} className="text-red-600 hover:text-red-500 mt-2 text-sm">Clear filters</button>
                </div>
              )}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Careers;
