
import React, { useEffect, useState, useRef } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const AnimatedStat = ({ end, label, suffix = '', prefix = '', className = '' }: { end: number, label: string, suffix?: string, prefix?: string, className?: string }) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          const duration = 2000;
          const start = 0;
          const startTime = performance.now();

          const animate = (currentTime: number) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const easeOut = 1 - Math.pow(1 - progress, 3);
            
            setCount(Math.floor(start + (end - start) * easeOut));

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setCount(end);
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [end]);

  return (
    <div ref={ref} className={className}>
      <p className="font-display text-5xl font-bold text-red-600 mb-2 tabular-nums">
        {prefix}{count}{suffix}
      </p>
      <p className="text-neutral-400 uppercase tracking-wider text-sm">{label}</p>
    </div>
  );
};

const About: React.FC = () => {
  const [flippedIndex, setFlippedIndex] = useState<number | null>(null);

  const handleCardClick = (index: number) => {
    setFlippedIndex(flippedIndex === index ? null : index);
  };

  const leaders = [
    { 
      name: "Prince Nwagboso", 
      role: "Digital Marketer", 
      img: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=800",
      linkedin: "https://linkedin.com/in/princenwagboso",
      bio: "Prince leads our digital strategies, ensuring our brand resonates across all online platforms. With a keen eye for analytics and creative content, he drives engagement and growth for the Chris-Ejik Group."
    },
    { 
      name: "Chief Chris-Ejik", 
      role: "Founder & Chairman", 
      img: "https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&q=80&w=800",
      linkedin: "https://linkedin.com",
      bio: "Visionary leader with over 30 years of experience building successful businesses across multiple industries. Under his leadership, Chris-Ejik Group has grown from a small pharmaceutical company to a diversified conglomerate with operations spanning healthcare, energy, international trade, and engineering."
    },
    { 
      name: "Dr. Amara Okonkwo", 
      role: "CEO, Chris-Ejik Pharmaceuticals", 
      img: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=800",
      linkedin: "https://linkedin.com",
      bio: "Leading pharmaceutical innovation with 20 years of experience in drug development and healthcare. Dr. Okonkwo has overseen the expansion of the pharmaceutical division, introducing new product lines and ensuring compliance with international quality standards."
    },
    { 
      name: "Emmanuel Adeleke", 
      role: "CEO, Chris-Ejik International", 
      img: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=800",
      linkedin: "https://linkedin.com",
      bio: "Expert in international trade and power infrastructure with extensive experience in EPC projects. Emmanuel has led major transmission line constructions and transformer installations across Nigeria."
    },
    { 
      name: "Grace Mwangi", 
      role: "CEO, CE-Energy", 
      img: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=800",
      linkedin: "https://linkedin.com",
      bio: "Energy sector veteran driving sustainable power solutions across the African continent. Grace has been instrumental in expanding CE-Energy's power generation capacity and establishing partnerships with major distribution companies."
    },
    { 
      name: "David Ogundimu", 
      role: "CEO, Heliohm", 
      img: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=800",
      linkedin: "https://linkedin.com",
      bio: "Renewable energy pioneer with a passion for solar technology. David leads Heliohm's mission to bring clean energy to homes and businesses across Africa, having overseen the installation of over 50MW of solar capacity."
    },
    { 
      name: "Chisom Eze", 
      role: "CEO, Chris-Ejik Engineering", 
      img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=800",
      linkedin: "https://linkedin.com",
      bio: "Engineering expert specializing in metering solutions and power infrastructure. Chisom has led the engineering division to become a leading manufacturer of prepaid and smart meters."
    }
  ];

  return (
    <div className="min-h-screen bg-black font-sans text-white overflow-x-hidden">
      <Header />
      
      {/* About Hero */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
         <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=2301')] bg-cover bg-center opacity-30"></div>
         <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/80 to-black"></div>
         
         <div className="container mx-auto px-4 relative z-10 text-center">
            <div className="flex items-center justify-center gap-4 mb-6">
              <div className="w-12 h-[2px] bg-red-600"></div>
              <span className="text-red-600 uppercase tracking-widest text-sm font-medium">Who We Are</span>
              <div className="w-12 h-[2px] bg-red-600"></div>
            </div>
            <h1 className="font-display text-5xl md:text-7xl font-bold text-white mb-8">
               Our <span className="text-red-600">Legacy</span>
            </h1>
            <p className="text-xl text-neutral-300 max-w-3xl mx-auto leading-relaxed">
               For over 30 years, we have been dedicated to improving the quality of life through innovative solutions in healthcare, international trade, energy, and engineering.
            </p>
         </div>
      </section>

      {/* Our Story */}
      <section className="py-24 bg-neutral-900/50">
         <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
               <div>
                  <h2 className="font-display text-4xl font-bold text-white mb-6">Our Story</h2>
                  <div className="space-y-6 text-neutral-400 leading-relaxed">
                     <p>
                        Founded in 1990 by Chief Chris-Ejik, the Chris-Ejik Group began as a small pharmaceutical distribution company with a simple mission: to make quality healthcare accessible to all Nigerians.
                     </p>
                     <p>
                        Over three decades, we have grown into a diversified conglomerate with operations spanning pharmaceuticals, international trade, power infrastructure, renewable energy, and engineering. Our journey has been guided by an unwavering commitment to excellence and a deep-seated desire to improve the quality of life for communities across Africa.
                     </p>
                     <p>
                        Today, the Chris-Ejik Group employs over 1,000 people across multiple subsidiaries, serving millions of customers. We continue to invest in innovation, sustainability, and human development as we work towards a brighter future for all.
                     </p>
                  </div>
               </div>
               <div className="relative">
                  <div className="aspect-[4/3] rounded-2xl overflow-hidden border border-neutral-800">
                     <img 
                        src="https://image2url.com/r2/default/images/1768901749698-cf864e8c-db58-4df7-a152-69c977952cef.jpg" 
                        alt="Office" 
                        className="w-full h-full object-cover"
                     />
                     <div className="absolute inset-0 bg-red-600/10"></div>
                  </div>
                  <div className="absolute -bottom-6 -left-6 bg-black border border-neutral-800 p-8 rounded-xl max-w-xs hidden lg:block">
                     <AnimatedStat end={30} suffix="+" label="Years of Excellence" />
                  </div>
               </div>
            </div>
         </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24 bg-black">
         <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-8">
               <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-10 hover:border-red-600/30 transition-colors group">
                  <div className="w-16 h-16 bg-red-600/10 rounded-xl flex items-center justify-center mb-8 group-hover:bg-red-600/20 transition-colors">
                     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-target w-8 h-8 text-red-600"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>
                  </div>
                  <h3 className="font-display text-3xl font-bold text-white mb-4">Our Mission</h3>
                  <p className="text-neutral-400 leading-relaxed text-lg">
                     To improve the quality of life for communities across Africa and beyond by providing innovative solutions in healthcare, trade, energy, and engineering, while maintaining the highest standards of integrity and excellence.
                  </p>
               </div>
               <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-10 hover:border-red-600/30 transition-colors group">
                  <div className="w-16 h-16 bg-red-600/10 rounded-xl flex items-center justify-center mb-8 group-hover:bg-red-600/20 transition-colors">
                     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-eye w-8 h-8 text-red-600"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                  </div>
                  <h3 className="font-display text-3xl font-bold text-white mb-4">Our Vision</h3>
                  <p className="text-neutral-400 leading-relaxed text-lg">
                     To be Africa's leading conglomerate, recognized globally for our commitment to innovation, sustainability, and positive social impact, creating lasting value for our stakeholders and communities.
                  </p>
               </div>
            </div>
         </div>
      </section>

      {/* Core Values */}
      <section className="py-24 bg-neutral-900/30">
         <div className="container mx-auto px-4">
            <div className="text-center max-w-2xl mx-auto mb-16">
               <h2 className="font-display text-4xl font-bold text-white mb-6">Our Core Values</h2>
               <p className="text-neutral-400 text-lg">The principles that guide everything we do</p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
               <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-red-600/50 transition-colors">
                  <div className="w-12 h-12 bg-red-600/10 rounded-lg flex items-center justify-center mb-4">
                     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-target w-6 h-6 text-red-600">
                        <circle cx="12" cy="12" r="10"></circle>
                        <circle cx="12" cy="12" r="6"></circle>
                        <circle cx="12" cy="12" r="2"></circle>
                     </svg>
                  </div>
                  <h3 className="text-xl font-display font-semibold text-white mb-2">Excellence</h3>
                  <p className="text-neutral-400 text-sm">We strive for excellence in everything we do, setting high standards and continuously improving.</p>
               </div>
               
               <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-red-600/50 transition-colors">
                  <div className="w-12 h-12 bg-red-600/10 rounded-lg flex items-center justify-center mb-4">
                     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-users w-6 h-6 text-red-600">
                        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                     </svg>
                  </div>
                  <h3 className="text-xl font-display font-semibold text-white mb-2">Integrity</h3>
                  <p className="text-neutral-400 text-sm">We conduct our business with honesty, transparency, and ethical principles at all times.</p>
               </div>
               
               <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-red-600/50 transition-colors">
                  <div className="w-12 h-12 bg-red-600/10 rounded-lg flex items-center justify-center mb-4">
                     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-award w-6 h-6 text-red-600">
                        <path d="m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526"></path>
                        <circle cx="12" cy="8" r="6"></circle>
                     </svg>
                  </div>
                  <h3 className="text-xl font-display font-semibold text-white mb-2">Innovation</h3>
                  <p className="text-neutral-400 text-sm">We embrace innovation and creativity to develop solutions that address real-world challenges.</p>
               </div>
               
               <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-red-600/50 transition-colors">
                  <div className="w-12 h-12 bg-red-600/10 rounded-lg flex items-center justify-center mb-4">
                     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-globe w-6 h-6 text-red-600">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"></path>
                        <path d="M2 12h20"></path>
                     </svg>
                  </div>
                  <h3 className="text-xl font-display font-semibold text-white mb-2">Impact</h3>
                  <p className="text-neutral-400 text-sm">We are committed to making a positive impact on communities and the environment.</p>
               </div>
            </div>
         </div>
      </section>

      {/* Timeline */}
      <section className="py-24 bg-black">
         <div className="container mx-auto px-4">
            <div className="text-center max-w-2xl mx-auto mb-16">
               <h2 className="font-display text-4xl font-bold text-white mb-6">Our Journey</h2>
               <p className="text-neutral-400 text-lg">Key milestones in our 30+ year history</p>
            </div>
            <div className="relative max-w-4xl mx-auto">
               <div className="absolute left-[15px] md:left-1/2 top-0 bottom-0 w-px bg-neutral-800 md:-translate-x-1/2"></div>
               {[
                  { year: "1990", title: "Foundation", desc: "Chris-Ejik Group was founded with a vision to improve lives." },
                  { year: "1998", title: "Pharmaceuticals Launch", desc: "Chris-Ejik Pharmaceuticals established to provide quality healthcare." },
                  { year: "2005", title: "International Expansion", desc: "Chris-Ejik International opened to expand global trade operations." },
                  { year: "2012", title: "Energy Sector Entry", desc: "CE-Energy launched to address Africa's energy needs." },
                  { year: "2018", title: "Green Energy Initiative", desc: "Heliohm founded to lead sustainable energy solutions." },
                  { year: "2023", title: "Engineering Division", desc: "Chris-Ejik Engineering established for meter assembly and power solutions." }
               ].map((item, i) => (
                  <div key={i} className={`relative flex items-center gap-8 mb-12 md:justify-between ${i % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}>
                     <div className="absolute left-0 md:left-1/2 w-8 h-8 rounded-full bg-black border-4 border-red-600 z-10 md:-translate-x-1/2"></div>
                     <div className={`pl-12 md:pl-0 w-full md:w-[45%] ${i % 2 === 0 ? 'md:text-right' : 'md:text-left'}`}>
                        <span className="text-red-600 font-display font-bold text-2xl block mb-2">{item.year}</span>
                        <h3 className="text-white font-bold text-xl mb-2">{item.title}</h3>
                        <p className="text-neutral-400">{item.desc}</p>
                     </div>
                     <div className="hidden md:block md:w-[45%]"></div>
                  </div>
               ))}
            </div>
         </div>
      </section>

      {/* Leadership */}
      <section className="py-24 bg-neutral-900/50">
         <div className="container mx-auto px-4">
            <div className="text-center max-w-2xl mx-auto mb-16">
               <h2 className="font-display text-4xl font-bold text-white mb-6">Leadership Team</h2>
               <p className="text-neutral-400 text-lg">Meet the visionaries driving our success.</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
               {leaders.map((leader, i) => (
                  <div 
                    key={i} 
                    className="group perspective-1000 h-[450px] cursor-pointer"
                    onClick={() => handleCardClick(i)}
                  >
                     <div className={`relative w-full h-full transition-transform duration-700 transform-style-3d ${flippedIndex === i ? '[transform:rotateY(180deg)]' : 'group-hover:[transform:rotateY(180deg)]'}`}>
                        {/* Front Face */}
                        <div className="absolute inset-0 backface-hidden bg-card rounded-2xl border border-border overflow-hidden bg-neutral-900 shadow-xl">
                           <div className="h-[70%] w-full overflow-hidden">
                              <img 
                                src={leader.img} 
                                alt={leader.name} 
                                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                              />
                           </div>
                           <div className="h-[30%] p-6 flex flex-col justify-center relative bg-neutral-900 border-t border-neutral-800">
                              <h3 className="text-xl font-display font-bold text-white mb-1">{leader.name}</h3>
                              <div className="text-red-600 text-sm font-medium">{leader.role}</div>
                              
                              {/* Plus Icon */}
                              <div className="absolute top-0 right-6 -translate-y-1/2 w-12 h-12 bg-red-600 rounded-full flex items-center justify-center text-white shadow-lg border-4 border-neutral-900 group-hover:bg-white group-hover:text-red-600 transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-plus"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                              </div>
                           </div>
                        </div>

                        {/* Back Face */}
                        <div className="absolute inset-0 backface-hidden [transform:rotateY(180deg)] bg-red-900/90 backdrop-blur-xl rounded-2xl border border-red-600 overflow-hidden p-8 flex flex-col items-center text-center justify-between">
                           <div className="w-full">
                             <div className="w-20 h-20 rounded-full overflow-hidden border-4 border-white/20 mx-auto mb-6">
                               <img src={leader.img} alt={leader.name} className="w-full h-full object-cover" />
                             </div>
                             <h3 className="text-2xl font-display font-bold text-white mb-2">{leader.name}</h3>
                             <div className="text-red-200 text-sm font-medium mb-6 pb-6 border-b border-white/10">{leader.role}</div>
                             <p className="text-white/90 text-sm leading-relaxed">{leader.bio}</p>
                           </div>
                           
                           <a 
                              href={leader.linkedin} 
                              target="_blank" 
                              rel="noopener noreferrer" 
                              className="inline-flex items-center gap-2 bg-white text-red-900 hover:bg-neutral-100 transition-colors rounded-full px-6 py-3 font-semibold text-sm w-full justify-center"
                              onClick={(e) => e.stopPropagation()}
                           >
                              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-linkedin"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect width="4" height="12" x="2" y="9"></rect><circle cx="4" cy="4" r="2"></circle></svg>
                              View LinkedIn Profile
                           </a>
                        </div>
                     </div>
                  </div>
               ))}
            </div>
         </div>
      </section>

      <Footer />
    </div>
  );
};

export default About;
