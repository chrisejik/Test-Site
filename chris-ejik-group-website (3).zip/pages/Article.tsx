
import React, { useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useCMS } from '../context/CMSContext';

const Article: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { articles } = useCMS();
  
  // Find the article based on the slug from Context
  const article = articles.find(a => a.slug === slug);

  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  if (!article) {
    return (
      <div className="min-h-screen bg-black flex flex-col font-sans text-white">
        <Header />
        <div className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Article Not Found</h1>
            <p className="text-neutral-400 mb-8">The article you are looking for does not exist or has been moved.</p>
            <Link to="/media" className="bg-red-600 text-white px-6 py-3 rounded-md hover:bg-red-700 transition-colors">
              Back to Media Centre
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  // Find related articles (same category, excluding current)
  const relatedArticles = articles
    .filter(a => a.category === article.category && a.slug !== article.slug)
    .slice(0, 2);

  // Helper to render content which might be string (HTML) or ReactNode (Legacy hardcode)
  // For the CMS context, everything is string, so we need to dangerouslySetInnerHTML carefully
  // or simple rendering if it's plain text.
  // Note: In a real app, use a sanitizer like DOMPurify.
  const renderContent = () => {
    // Check if we are rendering the hardcoded legacy JSX (if type was preserved) or string from CMS
    // Since our interface says 'string', we treat it as HTML string from the textarea editor.
    return (
        <div 
            dangerouslySetInnerHTML={{ __html: article.content }} 
            className="prose prose-invert prose-lg max-w-none [&>h3]:text-2xl [&>h3]:font-bold [&>h3]:text-white [&>h3]:mb-4 [&>h3]:mt-8 [&>p]:text-neutral-400 [&>p]:mb-6 [&>p]:leading-relaxed [&>figure]:my-10 [&>figure>div]:rounded-lg [&>figure>div]:overflow-hidden [&>figure>figcaption]:text-center [&>figure>figcaption]:text-neutral-500 [&>figure>figcaption]:text-xs [&>figure>figcaption]:mt-2 [&>figure>figcaption]:italic"
        />
    );
  };

  return (
    <div className="min-h-screen bg-black flex flex-col font-sans text-white">
      <Header />
      
      <main className="flex-grow pt-20">
        {/* Article Hero */}
        <div className="relative h-[60vh] min-h-[400px] w-full overflow-hidden">
          <div className="absolute inset-0">
            <img 
              src={article.image} 
              alt={article.title} 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 p-8 lg:p-16 container mx-auto">
            <div className="max-w-4xl">
              <div className="flex items-center gap-4 mb-4">
                <span className="bg-red-600 text-white px-3 py-1 text-xs font-bold uppercase tracking-widest rounded-sm">
                  {article.category}
                </span>
                <span className="text-neutral-300 text-sm flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-calendar"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/></svg>
                  {article.date}
                </span>
              </div>
              <h1 className="text-3xl md:text-5xl lg:text-6xl font-display font-bold text-white leading-tight mb-4">
                {article.title}
              </h1>
              {article.author && (
                <p className="text-neutral-400 text-sm">By <span className="text-white font-medium">{article.author}</span></p>
              )}
            </div>
          </div>
        </div>

        {/* Article Content */}
        <article className="container mx-auto px-4 py-16">
          <div className="grid lg:grid-cols-12 gap-12">
            {/* Main Content Column */}
            <div className="lg:col-span-8">
              {renderContent()}
              
              {/* Share/Tags Section (Optional) */}
              <div className="mt-12 pt-8 border-t border-neutral-800 flex justify-between items-center">
                <div className="text-neutral-500 text-sm">
                  Share this article
                </div>
                <div className="flex gap-4">
                  <button className="w-10 h-10 rounded-full bg-neutral-900 flex items-center justify-center text-neutral-400 hover:text-white hover:bg-blue-600 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                  </button>
                  <button className="w-10 h-10 rounded-full bg-neutral-900 flex items-center justify-center text-neutral-400 hover:text-white hover:bg-blue-400 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/></svg>
                  </button>
                  <button className="w-10 h-10 rounded-full bg-neutral-900 flex items-center justify-center text-neutral-400 hover:text-white hover:bg-blue-700 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect width="4" height="12" x="2" y="9"/><circle cx="4" cy="4" r="2"/></svg>
                  </button>
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-4 space-y-12">
              {/* Related Articles */}
              {relatedArticles.length > 0 && (
                <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6">
                  <h3 className="font-display font-bold text-xl text-white mb-6">Related {article.category}</h3>
                  <div className="space-y-6">
                    {relatedArticles.map((related) => (
                      <Link key={related.slug} to={`/media/${related.slug}`} className="group block">
                        <div className="aspect-video rounded-lg overflow-hidden mb-3">
                          <img 
                            src={related.image} 
                            alt={related.title} 
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                          />
                        </div>
                        <h4 className="font-semibold text-white group-hover:text-red-600 transition-colors line-clamp-2">
                          {related.title}
                        </h4>
                        <p className="text-neutral-500 text-xs mt-2">{related.date}</p>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Newsletter CTA */}
              <div className="bg-red-600/10 border border-red-600/20 rounded-xl p-6">
                <h3 className="font-display font-bold text-xl text-white mb-2">Stay Updated</h3>
                <p className="text-neutral-400 text-sm mb-4">Get the latest news and insights from Chris-Ejik Group delivered to your inbox.</p>
                <form className="space-y-2">
                  <input 
                    type="email" 
                    placeholder="Your email address" 
                    className="w-full bg-black border border-neutral-800 rounded-md px-3 py-2 text-sm text-white focus:outline-none focus:border-red-600"
                  />
                  <button className="w-full bg-red-600 text-white rounded-md px-3 py-2 text-sm font-medium hover:bg-red-700 transition-colors">
                    Subscribe
                  </button>
                </form>
              </div>
            </div>
          </div>
        </article>
      </main>

      <Footer />
    </div>
  );
};

export default Article;
