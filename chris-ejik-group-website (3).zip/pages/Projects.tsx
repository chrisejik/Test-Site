
import React, { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';

const AnimatedStat = ({ end, label, suffix = '' }: { end: number, label: string, suffix?: string }) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          const duration = 2000;
          const start = 0;
          const startTime = performance.now();

          const animate = (currentTime: number) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const easeOut = 1 - Math.pow(1 - progress, 3);
            
            setCount(Math.floor(start + (end - start) * easeOut));

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setCount(end);
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [end]);

  return (
    <div ref={ref} className="text-center">
      <div className="text-4xl md:text-5xl font-display font-bold text-red-600 mb-2 tabular-nums">
        {count}{suffix}
      </div>
      <div className="text-neutral-400 uppercase tracking-wider text-sm">{label}</div>
    </div>
  );
};

const Projects: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col bg-black font-sans text-white">
      <Header />

      <main className="flex-1 pt-20">
        {/* Hero Section */}
        <section className="relative py-24 lg:py-32 overflow-hidden">
          {/* Dark gradient background */}
          <div className="absolute inset-0 bg-gradient-to-b from-red-900/20 to-transparent pointer-events-none"></div>
          
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <div className="flex items-center justify-center gap-4 mb-6">
                 <div className="w-12 h-[2px] bg-red-600"></div>
                 <span className="text-red-600 uppercase tracking-widest text-sm font-medium">What We Do</span>
                 <div className="w-12 h-[2px] bg-red-600"></div>
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold text-white mb-6">
                Our <span className="text-red-600">Subsidiaries</span>
              </h1>
              <p className="text-lg md:text-xl text-neutral-400 leading-relaxed max-w-2xl mx-auto">
                The Chris Ejik Group operates through strategic subsidiaries, each focused on delivering excellence and innovation in their respective industries.
              </p>
            </div>
          </div>
        </section>

        {/* Subsidiaries List */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="space-y-24">
              
              {/* Item 1 - Pharmaceuticals */}
              <div className="flex flex-col lg:flex-row gap-16 items-center">
                <div className="flex-1 w-full">
                  <div className="aspect-[4/3] rounded-2xl border border-neutral-800 flex items-center justify-center relative overflow-hidden group hover:border-red-600/50 transition-colors duration-500">
                    <img 
                      src="https://images.unsplash.com/photo-1631549916768-4119b2e5f926?auto=format&fit=crop&q=80&w=800" 
                      alt="Chris Ejik Pharmaceuticals" 
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-80 group-hover:opacity-100" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent pointer-events-none"></div>
                    <div className="absolute top-6 left-6 bg-black/50 backdrop-blur-md border border-white/10 rounded-full px-4 py-2 z-10">
                      <span className="text-sm font-medium text-white">01</span>
                    </div>
                  </div>
                </div>
                <div className="flex-1 space-y-8">
                  <div>
                    <span className="text-red-600 text-sm font-medium uppercase tracking-wider">Healthcare Excellence</span>
                    <h2 className="text-3xl md:text-4xl font-display font-bold text-white mt-3">Chris Ejik Pharmaceuticals</h2>
                  </div>
                  <p className="text-neutral-400 leading-relaxed text-lg">
                    A leading pharmaceutical company providing quality healthcare solutions across Africa. We manufacture, import, and distribute essential medicines and medical supplies, ensuring accessibility and affordability for all.
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <Link to="/subsidiaries/pharmaceuticals">
                      <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 h-11 px-8 py-2 gap-2 bg-red-600 text-white hover:bg-red-700">
                        Learn More 
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                      </button>
                    </Link>
                  </div>
                </div>
              </div>

              {/* Item 2 - International */}
              <div className="flex flex-col lg:flex-row-reverse gap-16 items-center">
                <div className="flex-1 w-full">
                  <div className="aspect-[4/3] rounded-2xl border border-neutral-800 flex items-center justify-center relative overflow-hidden group hover:border-red-600/50 transition-colors duration-500">
                    <img 
                      src="https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&q=80&w=800" 
                      alt="Chris Ejik International" 
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-80 group-hover:opacity-100" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent pointer-events-none"></div>
                    <div className="absolute top-6 left-6 bg-black/50 backdrop-blur-md border border-white/10 rounded-full px-4 py-2 z-10">
                      <span className="text-sm font-medium text-white">02</span>
                    </div>
                  </div>
                </div>
                <div className="flex-1 space-y-8">
                  <div>
                    <span className="text-red-600 text-sm font-medium uppercase tracking-wider">Global Trade Solutions</span>
                    <h2 className="text-3xl md:text-4xl font-display font-bold text-white mt-3">Chris Ejik International</h2>
                  </div>
                  <p className="text-neutral-400 leading-relaxed text-lg">
                    An international trading company facilitating seamless import and export of goods across continents. We connect African markets to the global economy through strategic partnerships and efficient logistics.
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <Link to="/subsidiaries/international">
                      <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 h-11 px-8 py-2 gap-2 bg-red-600 text-white hover:bg-red-700">
                        Learn More 
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                      </button>
                    </Link>
                  </div>
                </div>
              </div>

              {/* Item 3 - Engineering */}
              <div className="flex flex-col lg:flex-row gap-16 items-center">
                <div className="flex-1 w-full">
                  <div className="aspect-[4/3] rounded-2xl border border-neutral-800 flex items-center justify-center relative overflow-hidden group hover:border-red-600/50 transition-colors duration-500">
                    <img 
                      src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=800" 
                      alt="Chris Ejik Engineering" 
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-80 group-hover:opacity-100" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent pointer-events-none"></div>
                    <div className="absolute top-6 left-6 bg-black/50 backdrop-blur-md border border-white/10 rounded-full px-4 py-2 z-10">
                      <span className="text-sm font-medium text-white">03</span>
                    </div>
                  </div>
                </div>
                <div className="flex-1 space-y-8">
                  <div>
                    <span className="text-red-600 text-sm font-medium uppercase tracking-wider">Metering &amp; Power Solutions</span>
                    <h2 className="text-3xl md:text-4xl font-display font-bold text-white mt-3">Chris Ejik Engineering</h2>
                  </div>
                  <p className="text-neutral-400 leading-relaxed text-lg">
                    An engineering company providing end-to-end metering and power infrastructure solutions. We support Nigeria's electricity supply industry with reliable prepaid and smart meters, ensuring accurate billing and energy management.
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <Link to="/subsidiaries/engineering">
                      <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 h-11 px-8 py-2 gap-2 bg-red-600 text-white hover:bg-red-700">
                        Learn More 
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                      </button>
                    </Link>
                  </div>
                </div>
              </div>

              {/* Item 4 - CE-Energy */}
              <div className="flex flex-col lg:flex-row-reverse gap-16 items-center">
                <div className="flex-1 w-full">
                  <div className="aspect-[4/3] rounded-2xl border border-neutral-800 flex items-center justify-center relative overflow-hidden group hover:border-red-600/50 transition-colors duration-500">
                    <img 
                      src="https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&q=80&w=800" 
                      alt="CE-Energy" 
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-80 group-hover:opacity-100" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent pointer-events-none"></div>
                    <div className="absolute top-6 left-6 bg-black/50 backdrop-blur-md border border-white/10 rounded-full px-4 py-2 z-10">
                      <span className="text-sm font-medium text-white">04</span>
                    </div>
                  </div>
                </div>
                <div className="flex-1 space-y-8">
                  <div>
                    <span className="text-red-600 text-sm font-medium uppercase tracking-wider">Powering Africa Forward</span>
                    <h2 className="text-3xl md:text-4xl font-display font-bold text-white mt-3">CE-Energy</h2>
                  </div>
                  <p className="text-neutral-400 leading-relaxed text-lg">
                    An energy solutions company addressing Africa's power needs through reliable infrastructure, power generation, and distribution services. We are committed to lighting up communities and powering industries.
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <Link to="/subsidiaries/ce-energy">
                      <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 h-11 px-8 py-2 gap-2 bg-red-600 text-white hover:bg-red-700">
                        Learn More 
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                      </button>
                    </Link>
                    <a href="https://ce-energy.com" target="_blank" rel="noopener noreferrer">
                      <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 h-11 px-8 py-2 gap-2 border border-neutral-700 bg-transparent text-white hover:bg-neutral-800">
                        Visit Website 
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                      </button>
                    </a>
                  </div>
                </div>
              </div>

              {/* Item 5 - Heliohm */}
              <div className="flex flex-col lg:flex-row gap-16 items-center">
                <div className="flex-1 w-full">
                  <div className="aspect-[4/3] rounded-2xl border border-neutral-800 flex items-center justify-center relative overflow-hidden group hover:border-red-600/50 transition-colors duration-500">
                    <img 
                      src="https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&q=80&w=800" 
                      alt="Heliohm" 
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-80 group-hover:opacity-100" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent pointer-events-none"></div>
                    <div className="absolute top-6 left-6 bg-black/50 backdrop-blur-md border border-white/10 rounded-full px-4 py-2 z-10">
                      <span className="text-sm font-medium text-white">05</span>
                    </div>
                  </div>
                </div>
                <div className="flex-1 space-y-8">
                  <div>
                    <span className="text-red-600 text-sm font-medium uppercase tracking-wider">Sustainable Energy Future</span>
                    <h2 className="text-3xl md:text-4xl font-display font-bold text-white mt-3">Heliohm</h2>
                  </div>
                  <p className="text-neutral-400 leading-relaxed text-lg">
                    A renewable energy company pioneering solar and clean energy solutions for homes, businesses, and communities. We are driving the transition to a sustainable, low-carbon future.
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <Link to="/subsidiaries/heliohm">
                      <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 h-11 px-8 py-2 gap-2 bg-red-600 text-white hover:bg-red-700">
                        Learn More 
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                      </button>
                    </Link>
                    <a href="https://heliohm.com" target="_blank" rel="noopener noreferrer">
                      <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 h-11 px-8 py-2 gap-2 border border-neutral-700 bg-transparent text-white hover:bg-neutral-800">
                        Visit Website 
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                      </button>
                    </a>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-20 bg-neutral-900/30 border-t border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
              <AnimatedStat end={5} label="Subsidiaries" />
              <AnimatedStat end={5} suffix="K+" label="Employees" />
              <AnimatedStat end={15} suffix="+" label="Countries" />
              <AnimatedStat end={30} suffix="+" label="Years" />
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Projects;
