
import React, { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { jobs } from '../lib/jobs';

const JobDetail: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const job = jobs.find(j => j.slug === slug);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  if (!job) {
    return (
      <div className="min-h-screen bg-black flex flex-col font-sans text-white">
        <Header />
        <div className="flex-grow flex items-center justify-center pt-20">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Job Not Found</h1>
            <Link to="/careers" className="text-red-600 hover:text-white transition-colors">Back to Careers</Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex flex-col font-sans text-white">
      <Header />
      <main className="flex-grow pt-20">
        <section className="relative py-20 bg-neutral-900 border-b border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <Link to="/careers" className="inline-flex items-center gap-2 text-neutral-400 hover:text-white mb-8 transition-colors text-sm">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-left"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>
                Back to Open Positions
              </Link>
              <div className="flex flex-wrap items-center gap-4 mb-4 text-sm font-medium">
                <span className="bg-red-600/10 text-red-500 px-3 py-1 rounded-full border border-red-600/20">{job.department}</span>
                <span className="bg-neutral-800 text-neutral-300 px-3 py-1 rounded-full border border-neutral-700">{job.type}</span>
                <span className="flex items-center gap-1 text-neutral-400">
                   <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/></svg>
                   {job.location}
                </span>
              </div>
              <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-8">{job.title}</h1>
              <a href={job.applyLink} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-11 px-8 bg-red-600 text-white hover:bg-red-700">
                Apply Now
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-2"><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>
              </a>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto space-y-12">
              <div>
                <h3 className="text-2xl font-display font-bold text-white mb-4">About the Role</h3>
                <p className="text-neutral-400 leading-relaxed text-lg">{job.description}</p>
              </div>
              
              <div>
                <h3 className="text-2xl font-display font-bold text-white mb-4">Responsibilities</h3>
                <ul className="space-y-3">
                  {job.responsibilities.map((item, i) => (
                    <li key={i} className="flex items-start gap-3 text-neutral-400">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-600 shrink-0 mt-1"><path d="M20 6 9 17l-5-5"/></svg>
                      <span className="leading-relaxed">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="text-2xl font-display font-bold text-white mb-4">Requirements</h3>
                <ul className="space-y-3">
                  {job.requirements.map((item, i) => (
                    <li key={i} className="flex items-start gap-3 text-neutral-400">
                      <div className="w-1.5 h-1.5 rounded-full bg-red-600 shrink-0 mt-2.5"></div>
                      <span className="leading-relaxed">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-8 border-t border-neutral-800">
                <h3 className="text-xl font-display font-bold text-white mb-6">Ready to Apply?</h3>
                <a href={job.applyLink} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-11 px-8 bg-white text-black hover:bg-neutral-200">
                  Fill Application Form
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default JobDetail;
