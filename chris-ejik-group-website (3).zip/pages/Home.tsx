
import React from 'react';
import Header from '../components/Header';
import Hero from '../components/Hero';
import Stats from '../components/Stats';
import About from '../components/About';
import Subsidiaries from '../components/Subsidiaries';
import Partners from '../components/Partners';
import MediaCentre from '../components/MediaCentre';
import CareersCTA from '../components/CareersCTA';
import Footer from '../components/Footer';

const Home: React.FC = () => {
  return (
    <div className="min-h-screen bg-black font-sans text-white overflow-x-hidden">
      <div className="relative">
        <Header />
        <Hero />
      </div>
      
      <main>
        <Stats />
        <About />
        <Subsidiaries />
        <Partners />
        <MediaCentre />
        <CareersCTA />
      </main>

      <Footer />
    </div>
  );
};

export default Home;
