
import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useCMS } from '../context/CMSContext';

const MediaCentre: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'news' | 'insights'>('news');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Use data from CMS Context
  const { articles } = useCMS();

  useEffect(() => {
    if (location.pathname.includes('/media/insights')) {
      setActiveTab('insights');
    } else {
      setActiveTab('news');
    }
  }, [location]);

  const handleTabChange = (tab: 'news' | 'insights') => {
    setActiveTab(tab);
    navigate(`/media/${tab}`);
  };

  // Filter articles based on Tab and Search
  const currentArticles = articles.filter(article => {
    // 1. Filter by category (Case insensitive check because tab is lowercase)
    const matchesCategory = article.category.toLowerCase() === activeTab;
    
    // 2. Filter by search query
    const matchesSearch = 
      article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.excerpt.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen flex flex-col bg-black font-sans text-white">
      <Header />

      <main className="flex-1 pt-20">
        {/* Hero Section */}
        <section className="relative py-24 lg:py-32 overflow-hidden">
          <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1504711434969-e33886168f5c?q=80&w=2070&auto=format&fit=crop")' }}></div>
          <div className="absolute inset-0 bg-black/80"></div>
          
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold text-white mb-6">
                Media <span className="text-red-600">Centre</span>
              </h1>
              <p className="text-lg md:text-xl text-neutral-400 leading-relaxed max-w-2xl mx-auto">
                Stay updated with the latest news, insights, and announcements from Chris-Ejik Group and our subsidiaries.
              </p>
            </div>
          </div>
        </section>

        {/* Content Section */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="w-full">
              {/* Controls */}
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
                
                {/* Tabs */}
                <div className="inline-flex h-10 items-center justify-center rounded-md p-1 bg-neutral-900 border border-neutral-800">
                  <button 
                    onClick={() => handleTabChange('news')}
                    className={`inline-flex items-center justify-center whitespace-nowrap rounded-sm px-6 py-1.5 text-sm font-medium transition-all ${activeTab === 'news' ? 'bg-red-600 text-white shadow-sm' : 'text-neutral-400 hover:text-white'}`}
                  >
                    News
                  </button>
                  <button 
                    onClick={() => handleTabChange('insights')}
                    className={`inline-flex items-center justify-center whitespace-nowrap rounded-sm px-6 py-1.5 text-sm font-medium transition-all ${activeTab === 'insights' ? 'bg-red-600 text-white shadow-sm' : 'text-neutral-400 hover:text-white'}`}
                  >
                    Insights
                  </button>
                </div>

                {/* Search */}
                <div className="relative w-full md:w-80">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-neutral-500">
                    <circle cx="11" cy="11" r="8" />
                    <path d="m21 21-4.3-4.3" />
                  </svg>
                  <input 
                    className="flex h-10 w-full rounded-md border border-neutral-800 bg-neutral-900 px-3 py-2 text-sm text-white placeholder:text-neutral-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-600 focus-visible:border-transparent pl-10" 
                    placeholder="Search articles..." 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>

              {/* Grid */}
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {currentArticles.length > 0 ? (
                  currentArticles.map((article) => (
                    <div key={article.id} className="group flex flex-col bg-neutral-900 border border-neutral-800 rounded-lg overflow-hidden hover:border-red-600/50 transition-colors">
                      <Link to={`/media/${article.slug}`} className="block overflow-hidden relative aspect-video">
                        <img 
                          src={article.image} 
                          alt={article.title} 
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60"></div>
                      </Link>
                      <div className="p-6 flex-1 flex flex-col">
                        <div className="flex items-center justify-between mb-4">
                            <span className="text-red-600 text-xs font-bold uppercase tracking-wider">{article.category}</span>
                            <span className="text-neutral-500 text-xs flex items-center gap-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-3 h-3">
                                  <path d="M8 2v4" />
                                  <path d="M16 2v4" />
                                  <rect width="18" height="18" x="3" y="4" rx="2" />
                                  <path d="M3 10h18" />
                                </svg>
                                {article.date}
                            </span>
                        </div>
                        <Link to={`/media/${article.slug}`}>
                          <h3 className="text-xl font-display font-bold text-white mb-3 group-hover:text-red-600 transition-colors line-clamp-2">
                            {article.title}
                          </h3>
                        </Link>
                        <p className="text-neutral-400 text-sm leading-relaxed mb-6 line-clamp-3">
                          {article.excerpt}
                        </p>
                        <div className="mt-auto">
                           <Link to={`/media/${article.slug}`} className="text-white text-sm font-medium flex items-center gap-2 group-hover:text-red-600 transition-colors">
                             Read Article 
                             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4 transition-transform group-hover:translate-x-1"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg>
                           </Link>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="col-span-full text-center py-20">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-neutral-900 border border-neutral-800 mb-4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-8 h-8 text-neutral-500"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" /></svg>
                    </div>
                    <p className="text-neutral-400 text-lg">No articles found matching "{searchQuery}".</p>
                    <button 
                        onClick={() => setSearchQuery('')}
                        className="mt-4 text-red-600 hover:text-red-500 font-medium text-sm"
                    >
                        Clear search
                    </button>
                  </div>
                )}
              </div>

            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default MediaCentre;
