
import React from 'react';
import { Link } from 'react-router-dom';

const Admin: React.FC = () => {
  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-800 p-8 rounded-xl max-w-2xl w-full text-center">
        <h1 className="text-3xl font-display font-bold mb-4">Admin Panel</h1>
        <p className="text-neutral-400 mb-8">
          The administration panel has been disabled as Sanity integration is no longer active. 
          Content is currently served statically.
        </p>
        <Link to="/" className="inline-block bg-red-600 text-white font-medium px-6 py-3 rounded-md hover:bg-red-700 transition-colors">
          Return to Home
        </Link>
      </div>
    </div>
  );
};

export default Admin;
