
import React, { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import InternationalHeader from '../../components/InternationalHeader';
import InternationalFooter from '../../components/InternationalFooter';

const AnimatedStat = ({ end, label, suffix = '', prefix = '' }: { end: number, label: string, suffix?: string, prefix?: string }) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          const duration = 2000;
          const start = 0;
          const startTime = performance.now();

          const animate = (currentTime: number) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const easeOut = 1 - Math.pow(1 - progress, 3);
            
            setCount(Math.floor(start + (end - start) * easeOut));

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setCount(end);
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [end]);

  return (
    <div ref={ref} className="p-4">
      <div className="text-4xl font-display font-bold text-neutral-400 mb-1 tabular-nums">
        {prefix}{count}{suffix}
      </div>
      <div className="text-neutral-500 text-sm uppercase tracking-wider">{label}</div>
    </div>
  );
};

const International: React.FC = () => {
  // Using placeholder logos for international partners
  const partners = [
    'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Google_2015_logo.svg/2560px-Google_2015_logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/2560px-Amazon_logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/IBM_logo.svg/2560px-IBM_logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Tata_Consultancy_Services_Logo.svg/2560px-Tata_Consultancy_Services_Logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Cisco_logo_blue_2016.svg/2560px-Cisco_logo_blue_2016.svg.png'
  ];

  return (
    <div className="bg-black text-white font-sans">
      <InternationalHeader />
      
      <main className="flex-grow pt-20">
        {/* Hero Section */}
        <section className="relative py-24 lg:py-32 overflow-hidden">
          <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?q=80&w=2070&auto=format&fit=crop")' }}></div>
          <div className="absolute inset-0 bg-black/70"></div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl">
              <div className="inline-flex items-center gap-2 bg-neutral-800/80 text-neutral-300 px-4 py-2 rounded-full text-sm font-medium mb-6 border border-neutral-700">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-4 h-4"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>
                Power Infrastructure Solutions
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold text-white mb-6">
                Chris-Ejik <span className="text-neutral-400">International</span>
              </h1>
              <p className="text-lg md:text-xl text-neutral-300 leading-relaxed mb-4">
                Chris Ejik International is a leading service provider in the Nigerian Electricity Supply Industry. In the last 35 years, we have proffered solutions and executed Engineering, Procurement, and Construction (EPC) projects of varying complexities.
              </p>
              <p className="text-neutral-400 mb-8 max-w-2xl">
                We help our clients meet their strategic objectives and have built expertise as a major constructor of transmission lines (up to 330KV), procurement, sales distribution, and power transformers.
              </p>
              <div className="flex gap-4">
                <Link to="/subsidiaries/international/services">
                  <button className="inline-flex items-center justify-center whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-black h-11 rounded-md px-8 bg-white hover:bg-neutral-200 gap-2">
                    Our Services
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                  </button>
                </Link>
                <Link to="/contact">
                  <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-neutral-600 bg-transparent hover:bg-neutral-800 text-white h-11 rounded-md px-8">
                    Contact Us
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-12 bg-neutral-900 border-y border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
              <AnimatedStat end={35} suffix="+" label="Years Experience" />
              <AnimatedStat end={100} suffix="+" label="EPC Projects" />
              <AnimatedStat end={330} suffix="KV" label="Transmission Lines" />
              <AnimatedStat end={500} suffix="+" label="Engineers" />
            </div>
          </div>
        </section>

        {/* About / Mission */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-6">Powering Infrastructure</h2>
                <p className="text-neutral-400 leading-relaxed mb-6">
                  At Chris-Ejik International, we understand the complexities of the power sector. From conceptualisation and design, engineering, consultancy, and project management, we handle every step with precision.
                </p>
                <p className="text-neutral-400 leading-relaxed mb-8">
                  Our deep understanding of the Nigerian regulatory landscape, combined with our strong relationships with international manufacturers, allows us to deliver world-class infrastructure projects efficiently and reliably.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex items-center gap-3 text-neutral-300">
                    <div className="w-8 h-8 rounded-full bg-neutral-800 flex items-center justify-center border border-neutral-700">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check w-4 h-4 text-neutral-400"><path d="M20 6 9 17l-5-5"/></svg>
                    </div>
                    <span>EPC Services</span>
                  </div>
                  <div className="flex items-center gap-3 text-neutral-300">
                    <div className="w-8 h-8 rounded-full bg-neutral-800 flex items-center justify-center border border-neutral-700">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check w-4 h-4 text-neutral-400"><path d="M20 6 9 17l-5-5"/></svg>
                    </div>
                    <span>Power Transformers</span>
                  </div>
                  <div className="flex items-center gap-3 text-neutral-300">
                    <div className="w-8 h-8 rounded-full bg-neutral-800 flex items-center justify-center border border-neutral-700">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check w-4 h-4 text-neutral-400"><path d="M20 6 9 17l-5-5"/></svg>
                    </div>
                    <span>Transmission Lines</span>
                  </div>
                  <div className="flex items-center gap-3 text-neutral-300">
                    <div className="w-8 h-8 rounded-full bg-neutral-800 flex items-center justify-center border border-neutral-700">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check w-4 h-4 text-neutral-400"><path d="M20 6 9 17l-5-5"/></svg>
                    </div>
                    <span>Engineering Design</span>
                  </div>
                </div>
              </div>
              <div className="relative">
                <div className="aspect-square rounded-2xl overflow-hidden border border-neutral-800 grayscale hover:grayscale-0 transition-all duration-700">
                   <img src="https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&q=80&w=2070" alt="Power Infrastructure" className="w-full h-full object-cover" />
                </div>
                <div className="absolute -bottom-6 -left-6 bg-neutral-800 p-6 rounded-xl border border-neutral-700 shadow-xl max-w-xs">
                   <p className="text-white font-medium mb-1">"Integrity in every project."</p>
                   <p className="text-neutral-500 text-sm">— Management</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Services Summary Section */}
        <section id="services" className="py-24 bg-neutral-900/30">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Our Core Services</h2>
              <p className="text-neutral-400">Delivering value through comprehensive engineering solutions.</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              {/* Service 1 */}
              <div className="bg-black rounded-xl p-8 border border-neutral-800 hover:border-neutral-500 transition-colors group">
                <div className="w-14 h-14 bg-neutral-900 rounded-lg flex items-center justify-center mb-6 group-hover:bg-neutral-800 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-wrench w-7 h-7 text-neutral-400 group-hover:text-white"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path></svg>
                </div>
                <h3 className="text-xl font-display font-bold text-white mb-4">Procurement & E.P.C</h3>
                <p className="text-neutral-400 leading-relaxed text-sm">
                  End-to-end engineering, procurement, and construction services for power infrastructure projects of any scale.
                </p>
              </div>

              {/* Service 2 */}
              <div className="bg-black rounded-xl p-8 border border-neutral-800 hover:border-neutral-500 transition-colors group">
                <div className="w-14 h-14 bg-neutral-900 rounded-lg flex items-center justify-center mb-6 group-hover:bg-neutral-800 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-7 h-7 text-neutral-400 group-hover:text-white"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>
                </div>
                <h3 className="text-xl font-display font-bold text-white mb-4">Transformer Sales</h3>
                <p className="text-neutral-400 leading-relaxed text-sm">
                  Power/Distribution Transformers. Online Mobile Transformer Oil Filtration and Regeneration.
                </p>
              </div>

              {/* Service 3 */}
              <div className="bg-black rounded-xl p-8 border border-neutral-800 hover:border-neutral-500 transition-colors group">
                <div className="w-14 h-14 bg-neutral-900 rounded-lg flex items-center justify-center mb-6 group-hover:bg-neutral-800 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-building2 w-7 h-7 text-neutral-400 group-hover:text-white"><path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"></path><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"></path><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"></path><path d="M10 6h4"></path><path d="M10 10h4"></path><path d="M10 14h4"></path><path d="M10 18h4"></path></svg>
                </div>
                <h3 className="text-xl font-display font-bold text-white mb-4">Transmission Lines</h3>
                <p className="text-neutral-400 leading-relaxed text-sm">
                  Construction of Transmission Lines up to 330KV and Transmission Substations up to 330KV.
                </p>
              </div>
            </div>
            
            <div className="text-center mt-12">
              <Link to="/subsidiaries/international/services">
                <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-neutral-700 bg-transparent hover:bg-neutral-800 text-white h-11 rounded-md px-8">
                  View All Services
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                </button>
              </Link>
            </div>
          </div>
        </section>

        {/* Partners Marquee */}
        <section id="partners" className="py-20 bg-neutral-900 overflow-hidden">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Our Partners</h2>
              <p className="text-neutral-400">We collaborate with leading organizations in the power sector</p>
            </div>
          </div>
          <div className="relative overflow-hidden py-4 w-full">
            <div className="flex animate-marquee whitespace-nowrap items-center">
              {partners.map((logo, i) => (
                <div key={i} className="mx-12 w-48 h-24 flex items-center justify-center flex-shrink-0 grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all duration-500">
                  <img src={logo} alt="Partner Logo" className="max-w-full max-h-full object-contain" />
                </div>
              ))}
              {partners.map((logo, i) => (
                <div key={`dup-${i}`} className="mx-12 w-48 h-24 flex items-center justify-center flex-shrink-0 grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all duration-500">
                  <img src={logo} alt="Partner Logo" className="max-w-full max-h-full object-contain" />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-24">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-16">
              <div className="space-y-12">
                <div className="flex gap-6">
                  <div className="w-12 h-12 rounded-full bg-neutral-800 flex items-center justify-center shrink-0 border border-neutral-700">
                    <span className="font-bold text-neutral-400">01</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">Passion & Professionalism</h3>
                    <p className="text-neutral-400">Our passion for work and our client stems from a strong desire to add value to our society through our clients.</p>
                  </div>
                </div>
                <div className="flex gap-6">
                  <div className="w-12 h-12 rounded-full bg-neutral-800 flex items-center justify-center shrink-0 border border-neutral-700">
                    <span className="font-bold text-neutral-400">02</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">Smart-Work</h3>
                    <p className="text-neutral-400">We don't just work hard but we work Smart. Working smart means working strategically, thus effectively meeting our clients' needs.</p>
                  </div>
                </div>
                <div className="flex gap-6">
                  <div className="w-12 h-12 rounded-full bg-neutral-800 flex items-center justify-center shrink-0 border border-neutral-700">
                    <span className="font-bold text-neutral-400">03</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">Excellence</h3>
                    <p className="text-neutral-400">We strive to maintain world class standards in all our engagements with our stakeholders.</p>
                  </div>
                </div>
              </div>
              <div className="relative">
                 <div className="absolute top-0 right-0 w-32 h-32 bg-neutral-700/20 rounded-full blur-3xl"></div>
                 <div className="bg-neutral-900 border border-neutral-800 p-8 rounded-2xl">
                    <h3 className="text-2xl font-display font-bold text-white mb-6">Why Partner With Us?</h3>
                    <p className="text-neutral-400 mb-6">
                      We have served major distribution and generation companies in Nigeria, government agencies, state governments, local municipalities, and private companies.
                    </p>
                    <ul className="space-y-4 text-neutral-300">
                      <li className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-neutral-500 rounded-full"></div>
                        NERC Licensed
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-neutral-500 rounded-full"></div>
                        ISO Certified Processes
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-neutral-500 rounded-full"></div>
                        Local Content Compliant
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-neutral-500 rounded-full"></div>
                        Proven Track Record
                      </li>
                    </ul>
                 </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-neutral-900 border-t border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="bg-gradient-to-r from-neutral-800 to-neutral-900 rounded-2xl p-12 text-center border border-neutral-700">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Power Your Projects With Us</h2>
              <p className="text-neutral-400 max-w-2xl mx-auto mb-8">
                Ready to take on your next power infrastructure project? Let us help you deliver with our expertise and proven track record.
              </p>
              <div className="flex justify-center">
                <Link to="/contact">
                  <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-black h-11 rounded-md px-8 bg-white hover:bg-neutral-200 w-full sm:w-auto">
                    Start a Project
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <InternationalFooter />
    </div>
  );
};

export default International;
