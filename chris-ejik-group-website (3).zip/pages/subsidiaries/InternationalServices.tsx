
import React from 'react';
import { Link } from 'react-router-dom';
import InternationalHeader from '../../components/InternationalHeader';
import InternationalFooter from '../../components/InternationalFooter';

const InternationalServices: React.FC = () => {
  return (
    <div className="bg-black text-white font-sans flex flex-col min-h-screen">
      <InternationalHeader />
      
      <main className="flex-grow pt-20">
        {/* Hero Section */}
        <section className="relative py-16 lg:py-24 overflow-hidden">
          <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072&auto=format&fit=crop")' }}></div>
          <div className="absolute inset-0 bg-black/80"></div>
          <div className="container mx-auto px-4 relative z-10">
            <Link className="inline-flex items-center gap-2 text-neutral-400 hover:text-white mb-8 transition-colors text-sm" to="/subsidiaries/international">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-left w-4 h-4"><path d="m12 19-7-7 7-7"></path><path d="M19 12H5"></path></svg>
              Back to Overview
            </Link>
            <div className="max-w-3xl">
              <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-6">
                Our <span className="text-neutral-400">Services</span>
              </h1>
              <p className="text-lg text-neutral-400 leading-relaxed">
                We provide holistic engineering solutions from conceptualisation and design, engineering, consultancy and project management, to preventive maintenance services. Each service is designed to meet the highest standards of quality and reliability.
              </p>
            </div>
          </div>
        </section>

        {/* Services List */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="space-y-24">
              
              {/* Procurement & E.P.C */}
              <div id="procurement-epc" className="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                  <div className="w-16 h-16 bg-neutral-900 rounded-2xl flex items-center justify-center mb-6 border border-neutral-800">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-wrench w-8 h-8 text-neutral-400"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path></svg>
                  </div>
                  <h2 className="text-3xl font-display font-bold text-white mb-4">Procurement & E.P.C</h2>
                  <p className="text-neutral-400 text-lg mb-6">End-to-end engineering, procurement, and construction services for power infrastructure projects of any scale.</p>
                  <ul className="space-y-3 mb-8">
                    {[
                      "Complete project lifecycle management",
                      "Procurement of quality materials and equipment",
                      "Expert engineering and design services",
                      "Construction supervision and management",
                      "Quality assurance and control",
                      "Project commissioning and handover"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check w-5 h-5 text-neutral-500 mt-0.5 flex-shrink-0"><path d="M20 6 9 17l-5-5"></path></svg>
                        <span className="text-neutral-300">{item}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to="/contact">
                    <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-10 px-4 py-2 bg-white text-black hover:bg-neutral-200 gap-2">
                      Start a Project 
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                    </button>
                  </Link>
                </div>
                <div>
                  <div className="aspect-[4/3] rounded-2xl bg-neutral-900 border border-neutral-800 relative overflow-hidden group">
                    <img 
                      src="https://images.unsplash.com/photo-1581094794320-c917758e6fbb?q=80&w=2070&auto=format&fit=crop" 
                      alt="Procurement and EPC" 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-neutral-900/20 group-hover:bg-neutral-900/10 transition-colors"></div>
                  </div>
                </div>
              </div>

              {/* Transformer Sales & Maintenance */}
              <div id="transformer-services" className="grid lg:grid-cols-2 gap-12 items-center lg:grid-flow-dense">
                <div className="lg:col-start-2">
                  <div className="w-16 h-16 bg-neutral-900 rounded-2xl flex items-center justify-center mb-6 border border-neutral-800">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-8 h-8 text-neutral-400"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>
                  </div>
                  <h2 className="text-3xl font-display font-bold text-white mb-4">Transformer Sales & Maintenance</h2>
                  <p className="text-neutral-400 text-lg mb-6">Power/Distribution Transformers. Online Mobile Transformer Oil Filtration and Regeneration.</p>
                  <ul className="space-y-3 mb-8">
                    {[
                      "Power Transformer sales (up to 330KV)",
                      "Distribution Transformer sales",
                      "Online Mobile Transformer Oil Filtration",
                      "Transformer Oil Regeneration",
                      "Preventive maintenance services",
                      "Emergency repair services"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check w-5 h-5 text-neutral-500 mt-0.5 flex-shrink-0"><path d="M20 6 9 17l-5-5"></path></svg>
                        <span className="text-neutral-300">{item}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to="/contact">
                    <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-10 px-4 py-2 bg-white text-black hover:bg-neutral-200 gap-2">
                      Start a Project 
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                    </button>
                  </Link>
                </div>
                <div className="lg:col-start-1">
                  <div className="aspect-[4/3] rounded-2xl bg-neutral-900 border border-neutral-800 relative overflow-hidden group">
                    <img 
                      src="https://images.unsplash.com/photo-1544724569-5f546fd6dd2d?q=80&w=2070&auto=format&fit=crop" 
                      alt="Transformer Services" 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-neutral-900/20 group-hover:bg-neutral-900/10 transition-colors"></div>
                  </div>
                </div>
              </div>

              {/* Transmission Lines */}
              <div id="transmission-lines" className="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                  <div className="w-16 h-16 bg-neutral-900 rounded-2xl flex items-center justify-center mb-6 border border-neutral-800">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-building2 w-8 h-8 text-neutral-400"><path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"></path><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"></path><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"></path><path d="M10 6h4"></path><path d="M10 10h4"></path><path d="M10 14h4"></path><path d="M10 18h4"></path></svg>
                  </div>
                  <h2 className="text-3xl font-display font-bold text-white mb-4">Transmission Lines Construction</h2>
                  <p className="text-neutral-400 text-lg mb-6">Construction of Transmission Lines up to 330KV and Transmission Substations up to 330KV.</p>
                  <ul className="space-y-3 mb-8">
                    {[
                      "Transmission line construction (up to 330KV)",
                      "Transmission substation construction",
                      "Line stringing and tensioning",
                      "Tower erection and installation",
                      "Foundation works",
                      "Right of way clearing"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check w-5 h-5 text-neutral-500 mt-0.5 flex-shrink-0"><path d="M20 6 9 17l-5-5"></path></svg>
                        <span className="text-neutral-300">{item}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to="/contact">
                    <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-10 px-4 py-2 bg-white text-black hover:bg-neutral-200 gap-2">
                      Start a Project 
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                    </button>
                  </Link>
                </div>
                <div>
                  <div className="aspect-[4/3] rounded-2xl bg-neutral-900 border border-neutral-800 relative overflow-hidden group">
                    <img 
                      src="https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?q=80&w=2070&auto=format&fit=crop" 
                      alt="Transmission Lines" 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-neutral-900/20 group-hover:bg-neutral-900/10 transition-colors"></div>
                  </div>
                </div>
              </div>

              {/* Engineering Design */}
              <div id="engineering-design" className="grid lg:grid-cols-2 gap-12 items-center lg:grid-flow-dense">
                <div className="lg:col-start-2">
                  <div className="w-16 h-16 bg-neutral-900 rounded-2xl flex items-center justify-center mb-6 border border-neutral-800">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-package w-8 h-8 text-neutral-400"><path d="M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z"></path><path d="M12 22V12"></path><path d="m3.3 7 7.703 4.734a2 2 0 0 0 1.994 0L20.7 7"></path><path d="m7.5 4.27 9 5.15"></path></svg>
                  </div>
                  <h2 className="text-3xl font-display font-bold text-white mb-4">Engineering Design & Consultancy</h2>
                  <p className="text-neutral-400 text-lg mb-6">Conceptual & Detailed Engineering Design. Project Management and Engineering Consultancy.</p>
                  <ul className="space-y-3 mb-8">
                    {[
                      "Conceptual design and feasibility studies",
                      "Detailed engineering design",
                      "Project management services",
                      "Engineering consultancy",
                      "Technical due diligence",
                      "System studies and analysis"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check w-5 h-5 text-neutral-500 mt-0.5 flex-shrink-0"><path d="M20 6 9 17l-5-5"></path></svg>
                        <span className="text-neutral-300">{item}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to="/contact">
                    <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-10 px-4 py-2 bg-white text-black hover:bg-neutral-200 gap-2">
                      Start a Project 
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                    </button>
                  </Link>
                </div>
                <div className="lg:col-start-1">
                  <div className="aspect-[4/3] rounded-2xl bg-neutral-900 border border-neutral-800 relative overflow-hidden group">
                    <img 
                      src="https://images.unsplash.com/photo-1503387762-592deb58ef4e?q=80&w=2071&auto=format&fit=crop" 
                      alt="Engineering Design" 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-neutral-900/20 group-hover:bg-neutral-900/10 transition-colors"></div>
                  </div>
                </div>
              </div>

              {/* Preventive Maintenance */}
              <div id="preventive-maintenance" className="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                  <div className="w-16 h-16 bg-neutral-900 rounded-2xl flex items-center justify-center mb-6 border border-neutral-800">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-settings w-8 h-8 text-neutral-400"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                  </div>
                  <h2 className="text-3xl font-display font-bold text-white mb-4">Preventive Maintenance Services</h2>
                  <p className="text-neutral-400 text-lg mb-6">Preventive Maintenance Services for Substations to ensure optimal performance and longevity.</p>
                  <ul className="space-y-3 mb-8">
                    {[
                      "Scheduled maintenance programs",
                      "Equipment testing and diagnostics",
                      "Protective relay testing",
                      "Circuit breaker maintenance",
                      "Switchgear maintenance",
                      "SCADA system maintenance"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check w-5 h-5 text-neutral-500 mt-0.5 flex-shrink-0"><path d="M20 6 9 17l-5-5"></path></svg>
                        <span className="text-neutral-300">{item}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to="/contact">
                    <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-10 px-4 py-2 bg-white text-black hover:bg-neutral-200 gap-2">
                      Start a Project 
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                    </button>
                  </Link>
                </div>
                <div>
                  <div className="aspect-[4/3] rounded-2xl bg-neutral-900 border border-neutral-800 relative overflow-hidden group">
                    <img 
                      src="https://images.unsplash.com/photo-1518349619113-03114f06ac3a?q=80&w=2070&auto=format&fit=crop" 
                      alt="Preventive Maintenance" 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-neutral-900/20 group-hover:bg-neutral-900/10 transition-colors"></div>
                  </div>
                </div>
              </div>

              {/* Manufacturing */}
              <div id="manufacturing" className="grid lg:grid-cols-2 gap-12 items-center lg:grid-flow-dense">
                <div className="lg:col-start-2">
                  <div className="w-16 h-16 bg-neutral-900 rounded-2xl flex items-center justify-center mb-6 border border-neutral-800">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-globe w-8 h-8 text-neutral-400"><circle cx="12" cy="12" r="10"></circle><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"></path><path d="M2 12h20"></path></svg>
                  </div>
                  <h2 className="text-3xl font-display font-bold text-white mb-4">Manufacturing</h2>
                  <p className="text-neutral-400 text-lg mb-6">Manufacturing of Composite Insulators, Feeder Pillars & Distribution Boards.</p>
                  <ul className="space-y-3 mb-8">
                    {[
                      "Composite insulator manufacturing",
                      "Feeder pillar production",
                      "Distribution board manufacturing",
                      "Panel assembly",
                      "Custom fabrication services",
                      "Quality testing and certification"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check w-5 h-5 text-neutral-500 mt-0.5 flex-shrink-0"><path d="M20 6 9 17l-5-5"></path></svg>
                        <span className="text-neutral-300">{item}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to="/contact">
                    <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-10 px-4 py-2 bg-white text-black hover:bg-neutral-200 gap-2">
                      Start a Project 
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                    </button>
                  </Link>
                </div>
                <div className="lg:col-start-1">
                  <div className="aspect-[4/3] rounded-2xl bg-neutral-900 border border-neutral-800 relative overflow-hidden group">
                    <img 
                      src="https://images.unsplash.com/photo-1565514020176-db99d50a29d6?q=80&w=2070&auto=format&fit=crop" 
                      alt="Manufacturing" 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-neutral-900/20 group-hover:bg-neutral-900/10 transition-colors"></div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-neutral-900/30 border-t border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="bg-gradient-to-r from-neutral-800/50 to-neutral-800/20 rounded-2xl p-12 text-center border border-neutral-800">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Ready to Start Your Project?</h2>
              <p className="text-neutral-400 max-w-2xl mx-auto mb-8">
                Contact us today to discuss your power infrastructure needs and how we can help bring your project to life with our expertise and proven track record.
              </p>
              <Link to="/contact">
                <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-11 rounded-md px-8 bg-white text-black hover:bg-neutral-200">
                  Contact Our Team
                </button>
              </Link>
            </div>
          </div>
        </section>
      </main>

      <InternationalFooter />
    </div>
  );
};

export default InternationalServices;
