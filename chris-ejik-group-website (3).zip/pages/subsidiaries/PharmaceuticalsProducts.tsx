
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import PharmaceuticalsHeader from '../../components/PharmaceuticalsHeader';
import PharmaceuticalsFooter from '../../components/PharmaceuticalsFooter';

// Mock Product Data
const products = [
  {
    id: 'impilin',
    name: 'Impilin®',
    genericName: 'Ampicillin 250mg Capsules',
    description: 'A broad-spectrum penicillin antibiotic used to treat various bacterial infections including respiratory tract infections, urinary tract infections, meningitis, and salmonellosis.',
    category: 'Prescription',
    type: 'Antibiotic',
    variants: 1,
    image: null,
    link: '/subsidiaries/pharmaceuticals/products/impilin'
  },
  {
    id: 'euroclox',
    name: 'Euroclox®',
    genericName: 'Ampicillin 250mg + Cloxacillin 250mg Capsules',
    description: 'A synergistic combination of Ampicillin and Cloxacillin designed to provide broad-spectrum coverage against both gram-positive and gram-negative bacteria, including penicillinase-producing strains.',
    category: 'Prescription',
    type: 'Antibiotic',
    variants: 2,
    image: null,
    link: '/subsidiaries/pharmaceuticals/products/euroclox'
  },
  {
    id: 'imox',
    name: 'Imox®',
    genericName: 'Amoxicillin 500mg Capsules',
    description: 'A widely used antibiotic effective against a wide range of bacteria. It is commonly prescribed for ear, nose, and throat infections, as well as skin and soft tissue infections.',
    category: 'Prescription',
    type: 'Antibiotic',
    variants: 3,
    image: null,
    link: '/subsidiaries/pharmaceuticals/products/imox'
  },
  {
    id: 'imoxclav',
    name: 'Imoxclav®',
    genericName: 'Amoxicillin 500mg + Clavulanic Acid 125mg Tablets',
    description: 'An enhanced antibiotic formulation containing a beta-lactamase inhibitor, making it effective against resistant bacterial strains that would otherwise neutralize amoxicillin.',
    category: 'Prescription',
    type: 'Antibiotic',
    variants: 1,
    image: null,
    link: '/subsidiaries/pharmaceuticals/products/imoxclav'
  },
  {
    id: 'euromether',
    name: 'Euromether®',
    genericName: 'Artemether + Lumefantrine Tablets',
    description: 'A highly effective antimalarial combination therapy (ACT) for the treatment of uncomplicated Plasmodium falciparum malaria. Fast-acting and well-tolerated.',
    category: 'OTC',
    type: 'Antimalarial',
    variants: 2,
    image: null,
    link: '/subsidiaries/pharmaceuticals/products/euromether'
  },
  {
    id: 'ce-vit',
    name: 'CE-Vit C',
    genericName: 'Vitamin C 1000mg Effervescent',
    description: 'High strength Vitamin C supplement to boost immune system function and promote collagen formation. Refreshing orange flavor.',
    category: 'OTC',
    type: 'Supplement',
    variants: 1,
    image: null,
    link: '#'
  }
];

const PharmaceuticalsProducts: React.FC = () => {
  const [filter, setFilter] = useState('All');

  const filteredProducts = filter === 'All' 
    ? products 
    : products.filter(p => p.category === filter);

  return (
    <div className="bg-black text-white font-sans min-h-screen flex flex-col">
      <PharmaceuticalsHeader />
      
      <main className="flex-grow pt-20">
        {/* Hero Section */}
        <section className="relative py-20 lg:py-28 overflow-hidden">
          <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?q=80&w=2070&auto=format&fit=crop")' }}></div>
          <div className="absolute inset-0 bg-black/80"></div>
          
          <div className="container mx-auto px-4 relative z-10 text-center">
            <Link to="/subsidiaries/pharmaceuticals" className="inline-flex items-center gap-2 text-neutral-400 hover:text-blue-500 mb-8 transition-colors text-sm">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-left w-4 h-4"><path d="m12 19-7-7 7-7"></path><path d="M19 12H5"></path></svg>
              Back to Overview
            </Link>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold text-white mb-6">
              Our <span className="text-blue-600">Products</span>
            </h1>
            <p className="text-lg text-neutral-400 leading-relaxed max-w-2xl mx-auto">
              We manufacture and distribute a wide range of high-quality pharmaceutical products, ensuring accessibility and efficacy for patients across the nation.
            </p>
          </div>
        </section>

        {/* Filter Section */}
        <section className="sticky top-20 z-40 bg-black/80 backdrop-blur-md border-y border-neutral-800 py-4">
          <div className="container mx-auto px-4">
            <div className="flex justify-center gap-2 md:gap-4 overflow-x-auto pb-2 md:pb-0 scrollbar-hide">
              {['All', 'Prescription', 'OTC'].map((category) => (
                <button
                  key={category}
                  onClick={() => setFilter(category)}
                  className={`px-6 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all duration-300 ${
                    filter === category 
                      ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' 
                      : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800 border border-neutral-800'
                  }`}
                >
                  {category === 'All' ? 'All Products' : category === 'Prescription' ? 'Prescription (Ethical)' : 'Non-Prescription (OTC)'}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Products Grid */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProducts.map((product) => (
                <div key={product.id} className="group bg-neutral-900 rounded-2xl border border-neutral-800 overflow-hidden hover:border-blue-600/50 transition-all duration-300 hover:shadow-2xl hover:shadow-blue-900/10 flex flex-col">
                  {/* Image Placeholder */}
                  <div className="h-48 bg-neutral-800/50 relative overflow-hidden flex items-center justify-center group-hover:bg-blue-900/10 transition-colors">
                    <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 to-transparent opacity-50"></div>
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      width="24" 
                      height="24" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="1.5" 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      className={`w-20 h-20 transition-transform duration-500 group-hover:scale-110 ${product.category === 'Prescription' ? 'text-blue-500' : 'text-green-500'}`}
                    >
                      <path d="M4.5 3h15"></path>
                      <path d="M6 3v16a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V3"></path><path d="M6 14h12"></path>
                    </svg>
                    
                    {/* Badge */}
                    <div className="absolute top-4 right-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium border ${
                        product.category === 'Prescription' 
                          ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' 
                          : 'bg-green-500/10 text-green-400 border-green-500/20'
                      }`}>
                        {product.category}
                      </span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6 flex-1 flex flex-col">
                    <div className="mb-4">
                      <span className="text-neutral-500 text-xs uppercase tracking-wider font-medium">{product.type}</span>
                      <h3 className="text-2xl font-display font-bold text-white mt-1 mb-1 group-hover:text-blue-500 transition-colors">{product.name}</h3>
                      <p className="text-blue-400 text-sm font-medium">{product.genericName}</p>
                    </div>
                    
                    <p className="text-neutral-400 text-sm leading-relaxed mb-6 flex-grow">
                      {product.description}
                    </p>

                    <div className="pt-6 border-t border-neutral-800 mt-auto flex items-center justify-between">
                      <span className="text-neutral-500 text-sm font-medium">
                        {product.variants} variant{product.variants !== 1 ? 's' : ''}
                      </span>
                      <Link to={product.link} className={`text-sm font-medium transition-all flex items-center gap-1 group-hover:gap-2 ${
                        product.category === 'Prescription'
                          ? 'text-blue-500 hover:text-blue-400'
                          : 'text-green-500 hover:text-green-400'
                      }`}>
                        View Details
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className="text-center py-20">
                <p className="text-neutral-500 text-lg">No products found in this category.</p>
                <button 
                  onClick={() => setFilter('All')}
                  className="mt-4 text-blue-500 hover:text-blue-400 font-medium"
                >
                  View all products
                </button>
              </div>
            )}
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-neutral-900/30 border-t border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="bg-gradient-to-r from-blue-900/20 to-blue-600/5 rounded-2xl p-12 text-center border border-blue-900/30 relative overflow-hidden">
              <div className="relative z-10">
                <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Partner With Us</h2>
                <p className="text-neutral-400 max-w-2xl mx-auto mb-8">
                  Are you a distributor or healthcare provider? Contact us to discuss partnership opportunities and bulk orders.
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                  <Link to="/contact">
                    <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-white h-11 rounded-md px-8 bg-blue-600 hover:bg-blue-700 w-full sm:w-auto">
                      Contact Sales
                    </button>
                  </Link>
                  <a href="mailto:sales@chrisejik.com">
                    <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-neutral-700 bg-transparent hover:bg-neutral-800 text-white h-11 rounded-md px-8 w-full sm:w-auto">
                      Request Catalog
                    </button>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <PharmaceuticalsFooter />
    </div>
  );
};

export default PharmaceuticalsProducts;
