
import React, { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import PharmaceuticalsHeader from '../../components/PharmaceuticalsHeader';
import PharmaceuticalsFooter from '../../components/PharmaceuticalsFooter';

const AnimatedStat = ({ end, label, suffix = '', prefix = '' }: { end: number, label: string, suffix?: string, prefix?: string }) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          const duration = 2000;
          const start = 0;
          const startTime = performance.now();

          const animate = (currentTime: number) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const easeOut = 1 - Math.pow(1 - progress, 3);
            
            setCount(Math.floor(start + (end - start) * easeOut));

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setCount(end);
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [end]);

  return (
    <div ref={ref} className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 text-center shadow-sm hover:border-blue-600/30 transition-colors">
      <div className="mb-4 flex justify-center text-blue-600">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-trending-up w-8 h-8"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>
      </div>
      <div className="text-2xl font-display font-bold text-white mb-1">
        {prefix}{count}{suffix}
      </div>
      <div className="text-neutral-400 text-sm">{label}</div>
    </div>
  );
};

const Pharmaceuticals: React.FC = () => {
  const affiliations = [
    { 
      name: "NAFDAC", 
      fullName: "National Agency for Food and Drug Administration and Control",
      logo: "https://placehold.co/150x150/000000/2563EB?text=NAFDAC&font=montserrat"
    },
    { 
      name: "PCN", 
      fullName: "Pharmacy Council of Nigeria",
      logo: "https://placehold.co/150x150/000000/2563EB?text=PCN&font=montserrat"
    },
    { 
      name: "PMG-MAN", 
      fullName: "Pharmaceutical Manufacturers Group",
      logo: "https://placehold.co/150x150/000000/2563EB?text=PMG-MAN&font=montserrat"
    },
    { 
      name: "LASEPA", 
      fullName: "Lagos State Environmental Protection Agency",
      logo: "https://placehold.co/150x150/000000/2563EB?text=LASEPA&font=montserrat"
    },
    { 
      name: "WHO GMP", 
      fullName: "World Health Organization Good Manufacturing Practice",
      logo: "https://placehold.co/150x150/000000/2563EB?text=WHO+GMP&font=montserrat"
    },
  ];

  // Placeholder logos for pharma partners
  const pharmaPartners = [
    'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/Pfizer_%282021%29.svg/2560px-Pfizer_%282021%29.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Novartis_Logo.svg/2560px-Novartis_Logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Roche_Logo.svg/2560px-Roche_Logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Sanofi_logo.svg/2560px-Sanofi_logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1a/Merck_Logo.svg/2560px-Merck_Logo.svg.png'
  ];

  return (
    <div className="bg-black text-white font-sans">
      <PharmaceuticalsHeader />
      
      <main className="flex-grow pt-20">
        <section className="relative py-24 lg:py-32 overflow-hidden">
          <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1631549916768-4119b2e5f926?q=80&w=2070&auto=format&fit=crop")' }}></div>
          <div className="absolute inset-0 bg-black/80"></div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl">
              <div className="inline-flex items-center gap-2 bg-blue-600/10 text-blue-500 px-4 py-2 rounded-full text-sm font-medium mb-6 border border-blue-900/30">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-pill w-4 h-4"><path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"></path><path d="m8.5 8.5 7 7"></path></svg>
                Healthcare Excellence Since 1987
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold text-white mb-6">
                Chris-Ejik <span className="text-blue-600">Pharmaceuticals</span>
              </h1>
              <p className="text-lg md:text-xl text-neutral-400 leading-relaxed mb-4">
                A prestigious Nigerian company founded in 1987 to import, manufacture, and distribute high-quality pharmaceutical products in Nigeria.
              </p>
              <p className="text-neutral-400 mb-4">
                With over 30+ years in beta-Lactam drug manufacturing, bridging the gap in essential drug distribution and access in Nigeria. We have distributed over 40 brands across various therapeutic areas, spreading wellness in over 700 communities across the 36 states in Nigeria.
              </p>
              <div className="bg-neutral-900/50 backdrop-blur-sm rounded-xl p-6 border border-blue-900/30 mb-8 shadow-sm">
                <p className="text-blue-500 font-medium italic">"To be relentless in our contribution to a society where true wellness is within reach for all."</p>
                <p className="text-neutral-500 text-sm mt-2">— Our Promise</p>
              </div>
              <div className="flex gap-4">
                <Link to="/subsidiaries/pharmaceuticals/products">
                  <button className="inline-flex items-center justify-center whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-white h-11 rounded-md px-8 bg-blue-600 hover:bg-blue-700 gap-2">
                    View Products 
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                  </button>
                </Link>
                <Link to="/contact">
                  <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-neutral-700 bg-black hover:bg-neutral-900 text-white h-11 rounded-md px-8">
                    Contact Us
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-neutral-900/30">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-neutral-900 rounded-2xl p-8 border border-neutral-800 shadow-sm hover:border-blue-900/30 transition-colors">
                <h3 className="text-2xl font-display font-bold text-white mb-4">Our Vision</h3>
                <p className="text-neutral-400 leading-relaxed">To provide access to essential pharmaceutical and healthcare products focused on improving the quality of life.</p>
              </div>
              <div className="bg-neutral-900 rounded-2xl p-8 border border-neutral-800 shadow-sm hover:border-blue-900/30 transition-colors">
                <h3 className="text-2xl font-display font-bold text-white mb-4">Our Mission</h3>
                <p className="text-neutral-400 leading-relaxed">To manufacture and distribute essential healthcare products by leveraging strategic stakeholder engagement and consumer insights to provide access to quality healthcare products that meet the needs of our customers.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Our Core Values</h2>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-blue-600/50 transition-colors shadow-sm">
                <div className="w-10 h-10 bg-blue-900/20 rounded-full flex items-center justify-center mb-4">
                  <span className="text-blue-500 font-bold">01</span>
                </div>
                <h3 className="text-lg font-display font-semibold text-white mb-2">Leadership</h3>
                <p className="text-neutral-400 text-sm">Create an environment to encourage responsibility and accountability.</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-blue-600/50 transition-colors shadow-sm">
                <div className="w-10 h-10 bg-blue-900/20 rounded-full flex items-center justify-center mb-4">
                  <span className="text-blue-500 font-bold">02</span>
                </div>
                <h3 className="text-lg font-display font-semibold text-white mb-2">Expertise</h3>
                <p className="text-neutral-400 text-sm">Consistently show competence with insights and knowledge in your field to deliver quality.</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-blue-600/50 transition-colors shadow-sm">
                <div className="w-10 h-10 bg-blue-900/20 rounded-full flex items-center justify-center mb-4">
                  <span className="text-blue-500 font-bold">03</span>
                </div>
                <h3 className="text-lg font-display font-semibold text-white mb-2">Efficiency</h3>
                <p className="text-neutral-400 text-sm">Create a smart process to make people deliver quality output with dedicated effort.</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-blue-600/50 transition-colors shadow-sm">
                <div className="w-10 h-10 bg-blue-900/20 rounded-full flex items-center justify-center mb-4">
                  <span className="text-blue-500 font-bold">04</span>
                </div>
                <h3 className="text-lg font-display font-semibold text-white mb-2">Empowerment</h3>
                <p className="text-neutral-400 text-sm">Give means to people to access quality information that helps make informed decisions.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-neutral-900/30">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Quality Policy</h2>
              <p className="text-neutral-400">We are committed to meeting and exceeding the expectations and needs of our customers.</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="bg-gradient-to-b from-blue-900/10 to-transparent rounded-xl p-6 border border-blue-900/20 shadow-sm">
                <div className="w-12 h-12 bg-blue-900/20 rounded-lg flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-users w-6 h-6 text-blue-500"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M22 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                </div>
                <h3 className="text-lg font-display font-semibold text-white mb-3">Personnel Development</h3>
                <p className="text-neutral-400 text-sm">Developing the skills and competencies of our personnel</p>
              </div>
              <div className="bg-gradient-to-b from-blue-900/10 to-transparent rounded-xl p-6 border border-blue-900/20 shadow-sm">
                <div className="w-12 h-12 bg-blue-900/20 rounded-lg flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-trending-up w-6 h-6 text-blue-500"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline><polyline points="16 7 22 7 22 13"></polyline></svg>
                </div>
                <h3 className="text-lg font-display font-semibold text-white mb-3">Process Monitoring</h3>
                <p className="text-neutral-400 text-sm">Monitoring, review and improvement of our processes and quality objectives</p>
              </div>
              <div className="bg-gradient-to-b from-blue-900/10 to-transparent rounded-xl p-6 border border-blue-900/20 shadow-sm">
                <div className="w-12 h-12 bg-blue-900/20 rounded-lg flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-building2 w-6 h-6 text-blue-500"><path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"></path><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"></path><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"></path><path d="M10 6h4"></path><path d="M10 10h4"></path><path d="M10 14h4"></path><path d="M10 18h4"></path></svg>
                </div>
                <h3 className="text-lg font-display font-semibold text-white mb-3">Manufacturing Excellence</h3>
                <p className="text-neutral-400 text-sm">Manufacturing of pharmaceutical products of high standard in terms of quality, safety, efficacy that complies with all relevant laws and regulations</p>
              </div>
              <div className="bg-gradient-to-b from-blue-900/10 to-transparent rounded-xl p-6 border border-blue-900/20 shadow-sm">
                <div className="w-12 h-12 bg-blue-900/20 rounded-lg flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-shield w-6 h-6 text-blue-500"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path></svg>
                </div>
                <h3 className="text-lg font-display font-semibold text-white mb-3">Quality Assurance</h3>
                <p className="text-neutral-400 text-sm">Importation and marketing of highly certified and validated pharmaceuticals</p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Key Milestones</h2>
              <p className="text-neutral-400">In over three decades of existence, we have distributed over 40 brands across various therapeutic areas, spreading wellness in over 700 communities across the 36 states in Nigeria.</p>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-neutral-900 rounded-xl p-8 border border-neutral-800 hover:border-blue-600/50 transition-colors shadow-sm">
                <div className="w-12 h-12 bg-blue-900/20 rounded-lg flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-trending-up w-6 h-6 text-blue-500"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline><polyline points="16 7 22 7 22 13"></polyline></svg>
                </div>
                <h3 className="text-xl font-display font-semibold text-white mb-3">Sales Growth</h3>
                <p className="text-neutral-400">We have continuously recorded year on year growth in sales and distribution of our high-quality healthcare products contributing positively to the healthcare delivery ecosystem.</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-8 border border-neutral-800 hover:border-blue-600/50 transition-colors shadow-sm">
                <div className="w-12 h-12 bg-blue-900/20 rounded-lg flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-package w-6 h-6 text-blue-500"><path d="M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z"></path><path d="M12 22V12"></path><path d="m3.3 7 7.703 4.734a2 2 0 0 0 1.994 0L20.7 7"></path><path d="m7.5 4.27 9 5.15"></path></svg>
                </div>
                <h3 className="text-xl font-display font-semibold text-white mb-3">Inventory</h3>
                <p className="text-neutral-400">Our strategic warehouse facility and 2 depots in Lagos and Anambra ensures our products get to the point of purchase in compliance with storage requirements and in the condition that preserves the quality and efficacy of our brands.</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-8 border border-neutral-800 hover:border-blue-600/50 transition-colors shadow-sm">
                <div className="w-12 h-12 bg-blue-900/20 rounded-lg flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-users w-6 h-6 text-blue-500"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M22 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                </div>
                <h3 className="text-xl font-display font-semibold text-white mb-3">Customer Satisfaction</h3>
                <p className="text-neutral-400">Our teeming partners across the country have expressed immense satisfaction with our offer and their communities have benefited from the Chris-Ejik advantage in pharmaceutical products that guarantees quality, efficacy, and affordability.</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-8 border border-neutral-800 hover:border-blue-600/50 transition-colors shadow-sm">
                <div className="w-12 h-12 bg-blue-900/20 rounded-lg flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-file-check w-6 h-6 text-blue-500"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path><path d="M14 2v4a2 2 0 0 0 2 2h4"></path><path d="m9 15 2 2 4-4"></path></svg>
                </div>
                <h3 className="text-xl font-display font-semibold text-white mb-3">Regulatory Compliance</h3>
                <p className="text-neutral-400">Our beta lactam facility is compliant with key regulatory agencies such as NAFDAC, PCN, PMG-MAN, LASEPA, amongst others.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-6">Memberships & Affiliations</h2>
              <p className="text-neutral-400">Our commitment to quality is demonstrated through our adherence to international standards and regulatory requirements.</p>
            </div>
            
            {/* Affiliations Marquee */}
            <div className="relative overflow-hidden py-12 bg-neutral-900/50 border-y border-neutral-800 mb-16">
              <div className="flex animate-marquee whitespace-nowrap">
                {[...affiliations, ...affiliations, ...affiliations].map((item, i) => (
                  <div key={i} className="mx-12 flex flex-col items-center justify-center min-w-[200px]">
                    <div className="w-32 h-32 bg-neutral-900 rounded-full flex items-center justify-center border border-neutral-800 mb-6 shadow-lg group hover:border-blue-600 transition-colors p-4">
                      <img src={item.logo} alt={item.name} className="w-full h-full object-contain opacity-70 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <h4 className="font-display font-bold text-white text-lg mb-1">{item.name}</h4>
                    <span className="text-neutral-400 font-medium text-xs text-center max-w-[200px] whitespace-normal line-clamp-2 leading-relaxed">{item.fullName}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Global Partners */}
            <div className="text-center max-w-3xl mx-auto mb-12">
               <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-6">Global Partners</h2>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
               {pharmaPartners.map((logo, index) => (
                  <div key={index} className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 text-center shadow-sm hover:border-blue-600/30 transition-colors flex items-center justify-center h-32 group">
                     <img 
                       src={logo} 
                       alt="Partner Logo" 
                       className="max-w-full max-h-full object-contain grayscale group-hover:grayscale-0 transition-all opacity-70 group-hover:opacity-100" 
                     />
                  </div>
               ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-neutral-900/30 border-t border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="bg-gradient-to-r from-blue-900/20 to-blue-600/5 rounded-2xl p-12 text-center border border-blue-900/30">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Partner With Us</h2>
              <p className="text-neutral-400 max-w-2xl mx-auto mb-8">
                We are always looking to expand our network of distributors and healthcare partners.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Link to="/contact">
                  <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-white h-11 rounded-md px-8 bg-blue-600 hover:bg-blue-700 w-full sm:w-auto">
                    Contact Us
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </section>

      </main>

      <PharmaceuticalsFooter />
    </div>
  );
};

export default Pharmaceuticals;
