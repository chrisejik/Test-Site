
import React from 'react';
import { Link } from 'react-router-dom';
import EngineeringHeader from '../../components/EngineeringHeader';
import EngineeringFooter from '../../components/EngineeringFooter';

const EngineeringServices: React.FC = () => {
  return (
    <div className="bg-black text-white font-sans min-h-screen flex flex-col">
      <EngineeringHeader />
      
      <main className="flex-grow pt-20">
        {/* Hero Section */}
        <section className="relative py-16 lg:py-24 overflow-hidden">
          <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1581092160562-40aa08e78837?q=80&w=2070&auto=format&fit=crop")' }}></div>
          <div className="absolute inset-0 bg-black/80"></div>
          <div className="container mx-auto px-4 relative z-10">
            <Link className="inline-flex items-center gap-2 text-neutral-400 hover:text-white mb-8 transition-colors text-sm" to="/subsidiaries/engineering">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-left w-4 h-4"><path d="m12 19-7-7 7-7"></path><path d="M19 12H5"></path></svg>
              Back to Overview
            </Link>
            <div className="max-w-3xl">
              <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-6">
                Our <span className="text-purple-500">Services</span>
              </h1>
              <p className="text-lg text-neutral-400 leading-relaxed">
                We provide comprehensive engineering solutions with a specialized focus on metering infrastructure, power distribution, and EPC services. Our solutions are designed to enhance efficiency and reliability in the power sector.
              </p>
            </div>
          </div>
        </section>

        {/* Services List */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="space-y-24">
              
              {/* Metering Solutions */}
              <div id="metering" className="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                  <div className="w-16 h-16 bg-neutral-900 rounded-2xl flex items-center justify-center mb-6 border border-neutral-800">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-gauge w-8 h-8 text-purple-500"><path d="m12 14 4-4"></path><path d="M3.34 19a10 10 0 1 1 17.32 0"></path></svg>
                  </div>
                  <h2 className="text-3xl font-display font-bold text-white mb-4">Metering Solutions</h2>
                  <p className="text-neutral-400 text-lg mb-6">Advanced manufacturing and assembly of electricity meters for residential, commercial, and industrial applications.</p>
                  <ul className="space-y-3 mb-8">
                    {[
                      "Single Phase Prepaid Meter Assembly",
                      "Three Phase Prepaid Meter Assembly",
                      "Smart Meter Production with AMI capabilities",
                      "Maximum Demand Meters",
                      "Meter installation and commissioning",
                      "Meter testing and calibration services"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check w-5 h-5 text-neutral-500 mt-0.5 flex-shrink-0"><path d="M20 6 9 17l-5-5"></path></svg>
                        <span className="text-neutral-300">{item}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to="/contact">
                    <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-10 px-4 py-2 bg-white text-black hover:bg-neutral-200 gap-2">
                      Request Catalog
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                    </button>
                  </Link>
                </div>
                <div>
                  <div className="aspect-[4/3] rounded-2xl bg-neutral-900 border border-neutral-800 relative overflow-hidden group">
                    <img 
                      src="https://images.unsplash.com/photo-1555664424-778a1e5e1b48?q=80&w=2070&auto=format&fit=crop" 
                      alt="Metering Solutions" 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-neutral-900/20 group-hover:bg-neutral-900/10 transition-colors"></div>
                  </div>
                </div>
              </div>

              {/* Manufacturing */}
              <div id="manufacturing" className="grid lg:grid-cols-2 gap-12 items-center lg:grid-flow-dense">
                <div className="lg:col-start-2">
                  <div className="w-16 h-16 bg-neutral-900 rounded-2xl flex items-center justify-center mb-6 border border-neutral-800">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-factory w-8 h-8 text-purple-500"><path d="M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8l-7 5V8l-7 5V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"></path><path d="M17 18h1"></path><path d="M12 18h1"></path><path d="M7 18h1"></path></svg>
                  </div>
                  <h2 className="text-3xl font-display font-bold text-white mb-4">Manufacturing & Fabrication</h2>
                  <p className="text-neutral-400 text-lg mb-6">Production of critical electrical components including feeder pillars and distribution boards.</p>
                  <ul className="space-y-3 mb-8">
                    {[
                      "Feeder Pillar production (various specifications)",
                      "Distribution Board manufacturing",
                      "Panel assembly and wiring",
                      "Composite insulator manufacturing",
                      "Custom electrical enclosure fabrication",
                      "Quality control testing for all manufactured units"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check w-5 h-5 text-neutral-500 mt-0.5 flex-shrink-0"><path d="M20 6 9 17l-5-5"></path></svg>
                        <span className="text-neutral-300">{item}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to="/contact">
                    <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-10 px-4 py-2 bg-white text-black hover:bg-neutral-200 gap-2">
                      Contact Sales
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                    </button>
                  </Link>
                </div>
                <div className="lg:col-start-1">
                  <div className="aspect-[4/3] rounded-2xl bg-neutral-900 border border-neutral-800 relative overflow-hidden group">
                    <img 
                      src="https://images.unsplash.com/photo-1565514020176-db99d50a29d6?q=80&w=2070&auto=format&fit=crop" 
                      alt="Manufacturing & Fabrication" 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-neutral-900/20 group-hover:bg-neutral-900/10 transition-colors"></div>
                  </div>
                </div>
              </div>

              {/* EPC Services */}
              <div id="epc" className="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                  <div className="w-16 h-16 bg-neutral-900 rounded-2xl flex items-center justify-center mb-6 border border-neutral-800">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-8 h-8 text-purple-500"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>
                  </div>
                  <h2 className="text-3xl font-display font-bold text-white mb-4">Power Infrastructure EPC</h2>
                  <p className="text-neutral-400 text-lg mb-6">Comprehensive Engineering, Procurement, and Construction services for power projects.</p>
                  <ul className="space-y-3 mb-8">
                    {[
                      "Rural electrification projects",
                      "Substation design and construction",
                      "Distribution network expansion",
                      "Grid extension projects",
                      "Solar power integration",
                      "Maintenance and rehabilitation of power assets"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check w-5 h-5 text-neutral-500 mt-0.5 flex-shrink-0"><path d="M20 6 9 17l-5-5"></path></svg>
                        <span className="text-neutral-300">{item}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to="/contact">
                    <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-10 px-4 py-2 bg-white text-black hover:bg-neutral-200 gap-2">
                      Start a Project 
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                    </button>
                  </Link>
                </div>
                <div>
                  <div className="aspect-[4/3] rounded-2xl bg-neutral-900 border border-neutral-800 relative overflow-hidden group">
                    <img 
                      src="https://images.unsplash.com/photo-1503387762-592deb58ef4e?q=80&w=2071&auto=format&fit=crop" 
                      alt="Power Infrastructure EPC" 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-neutral-900/20 group-hover:bg-neutral-900/10 transition-colors"></div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-neutral-900/30 border-t border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="bg-gradient-to-r from-purple-600/20 to-purple-600/5 rounded-2xl p-12 text-center border border-purple-600/20">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Need Custom Engineering Solutions?</h2>
              <p className="text-neutral-400 max-w-2xl mx-auto mb-8">
                Our team of expert engineers is ready to help design and implement the perfect solution for your specific power infrastructure needs.
              </p>
              <Link to="/contact">
                <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-11 rounded-md px-8 bg-purple-600 hover:bg-purple-700 text-white">
                  Speak to an Engineer
                </button>
              </Link>
            </div>
          </div>
        </section>
      </main>

      <EngineeringFooter />
    </div>
  );
};

export default EngineeringServices;
