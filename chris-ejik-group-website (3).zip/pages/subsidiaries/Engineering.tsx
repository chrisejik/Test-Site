
import React, { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import EngineeringHeader from '../../components/EngineeringHeader';
import EngineeringFooter from '../../components/EngineeringFooter';

const AnimatedStat = ({ end, label, suffix = '', prefix = '' }: { end: number, label: string, suffix?: string, prefix?: string }) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          const duration = 2000;
          const start = 0;
          const startTime = performance.now();

          const animate = (currentTime: number) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const easeOut = 1 - Math.pow(1 - progress, 3);
            
            setCount(Math.floor(start + (end - start) * easeOut));

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setCount(end);
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [end]);

  return (
    <div ref={ref} className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-purple-600/50 transition-colors group">
      <div className="text-4xl font-display font-bold text-purple-500 mb-1 tabular-nums group-hover:text-purple-400 transition-colors">
        {prefix}{count}{suffix}
      </div>
      <div className="text-neutral-400 text-sm uppercase tracking-wider">{label}</div>
    </div>
  );
};

const Engineering: React.FC = () => {
  const clients = [
    'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/Pfizer_%282021%29.svg/2560px-Pfizer_%282021%29.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Novartis_Logo.svg/2560px-Novartis_Logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Roche_Logo.svg/2560px-Roche_Logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Sanofi_logo.svg/2560px-Sanofi_logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1a/Merck_Logo.svg/2560px-Merck_Logo.svg.png'
  ];

  const partners = [
    'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Google_2015_logo.svg/2560px-Google_2015_logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/2560px-Amazon_logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/IBM_logo.svg/2560px-IBM_logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Tata_Consultancy_Services_Logo.svg/2560px-Tata_Consultancy_Services_Logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Cisco_logo_blue_2016.svg/2560px-Cisco_logo_blue_2016.svg.png'
  ];

  return (
    <div className="bg-black text-white font-sans min-h-screen flex flex-col">
      <EngineeringHeader />
      
      <main className="flex-grow pt-20">
        {/* Hero Section */}
        <section className="relative py-24 lg:py-32 overflow-hidden">
          <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1581094288338-2314dddb7ece?q=80&w=2070&auto=format&fit=crop")' }}></div>
          <div className="absolute inset-0 bg-black/80"></div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl">
              <div className="inline-flex items-center gap-2 bg-purple-600/10 text-purple-400 px-4 py-2 rounded-full text-sm font-medium mb-6 border border-purple-600/30">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-settings w-4 h-4"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                Metering & Power Solutions
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold text-white mb-6">
                Chris-Ejik <span className="text-purple-600">Engineering</span>
              </h1>
              <p className="text-lg md:text-xl text-neutral-400 leading-relaxed mb-8">
                Chris-Ejik Engineering Limited provides end-to-end metering and power infrastructure solutions, supporting Nigeria's electricity supply industry with reliable engineering services. We specialize in meter assembly, including prepaid and smart meters, serving major electricity distribution companies.
              </p>
              <div className="flex gap-4">
                <Link to="/subsidiaries/engineering/services">
                  <button className="inline-flex items-center justify-center whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-white h-11 rounded-md px-8 bg-purple-600 hover:bg-purple-700 gap-2">
                    Our Services 
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                  </button>
                </Link>
                <Link to="/contact">
                  <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-neutral-700 bg-transparent hover:bg-neutral-800 text-white h-11 rounded-md px-8">
                    Contact Us
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-12 bg-neutral-900 border-y border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
              <AnimatedStat end={10} suffix="+" label="Years Experience" />
              <AnimatedStat end={500} suffix="K+" label="Meters Produced" />
              <AnimatedStat end={20} suffix="+" label="EPC Projects" />
              <AnimatedStat end={100} suffix="+" label="Skilled Engineers" />
            </div>
          </div>
        </section>

        {/* Meter Types Section */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Energy Meter Types</h2>
              <p className="text-neutral-400">We manufacture a range of certified electricity meters to meet diverse needs</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-purple-600/50 transition-colors text-center group">
                <div className="w-16 h-16 bg-purple-600/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-600/20 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-8 h-8 text-purple-600"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Single Phase Prepaid</h3>
                <p className="text-neutral-400 text-sm">For residential use</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-purple-600/50 transition-colors text-center group">
                <div className="w-16 h-16 bg-purple-600/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-600/20 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-8 h-8 text-purple-600"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Three Phase Prepaid</h3>
                <p className="text-neutral-400 text-sm">For commercial use</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-purple-600/50 transition-colors text-center group">
                <div className="w-16 h-16 bg-purple-600/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-600/20 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-settings w-8 h-8 text-purple-600"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Smart Meters</h3>
                <p className="text-neutral-400 text-sm">With remote monitoring</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-purple-600/50 transition-colors text-center group">
                <div className="w-16 h-16 bg-purple-600/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-600/20 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-award w-8 h-8 text-purple-600"><path d="m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526"></path><circle cx="12" cy="8" r="6"></circle></svg>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">STS Certified</h3>
                <p className="text-neutral-400 text-sm">Industry standard</p>
              </div>
            </div>
          </div>
        </section>

        {/* Services Summary Section */}
        <section className="py-20 bg-neutral-900/30">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Our Services</h2>
              <p className="text-neutral-400">Complete metering and EPC solutions for the power sector</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-neutral-900 rounded-xl p-8 border border-neutral-800 hover:border-purple-600/50 transition-colors group">
                <div className="w-12 h-12 bg-purple-600/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-purple-600/20 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-6 h-6 text-purple-600"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>
                </div>
                <h3 className="text-xl font-display font-semibold text-white mb-3">Prepaid Meter Assembly</h3>
                <p className="text-neutral-400">Manufacturing high-quality prepaid electricity meters for residential and commercial use.</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-8 border border-neutral-800 hover:border-purple-600/50 transition-colors group">
                <div className="w-12 h-12 bg-purple-600/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-purple-600/20 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-settings w-6 h-6 text-purple-600"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                </div>
                <h3 className="text-xl font-display font-semibold text-white mb-3">Smart Meter Production</h3>
                <p className="text-neutral-400">Advanced smart metering solutions with remote monitoring and data analytics capabilities.</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-8 border border-neutral-800 hover:border-purple-600/50 transition-colors group">
                <div className="w-12 h-12 bg-purple-600/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-purple-600/20 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-building2 w-6 h-6 text-purple-600"><path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"></path><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"></path><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"></path><path d="M10 6h4"></path><path d="M10 10h4"></path><path d="M10 14h4"></path><path d="M10 18h4"></path></svg>
                </div>
                <h3 className="text-xl font-display font-semibold text-white mb-3">EPC Services</h3>
                <p className="text-neutral-400">Engineering, Procurement, and Construction services for power infrastructure projects.</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-8 border border-neutral-800 hover:border-purple-600/50 transition-colors group">
                <div className="w-12 h-12 bg-purple-600/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-purple-600/20 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-award w-6 h-6 text-purple-600"><path d="m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526"></path><circle cx="12" cy="8" r="6"></circle></svg>
                </div>
                <h3 className="text-xl font-display font-semibold text-white mb-3">Meter Installation & Support</h3>
                <p className="text-neutral-400">End-to-end installation services and ongoing technical support for all meter types.</p>
              </div>
            </div>
            
            <div className="text-center mt-12">
              <Link to="/subsidiaries/engineering/services">
                <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 text-white h-10 px-8 py-2 bg-purple-600 hover:bg-purple-700 gap-2">
                  View All Services 
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                </button>
              </Link>
            </div>
          </div>
        </section>

        {/* Permits & Accreditations */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Permits & Accreditations</h2>
              <p className="text-neutral-400">Our facilities and products are certified by relevant local and international bodies.</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-neutral-900 rounded-xl p-6 border border-purple-600/20 text-center hover:bg-purple-600/5 transition-colors">
                <div className="w-16 h-16 bg-purple-600/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-award w-8 h-8 text-purple-600"><path d="m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526"></path><circle cx="12" cy="8" r="6"></circle></svg>
                </div>
                <h3 className="text-xl font-display font-bold text-white mb-2">STS</h3>
                <p className="text-neutral-400 text-sm">Standard Transfer Specification Certified</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-6 border border-purple-600/20 text-center hover:bg-purple-600/5 transition-colors">
                <div className="w-16 h-16 bg-purple-600/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-award w-8 h-8 text-purple-600"><path d="m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526"></path><circle cx="12" cy="8" r="6"></circle></svg>
                </div>
                <h3 className="text-xl font-display font-bold text-white mb-2">NEMSA</h3>
                <p className="text-neutral-400 text-sm">Nigerian Electricity Management Services Agency Approved</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-6 border border-purple-600/20 text-center hover:bg-purple-600/5 transition-colors">
                <div className="w-16 h-16 bg-purple-600/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-award w-8 h-8 text-purple-600"><path d="m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526"></path><circle cx="12" cy="8" r="6"></circle></svg>
                </div>
                <h3 className="text-xl font-display font-bold text-white mb-2">SON</h3>
                <p className="text-neutral-400 text-sm">Standards Organisation of Nigeria Certified</p>
              </div>
              <div className="bg-neutral-900 rounded-xl p-6 border border-purple-600/20 text-center hover:bg-purple-600/5 transition-colors">
                <div className="w-16 h-16 bg-purple-600/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-award w-8 h-8 text-purple-600"><path d="m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526"></path><circle cx="12" cy="8" r="6"></circle></svg>
                </div>
                <h3 className="text-xl font-display font-bold text-white mb-2">ISO 9001:2015</h3>
                <p className="text-neutral-400 text-sm">Quality Management System Certified</p>
              </div>
            </div>
          </div>
        </section>

        {/* Clients Marquee */}
        <section className="py-20 overflow-hidden">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Our Clients</h2>
              <p className="text-neutral-400">We serve major distribution and generation companies across Nigeria.</p>
            </div>
          </div>
          <div className="relative overflow-hidden py-4 w-full">
            <div className="flex animate-marquee whitespace-nowrap items-center">
              {/* Note: Using logo placeholders as I don't have direct URLs for these specific clients, consistent with instruction to use logos only. */}
              {[...Array(10)].map((_, i) => (
                <div key={i} className="mx-8 flex-shrink-0 grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all duration-500">
                   <div className="w-40 h-20 bg-neutral-900 border border-neutral-800 rounded-lg flex items-center justify-center">
                      <span className="text-purple-600 font-bold text-xl">CLIENT {i + 1}</span>
                   </div>
                </div>
              ))}
              {/* Duplicate for infinite scroll */}
              {[...Array(10)].map((_, i) => (
                <div key={`dup-${i}`} className="mx-8 flex-shrink-0 grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all duration-500">
                   <div className="w-40 h-20 bg-neutral-900 border border-neutral-800 rounded-lg flex items-center justify-center">
                      <span className="text-purple-600 font-bold text-xl">CLIENT {i + 1}</span>
                   </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Partners Marquee */}
        <section id="partners" className="py-20 bg-neutral-900/30 overflow-hidden">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Our Partners</h2>
              <p className="text-neutral-400">We collaborate with leading organizations in the metering and power sector</p>
            </div>
          </div>
          <div className="relative overflow-hidden py-4 w-full">
            <div className="flex animate-marquee-reverse whitespace-nowrap items-center">
              {partners.map((logo, i) => (
                <div key={i} className="mx-12 w-48 h-24 flex items-center justify-center flex-shrink-0 grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all duration-500">
                  <img src={logo} alt="Partner Logo" className="max-w-full max-h-full object-contain" />
                </div>
              ))}
              {partners.map((logo, i) => (
                <div key={`dup-${i}`} className="mx-12 w-48 h-24 flex items-center justify-center flex-shrink-0 grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all duration-500">
                  <img src={logo} alt="Partner Logo" className="max-w-full max-h-full object-contain" />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-neutral-900 border-t border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="bg-gradient-to-r from-purple-600/10 to-purple-900/5 rounded-2xl p-12 text-center border border-purple-600/20">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Partner With Us</h2>
              <p className="text-neutral-400 max-w-2xl mx-auto mb-8">
                Looking for reliable metering solutions or EPC services? Let us help you power your projects with quality engineering and manufacturing excellence.
              </p>
              <Link to="/contact">
                <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 text-white h-11 rounded-md px-8 bg-purple-600 hover:bg-purple-700">
                  Get In Touch
                </button>
              </Link>
            </div>
          </div>
        </section>
      </main>

      <EngineeringFooter />
    </div>
  );
};

export default Engineering;
