
import React, { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import Header from '../../components/Header';
import Footer from '../../components/Footer';

const AnimatedStat = ({ end, label, suffix = '', prefix = '' }: { end: number, label: string, suffix?: string, prefix?: string }) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          const duration = 2000;
          const start = 0;
          const startTime = performance.now();

          const animate = (currentTime: number) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const easeOut = 1 - Math.pow(1 - progress, 3);
            
            setCount(Math.floor(start + (end - start) * easeOut));

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setCount(end);
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [end]);

  return (
    <div ref={ref} className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-red-600/50 transition-colors group text-center">
      <div className="text-4xl font-display font-bold text-white mb-2 tabular-nums group-hover:text-red-600 transition-colors">
        {prefix}{count}{suffix}
      </div>
      <div className="text-neutral-400 text-sm uppercase tracking-wider font-medium">{label}</div>
    </div>
  );
};

const Heliohm: React.FC = () => {
  // Using logos only as requested
  const partners = [
    'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Google_2015_logo.svg/2560px-Google_2015_logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/2560px-Amazon_logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/IBM_logo.svg/2560px-IBM_logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Tata_Consultancy_Services_Logo.svg/2560px-Tata_Consultancy_Services_Logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Cisco_logo_blue_2016.svg/2560px-Cisco_logo_blue_2016.svg.png'
  ];

  return (
    <div className="bg-black text-white font-sans min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-20">
        {/* Hero Section */}
        <section className="relative py-24 lg:py-32 overflow-hidden">
          <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1558449033-543634fa1654?q=80&w=2070&auto=format&fit=crop")' }}></div>
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/90 to-black/60"></div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl">
              <div className="inline-flex items-center gap-2 bg-red-600/10 text-red-500 px-4 py-2 rounded-full text-sm font-medium mb-6 border border-red-600/30">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-4 h-4"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>
                Premium Power Conversion
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold text-white mb-6">
                <span className="text-red-600">Heliohm</span> Inverters
              </h1>
              <p className="text-lg md:text-xl text-neutral-300 leading-relaxed mb-8">
                The heartbeat of your power system. Heliohm specializes exclusively in high-performance pure sine wave inverters designed to provide stable, uninterrupted power for homes and businesses.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <a href="https://heliohm.com" target="_blank" rel="noopener noreferrer">
                  <button className="inline-flex items-center justify-center whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-white h-12 rounded-md px-8 bg-red-600 hover:bg-red-700 gap-2 shadow-lg shadow-red-900/20">
                    Visit Heliohm Website
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-external-link w-4 h-4"><path d="M15 3h6v6"></path><path d="M10 14 21 3"></path><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path></svg>
                  </button>
                </a>
                <Link to="/contact">
                  <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-neutral-600 bg-transparent hover:bg-neutral-800 text-white h-12 rounded-md px-8">
                    Contact Us
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Overview Section */}
        <section className="py-20 bg-black border-y border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-6">
                  Intelligent <span className="text-red-600">Inverter</span> Technology
                </h2>
                <p className="text-neutral-400 leading-relaxed mb-6">
                  Heliohm stands as a beacon of innovation in power conversion. We design and distribute cutting-edge hybrid and off-grid inverters tailored for the rugged demands of the African power grid.
                </p>
                <p className="text-neutral-400 leading-relaxed mb-8">
                  Our inverters are engineered to deliver clean, pure sine wave power, ensuring the safety of sensitive electronics while maximizing energy efficiency from both grid and battery sources.
                </p>
                
                <div className="grid grid-cols-2 gap-6">
                   <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-red-600/10 flex items-center justify-center mt-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-activity w-4 h-4 text-red-600"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                      </div>
                      <div>
                        <h4 className="text-white font-bold">Pure Sine Wave</h4>
                        <p className="text-sm text-neutral-500">Clean power for all appliances</p>
                      </div>
                   </div>
                   <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-red-600/10 flex items-center justify-center mt-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-4 h-4 text-red-600"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>
                      </div>
                      <div>
                        <h4 className="text-white font-bold">Smart Charging</h4>
                        <p className="text-sm text-neutral-500">Optimized battery life</p>
                      </div>
                   </div>
                   <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-red-600/10 flex items-center justify-center mt-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-shield w-4 h-4 text-red-600"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path></svg>
                      </div>
                      <div>
                        <h4 className="text-white font-bold">Overload Protection</h4>
                        <p className="text-sm text-neutral-500">Built-in safety mechanisms</p>
                      </div>
                   </div>
                   <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-red-600/10 flex items-center justify-center mt-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-monitor-smartphone w-4 h-4 text-red-600"><path d="M18 8V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h8"/><path d="M10 19v-3.96 3.15"/><path d="M7 21h10"/><rect width="6" height="10" x="16" y="12" rx="2"/></svg>
                      </div>
                      <div>
                        <h4 className="text-white font-bold">LCD Display</h4>
                        <p className="text-sm text-neutral-500">Real-time status monitoring</p>
                      </div>
                   </div>
                </div>
              </div>
              <div className="relative">
                 {/* Decorative Elements */}
                 <div className="absolute -top-4 -right-4 w-32 h-32 bg-red-600/10 rounded-full blur-xl"></div>
                 <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-white/5 rounded-full blur-xl"></div>
                 
                 <div className="relative rounded-2xl overflow-hidden border border-neutral-800 bg-neutral-900 aspect-square flex items-center justify-center group">
                    <img src="https://images.unsplash.com/photo-1559302504-64aae6ca6b6f?q=80&w=1964&auto=format&fit=crop" alt="Solar Inverter Technology" className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity duration-700" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
                    <div className="absolute bottom-8 left-8">
                       <div className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-bold inline-block mb-2">HELIOHM SERIES X</div>
                       <p className="text-white text-lg font-medium">Smart Hybrid Inverter</p>
                    </div>
                 </div>
              </div>
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="py-12 bg-neutral-900">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <AnimatedStat end={98} suffix="%" label="Efficiency" />
              <AnimatedStat end={5} suffix="yr" label="Warranty" />
              <AnimatedStat end={24} suffix="h" label="Run Time" />
              <AnimatedStat end={100} suffix="+" label="Distributors" />
            </div>
          </div>
        </section>

        {/* Product Series Grid */}
        <section className="py-24 bg-neutral-900/30">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Inverter Series</h2>
              <p className="text-neutral-400">Choose the right capacity for your energy needs.</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              {/* Card 1 */}
              <div className="group bg-black p-8 rounded-xl border border-neutral-800 hover:border-red-600/50 transition-colors relative overflow-hidden flex flex-col items-center text-center">
                <div className="w-24 h-24 bg-neutral-900 rounded-lg flex items-center justify-center mb-6 text-white group-hover:text-red-600 transition-colors border border-neutral-800">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-cpu w-10 h-10"><rect width="16" height="16" x="4" y="4" rx="2"/><rect width="6" height="6" x="9" y="9" rx="1"/><path d="M15 2v2"/><path d="M15 20v2"/><path d="M2 15h2"/><path d="M2 9h2"/><path d="M20 15h2"/><path d="M20 9h2"/><path d="M9 2v2"/><path d="M9 20v2"/></svg>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Compact Series</h3>
                <p className="text-red-600 font-medium mb-4">1kVA - 3kVA</p>
                <p className="text-neutral-400 text-sm leading-relaxed mb-6">
                  Ideal for small homes and home offices. Supports essential appliances like fans, TVs, and lighting with silent operation.
                </p>
                <a href="https://heliohm.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-white text-sm font-medium hover:text-red-600 transition-colors mt-auto">
                  View Specs <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4 ml-1"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                </a>
              </div>

              {/* Card 2 */}
              <div className="group bg-black p-8 rounded-xl border border-neutral-800 hover:border-red-600/50 transition-colors relative overflow-hidden flex flex-col items-center text-center">
                <div className="absolute top-0 right-0 w-16 h-16 bg-red-600/10 rounded-bl-full"></div>
                <div className="w-24 h-24 bg-neutral-900 rounded-lg flex items-center justify-center mb-6 text-white group-hover:text-red-600 transition-colors border border-neutral-800">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-10 h-10"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Pro Series</h3>
                <p className="text-red-600 font-medium mb-4">5kVA - 10kVA</p>
                <p className="text-neutral-400 text-sm leading-relaxed mb-6">
                  Robust power for large homes and offices. Capable of running freezers, pumps, and air conditioners effortlessly.
                </p>
                <a href="https://heliohm.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-white text-sm font-medium hover:text-red-600 transition-colors mt-auto">
                  View Specs <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4 ml-1"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                </a>
              </div>

              {/* Card 3 */}
              <div className="group bg-black p-8 rounded-xl border border-neutral-800 hover:border-red-600/50 transition-colors relative overflow-hidden flex flex-col items-center text-center">
                <div className="w-24 h-24 bg-neutral-900 rounded-lg flex items-center justify-center mb-6 text-white group-hover:text-red-600 transition-colors border border-neutral-800">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-factory w-10 h-10"><path d="M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8l-7 5V8l-7 5V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"></path><path d="M17 18h1"></path><path d="M12 18h1"></path><path d="M7 18h1"></path></svg>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Industrial Series</h3>
                <p className="text-red-600 font-medium mb-4">20kVA - 100kVA+</p>
                <p className="text-neutral-400 text-sm leading-relaxed mb-6">
                  Heavy-duty 3-phase inverters for industrial complexes, estates, and commercial hubs requiring constant uptime.
                </p>
                <a href="https://heliohm.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-white text-sm font-medium hover:text-red-600 transition-colors mt-auto">
                  View Specs <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4 ml-1"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* Partners Marquee */}
        <section className="py-20 bg-black overflow-hidden">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Technology Partners</h2>
              <p className="text-neutral-400">Powered by world-class components.</p>
            </div>
          </div>
          <div className="relative overflow-hidden py-4 w-full">
            <div className="flex animate-marquee whitespace-nowrap items-center">
              {partners.map((logo, i) => (
                <div key={i} className="mx-12 w-48 h-24 flex items-center justify-center flex-shrink-0 grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all duration-500">
                  <img src={logo} alt="Partner Logo" className="max-w-full max-h-full object-contain" />
                </div>
              ))}
              {partners.map((logo, i) => (
                <div key={`dup-${i}`} className="mx-12 w-48 h-24 flex items-center justify-center flex-shrink-0 grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all duration-500">
                  <img src={logo} alt="Partner Logo" className="max-w-full max-h-full object-contain" />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24">
          <div className="container mx-auto px-4">
            <div className="bg-gradient-to-r from-red-900/20 to-neutral-900 rounded-2xl p-12 text-center border border-red-900/30">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Power Your Life with Heliohm</h2>
              <p className="text-neutral-400 max-w-2xl mx-auto mb-10">
                Explore our full range of inverter products and find authorized distributors near you on our official website.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-6">
                <a href="https://heliohm.com" target="_blank" rel="noopener noreferrer">
                  <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-base font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 text-white h-14 rounded-full px-10 bg-red-600 hover:bg-red-700 shadow-xl shadow-red-900/20">
                    Go to Heliohm Website
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-external-link w-5 h-5"><path d="M15 3h6v6"></path><path d="M10 14 21 3"></path><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path></svg>
                  </button>
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Heliohm;
