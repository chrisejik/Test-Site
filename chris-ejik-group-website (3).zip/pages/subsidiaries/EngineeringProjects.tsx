
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import EngineeringHeader from '../../components/EngineeringHeader';
import EngineeringFooter from '../../components/EngineeringFooter';

const projects = [
  {
    id: 1,
    title: "MAP Meter Rollout",
    category: "Metering",
    description: "Large scale deployment of prepaid meters under the Meter Asset Provider scheme.",
    client: "Eko Electricity Distribution Company",
    location: "Lagos",
    year: "2023",
    highlights: ["50,000+ meters installed", "Reduced ATC&C losses", "Enhanced revenue collection"],
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-gauge w-16 h-16 text-neutral-600 group-hover:text-white transition-colors"><path d="m12 14 4-4"></path><path d="M3.34 19a10 10 0 1 1 17.32 0"></path></svg>
    )
  },
  {
    id: 2,
    title: "National Mass Metering Program",
    category: "Metering",
    description: "Supply and installation of smart meters for the Federal Government's NMMP initiative.",
    client: "Federal Government of Nigeria",
    location: "Nationwide",
    year: "2022",
    highlights: ["100,000+ units supplied", "Local content compliant", "Timely delivery"],
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-16 h-16 text-neutral-600 group-hover:text-white transition-colors"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>
    )
  },
  {
    id: 3,
    title: "Distribution Network Upgrade",
    category: "EPC",
    description: "Rehabilitation of 33KV and 11KV distribution lines to improve power supply reliability.",
    client: "Ikeja Electric",
    location: "Lagos",
    year: "2023",
    highlights: ["50km of lines upgraded", "New transformers installed", "Reduced downtime"],
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-construction w-16 h-16 text-neutral-600 group-hover:text-white transition-colors"><rect x="2" y="6" width="20" height="8" rx="1"></rect><path d="M17 14v7"></path><path d="M7 14v7"></path><path d="M17 3v3"></path><path d="M7 3v3"></path><path d="M10 14 2.3 6.3"></path><path d="m14 6 7.7 7.7"></path><path d="m8 6 8 8"></path></svg>
    )
  },
  {
    id: 4,
    title: "Feeder Pillar Manufacturing",
    category: "Manufacturing",
    description: "Production and supply of 500 units of 800A Feeder Pillars for distribution substations.",
    client: "Multiple DisCos",
    location: "Various Locations",
    year: "2023",
    highlights: ["Custom specifications", "Durable construction", "Safety compliant"],
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-factory w-16 h-16 text-neutral-600 group-hover:text-white transition-colors"><path d="M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8l-7 5V8l-7 5V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"></path><path d="M17 18h1"></path><path d="M12 18h1"></path><path d="M7 18h1"></path></svg>
    )
  },
  {
    id: 5,
    title: "Rural Electrification Scheme",
    category: "EPC",
    description: "Electrification of 10 rural communities using solar mini-grid solutions.",
    client: "REA (Rural Electrification Agency)",
    location: "North Central",
    year: "2022",
    highlights: ["2000+ homes connected", "Sustainable power source", "Community impact"],
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-lightbulb w-16 h-16 text-neutral-600 group-hover:text-white transition-colors"><path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-1 1.5-2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"></path><path d="M9 18h6"></path><path d="M10 22h4"></path></svg>
    )
  }
];

const categories = ["All", "Metering", "EPC", "Manufacturing"];

const EngineeringProjects: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredProjects = activeCategory === "All" 
    ? projects 
    : projects.filter(project => project.category === activeCategory);

  return (
    <div className="bg-black text-white font-sans min-h-screen flex flex-col">
      <EngineeringHeader />
      
      <main className="flex-grow pt-20">
        {/* Hero Section */}
        <section className="relative py-16 lg:py-24 overflow-hidden">
          <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1581092335397-9583eb92d232?q=80&w=2070&auto=format&fit=crop")' }}></div>
          <div className="absolute inset-0 bg-black/80"></div>
          <div className="container mx-auto px-4 relative z-10">
            <Link className="inline-flex items-center gap-2 text-neutral-400 hover:text-white mb-8 transition-colors text-sm" to="/subsidiaries/engineering">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-left w-4 h-4"><path d="m12 19-7-7 7-7"></path><path d="M19 12H5"></path></svg>
              Back to Overview
            </Link>
            <div className="max-w-3xl">
              <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-6">
                Our <span className="text-purple-500">Projects</span>
              </h1>
              <p className="text-lg text-neutral-400 leading-relaxed">
                Explore our portfolio of completed projects showcasing our expertise in metering, power infrastructure, and manufacturing.
              </p>
            </div>
          </div>
        </section>

        {/* Filter Section */}
        <section className="py-8 border-y border-neutral-800 bg-neutral-900/30 sticky top-20 z-40 backdrop-blur-md">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap gap-3">
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors border ${
                    activeCategory === category
                      ? 'bg-purple-600 text-white border-purple-600'
                      : 'bg-neutral-900 border-neutral-700 text-neutral-400 hover:text-white hover:border-purple-500'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Projects Grid */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProjects.map((project) => (
                <div key={project.id} className="bg-neutral-900 rounded-xl border border-neutral-800 hover:border-purple-600/50 transition-all overflow-hidden group hover:shadow-xl duration-300">
                  <div className="aspect-video bg-gradient-to-br from-neutral-800 to-neutral-900 flex items-center justify-center relative overflow-hidden">
                    <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
                    <div className="relative z-10 transform group-hover:scale-110 transition-transform duration-500">
                      {project.icon}
                    </div>
                  </div>
                  <div className="p-6">
                    <span className="inline-block bg-purple-600/10 text-purple-400 text-xs px-2 py-1 rounded-full mb-3 border border-purple-600/20">
                      {project.category}
                    </span>
                    <h3 className="text-xl font-display font-semibold text-white mb-2 group-hover:text-purple-400 transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-neutral-400 text-sm mb-4">
                      {project.description}
                    </p>
                    
                    <div className="flex flex-wrap gap-4 text-sm text-neutral-500 mb-6">
                      <span className="flex items-center gap-1.5">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-building2 w-3.5 h-3.5"><path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"></path><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"></path><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"></path><path d="M10 6h4"></path><path d="M10 10h4"></path><path d="M10 14h4"></path><path d="M10 18h4"></path></svg> 
                        {project.client}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-map-pin w-3.5 h-3.5"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"></path><circle cx="12" cy="10" r="3"></circle></svg> 
                        {project.location}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-calendar w-3.5 h-3.5"><path d="M8 2v4"></path><path d="M16 2v4"></path><rect width="18" height="18" x="3" y="4" rx="2"></rect><path d="M3 10h18"></path></svg> 
                        {project.year}
                      </span>
                    </div>

                    <div className="border-t border-neutral-800 pt-4">
                      <p className="text-xs text-neutral-500 uppercase tracking-wider mb-2 font-medium">Key Highlights</p>
                      <ul className="space-y-1.5">
                        {project.highlights.map((highlight, i) => (
                          <li key={i} className="text-sm text-neutral-300 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 bg-purple-500 rounded-full"></span>
                            {highlight}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-neutral-900 border-t border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="bg-gradient-to-r from-purple-600/10 to-purple-900/5 rounded-2xl p-12 text-center border border-purple-600/20">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Start Your Project With Us</h2>
              <p className="text-neutral-400 max-w-2xl mx-auto mb-8">
                Ready to deliver your next metering or power infrastructure project? Contact our engineering team today.
              </p>
              <div className="flex justify-center">
                <Link to="/contact">
                  <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-white h-11 rounded-md px-8 bg-purple-600 hover:bg-purple-700 w-full sm:w-auto">
                    Contact Our Team
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <EngineeringFooter />
    </div>
  );
};

export default EngineeringProjects;
