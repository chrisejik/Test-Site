
import React, { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import Header from '../../components/Header';
import Footer from '../../components/Footer';

const AnimatedStat = ({ end, label, suffix = '', prefix = '' }: { end: number, label: string, suffix?: string, prefix?: string }) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          const duration = 2000;
          const start = 0;
          const startTime = performance.now();

          const animate = (currentTime: number) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const easeOut = 1 - Math.pow(1 - progress, 3);
            
            setCount(Math.floor(start + (end - start) * easeOut));

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setCount(end);
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [end]);

  return (
    <div ref={ref} className="bg-[#146bb5]/5 rounded-xl p-6 border border-[#146bb5]/20 hover:border-[#e64e0f]/50 transition-colors group">
      <div className="text-4xl font-display font-bold text-[#146bb5] mb-1 tabular-nums group-hover:text-[#e64e0f] transition-colors">
        {prefix}{count}{suffix}
      </div>
      <div className="text-neutral-400 text-sm uppercase tracking-wider">{label}</div>
    </div>
  );
};

const CEEnergy: React.FC = () => {
  // Using logos only as requested
  const partners = [
    'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/2560px-Amazon_logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Google_2015_logo.svg/2560px-Google_2015_logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/IBM_logo.svg/2560px-IBM_logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Tata_Consultancy_Services_Logo.svg/2560px-Tata_Consultancy_Services_Logo.svg.png',
    'https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Cisco_logo_blue_2016.svg/2560px-Cisco_logo_blue_2016.svg.png'
  ];

  return (
    <div className="bg-black text-white font-sans min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-20">
        {/* Hero Section */}
        <section className="relative py-24 lg:py-32 overflow-hidden">
          <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?q=80&w=2070&auto=format&fit=crop")' }}></div>
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-black/40"></div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl">
              <div className="inline-flex items-center gap-2 bg-[#146bb5]/10 text-[#146bb5] px-4 py-2 rounded-full text-sm font-medium mb-6 border border-[#146bb5]/30">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-4 h-4"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>
                Sustainable Power Solutions
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold text-white mb-6">
                <span className="text-[#e64e0f]">CE</span>-<span className="text-[#146bb5]">Energy</span>
              </h1>
              <p className="text-lg md:text-xl text-neutral-300 leading-relaxed mb-8">
                CE-Energy is a dynamic energy company committed to addressing Africa's power deficit through reliable generation, transmission, and distribution solutions. We combine technical expertise with strategic partnerships to light up communities and power industries.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <a href="https://ce-energy.com" target="_blank" rel="noopener noreferrer">
                  <button className="inline-flex items-center justify-center whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-white h-12 rounded-md px-8 bg-[#146bb5] hover:bg-[#0f5290] gap-2 shadow-lg shadow-[#146bb5]/20">
                    Visit Official Website
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-external-link w-4 h-4"><path d="M15 3h6v6"></path><path d="M10 14 21 3"></path><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path></svg>
                  </button>
                </a>
                <Link to="/contact">
                  <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-neutral-600 bg-transparent hover:bg-neutral-800 text-white h-12 rounded-md px-8">
                    Contact Us
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Overview Section */}
        <section className="py-20 bg-neutral-900 border-y border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-16 items-center">
              <div className="relative">
                 <div className="absolute top-0 left-0 w-20 h-20 border-t-2 border-l-2 border-[#e64e0f] rounded-tl-3xl -translate-x-4 -translate-y-4"></div>
                 <div className="absolute bottom-0 right-0 w-20 h-20 border-b-2 border-r-2 border-[#146bb5] rounded-br-3xl translate-x-4 translate-y-4"></div>
                 <div className="rounded-2xl overflow-hidden grayscale hover:grayscale-0 transition-all duration-700">
                    <img src="https://images.unsplash.com/photo-1466611653911-95081537e5b7?q=80&w=2070&auto=format&fit=crop" alt="Wind Turbines" className="w-full h-full object-cover" />
                 </div>
              </div>
              <div>
                <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-6">
                  Driving <span className="text-[#146bb5]">Energy</span> Security
                </h2>
                <p className="text-neutral-400 leading-relaxed mb-6">
                  Africa's economic potential is closely tied to its energy security. CE-Energy was established to bridge the gap between demand and supply by investing in diverse energy sources, from conventional power generation to renewable energy integration.
                </p>
                <p className="text-neutral-400 leading-relaxed mb-8">
                  We work with governments, utility companies, and private enterprises to design, build, and operate efficient power systems. Our holistic approach ensures that every project we undertake contributes to a more sustainable and electrified future.
                </p>
                
                <div className="flex gap-8">
                   <div>
                      <span className="block text-3xl font-bold text-[#e64e0f] mb-1">10+</span>
                      <span className="text-sm text-neutral-500 uppercase tracking-wider">Years Active</span>
                   </div>
                   <div>
                      <span className="block text-3xl font-bold text-[#146bb5] mb-1">100+</span>
                      <span className="text-sm text-neutral-500 uppercase tracking-wider">MW Capacity</span>
                   </div>
                   <div>
                      <span className="block text-3xl font-bold text-white mb-1">24/7</span>
                      <span className="text-sm text-neutral-500 uppercase tracking-wider">Support</span>
                   </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Solutions Grid */}
        <section className="py-24 bg-black">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Our Core Solutions</h2>
              <p className="text-neutral-400">Delivering excellence across the energy value chain.</p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Card 1 */}
              <div className="group bg-neutral-900 p-8 rounded-xl border border-neutral-800 hover:border-[#146bb5]/50 transition-colors relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-[#146bb5]/5 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
                <div className="w-12 h-12 bg-[#146bb5]/10 rounded-lg flex items-center justify-center mb-6 text-[#146bb5] group-hover:text-[#e64e0f] transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-factory w-6 h-6"><path d="M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8l-7 5V8l-7 5V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"></path><path d="M17 18h1"></path><path d="M12 18h1"></path><path d="M7 18h1"></path></svg>
                </div>
                <h3 className="text-xl font-bold text-white mb-3">Power Generation</h3>
                <p className="text-neutral-400 text-sm leading-relaxed mb-6">
                  Development and operation of power plants utilizing thermal and renewable energy sources to feed into the national grid.
                </p>
                <a href="https://ce-energy.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-[#146bb5] text-sm font-medium hover:text-[#e64e0f] transition-colors">
                  Explore Generation <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4 ml-1"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                </a>
              </div>

              {/* Card 2 */}
              <div className="group bg-neutral-900 p-8 rounded-xl border border-neutral-800 hover:border-[#146bb5]/50 transition-colors relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-[#146bb5]/5 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
                <div className="w-12 h-12 bg-[#146bb5]/10 rounded-lg flex items-center justify-center mb-6 text-[#146bb5] group-hover:text-[#e64e0f] transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-6 h-6"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>
                </div>
                <h3 className="text-xl font-bold text-white mb-3">Transmission & Distribution</h3>
                <p className="text-neutral-400 text-sm leading-relaxed mb-6">
                  Upgrading and maintaining grid infrastructure to ensure efficient power delivery with minimal losses.
                </p>
                <a href="https://ce-energy.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-[#146bb5] text-sm font-medium hover:text-[#e64e0f] transition-colors">
                  View Capabilities <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4 ml-1"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                </a>
              </div>

              {/* Card 3 */}
              <div className="group bg-neutral-900 p-8 rounded-xl border border-neutral-800 hover:border-[#146bb5]/50 transition-colors relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-[#146bb5]/5 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
                <div className="w-12 h-12 bg-[#146bb5]/10 rounded-lg flex items-center justify-center mb-6 text-[#146bb5] group-hover:text-[#e64e0f] transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-sun w-6 h-6"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2"></path><path d="M12 20v2"></path><path d="m4.93 4.93 1.41 1.41"></path><path d="m17.66 17.66 1.41 1.41"></path><path d="M2 12h2"></path><path d="M20 12h2"></path><path d="m6.34 17.66-1.41 1.41"></path><path d="m19.07 4.93-1.41 1.41"></path></svg>
                </div>
                <h3 className="text-xl font-bold text-white mb-3">Renewable Integration</h3>
                <p className="text-neutral-400 text-sm leading-relaxed mb-6">
                  Implementing sustainable energy solutions including solar farms and hybrid systems to reduce carbon footprint.
                </p>
                <a href="https://ce-energy.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-[#146bb5] text-sm font-medium hover:text-[#e64e0f] transition-colors">
                  See Renewables <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right w-4 h-4 ml-1"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* Partners Marquee */}
        <section className="py-20 bg-neutral-900/30 overflow-hidden">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Strategic Partners</h2>
              <p className="text-neutral-400">Collaborating with global leaders to deliver world-class energy infrastructure.</p>
            </div>
          </div>
          <div className="relative overflow-hidden py-4 w-full">
            <div className="flex animate-marquee whitespace-nowrap items-center">
              {partners.map((logo, i) => (
                <div key={i} className="mx-12 w-48 h-24 flex items-center justify-center flex-shrink-0 grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all duration-500">
                  <img src={logo} alt="Partner Logo" className="max-w-full max-h-full object-contain" />
                </div>
              ))}
              {partners.map((logo, i) => (
                <div key={`dup-${i}`} className="mx-12 w-48 h-24 flex items-center justify-center flex-shrink-0 grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all duration-500">
                  <img src={logo} alt="Partner Logo" className="max-w-full max-h-full object-contain" />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24">
          <div className="container mx-auto px-4">
            <div className="bg-gradient-to-r from-[#146bb5]/20 to-[#e64e0f]/10 rounded-2xl p-12 text-center border border-[#146bb5]/30">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Discover More About CE-Energy</h2>
              <p className="text-neutral-400 max-w-2xl mx-auto mb-10">
                Visit our dedicated website to explore our projects, technical capabilities, and how we are powering the continent.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-6">
                <a href="https://ce-energy.com" target="_blank" rel="noopener noreferrer">
                  <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-base font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 text-white h-14 rounded-full px-10 bg-[#146bb5] hover:bg-[#0f5290] shadow-xl shadow-[#146bb5]/20">
                    Go to CE-Energy Website
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-external-link w-5 h-5"><path d="M15 3h6v6"></path><path d="M10 14 21 3"></path><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path></svg>
                  </button>
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default CEEnergy;
