
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import InternationalHeader from '../../components/InternationalHeader';
import InternationalFooter from '../../components/InternationalFooter';

const projects = [
  {
    id: 1,
    title: "330KV Transmission Line Construction",
    category: "Transmission Lines",
    description: "Construction of 120km 330KV transmission line connecting major industrial zones.",
    client: "TCN (Transmission Company of Nigeria)",
    location: "Lagos - Ogun State",
    year: "2022",
    highlights: ["120km line construction", "45 steel towers erected", "Completed ahead of schedule"],
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-16 h-16 text-neutral-600 group-hover:text-white transition-colors"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>
    )
  },
  {
    id: 2,
    title: "132KV Substation Installation",
    category: "Substations",
    description: "Complete installation and commissioning of a 132/33KV substation.",
    client: "NDPHC",
    location: "Anambra State",
    year: "2021",
    highlights: ["2x60MVA transformers", "Full protection systems", "SCADA integration"],
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-building2 w-16 h-16 text-neutral-600 group-hover:text-white transition-colors"><path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"></path><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"></path><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"></path><path d="M10 6h4"></path><path d="M10 10h4"></path><path d="M10 14h4"></path><path d="M10 18h4"></path></svg>
    )
  },
  {
    id: 3,
    title: "Distribution Transformer Supply",
    category: "Transformer Sales",
    description: "Supply and installation of 200 distribution transformers across service area.",
    client: "Ikeja Electric",
    location: "Lagos State",
    year: "2023",
    highlights: ["200 transformers supplied", "Installation completed", "Maintenance training provided"],
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-16 h-16 text-neutral-600 group-hover:text-white transition-colors"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>
    )
  },
  {
    id: 4,
    title: "Substation Preventive Maintenance",
    category: "Maintenance",
    description: "Comprehensive preventive maintenance program for 15 substations.",
    client: "EEDC",
    location: "South-East Region",
    year: "2023",
    highlights: ["15 substations serviced", "Equipment lifespan extended", "Downtime reduced by 40%"],
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-wrench w-16 h-16 text-neutral-600 group-hover:text-white transition-colors"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path></svg>
    )
  },
  {
    id: 5,
    title: "33KV Feeder Pillar Manufacturing",
    category: "Manufacturing",
    description: "Manufacturing and supply of over 500 feeder pillars for distribution networks.",
    client: "Multiple DisCos",
    location: "Nationwide",
    year: "2022",
    highlights: ["500+ units manufactured", "SON certified", "Custom specifications"],
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-box w-16 h-16 text-neutral-600 group-hover:text-white transition-colors"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" x2="12" y1="22.08" y2="12"></line></svg>
    )
  },
  {
    id: 6,
    title: "Rural Electrification Project",
    category: "EPC Projects",
    description: "Complete electrification of 25 rural communities including substations and distribution.",
    client: "State Government",
    location: "Enugu State",
    year: "2021",
    highlights: ["25 communities electrified", "50,000+ beneficiaries", "Sustainable power supply"],
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-lightbulb w-16 h-16 text-neutral-600 group-hover:text-white transition-colors"><path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-1 1.5-2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"></path><path d="M9 18h6"></path><path d="M10 22h4"></path></svg>
    )
  }
];

const categories = ["All", "EPC Projects", "Transmission Lines", "Substations", "Transformer Sales", "Maintenance", "Manufacturing"];

const InternationalProjects: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredProjects = activeCategory === "All" 
    ? projects 
    : projects.filter(project => project.category === activeCategory);

  return (
    <div className="bg-black text-white font-sans min-h-screen flex flex-col">
      <InternationalHeader />
      
      <main className="flex-grow pt-20">
        {/* Hero Section */}
        <section className="relative py-16 lg:py-24 overflow-hidden">
          <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1590959651367-692f36f055ce?q=80&w=2070&auto=format&fit=crop")' }}></div>
          <div className="absolute inset-0 bg-black/80"></div>
          <div className="container mx-auto px-4 relative z-10">
            <Link className="inline-flex items-center gap-2 text-neutral-400 hover:text-white mb-8 transition-colors text-sm" to="/subsidiaries/international">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-left w-4 h-4"><path d="m12 19-7-7 7-7"></path><path d="M19 12H5"></path></svg>
              Back to Overview
            </Link>
            <div className="max-w-3xl">
              <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-6">
                Our <span className="text-neutral-400">Projects</span>
              </h1>
              <p className="text-lg text-neutral-400 leading-relaxed">
                Explore our portfolio of completed projects showcasing our expertise in power infrastructure development. Each project represents our commitment to excellence and our clients' trust in our capabilities.
              </p>
            </div>
          </div>
        </section>

        {/* Filter Section */}
        <section className="py-8 border-y border-neutral-800 bg-neutral-900/30 sticky top-20 z-40 backdrop-blur-md">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap gap-3">
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors border ${
                    activeCategory === category
                      ? 'bg-white text-black border-white'
                      : 'bg-neutral-900 border-neutral-700 text-neutral-400 hover:text-white hover:border-neutral-500'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Projects Grid */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProjects.map((project) => (
                <div key={project.id} className="bg-neutral-900 rounded-xl border border-neutral-800 hover:border-neutral-600 transition-all overflow-hidden group hover:shadow-xl duration-300">
                  <div className="aspect-video bg-gradient-to-br from-neutral-800 to-neutral-900 flex items-center justify-center relative overflow-hidden">
                    <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
                    <div className="relative z-10 transform group-hover:scale-110 transition-transform duration-500">
                      {project.icon}
                    </div>
                  </div>
                  <div className="p-6">
                    <span className="inline-block bg-neutral-800 text-neutral-300 text-xs px-2 py-1 rounded-full mb-3 border border-neutral-700">
                      {project.category}
                    </span>
                    <h3 className="text-xl font-display font-semibold text-white mb-2 group-hover:text-neutral-300 transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-neutral-400 text-sm mb-4">
                      {project.description}
                    </p>
                    
                    <div className="flex flex-wrap gap-4 text-sm text-neutral-500 mb-6">
                      <span className="flex items-center gap-1.5">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-building2 w-3.5 h-3.5"><path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"></path><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"></path><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"></path><path d="M10 6h4"></path><path d="M10 10h4"></path><path d="M10 14h4"></path><path d="M10 18h4"></path></svg> 
                        {project.client}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-map-pin w-3.5 h-3.5"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"></path><circle cx="12" cy="10" r="3"></circle></svg> 
                        {project.location}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-calendar w-3.5 h-3.5"><path d="M8 2v4"></path><path d="M16 2v4"></path><rect width="18" height="18" x="3" y="4" rx="2"></rect><path d="M3 10h18"></path></svg> 
                        {project.year}
                      </span>
                    </div>

                    <div className="border-t border-neutral-800 pt-4">
                      <p className="text-xs text-neutral-500 uppercase tracking-wider mb-2 font-medium">Key Highlights</p>
                      <ul className="space-y-1.5">
                        {project.highlights.map((highlight, i) => (
                          <li key={i} className="text-sm text-neutral-300 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 bg-neutral-500 rounded-full"></span>
                            {highlight}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-neutral-900 border-t border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="bg-gradient-to-r from-neutral-800 to-neutral-900 rounded-2xl p-12 text-center border border-neutral-700">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Start Your Project With Us</h2>
              <p className="text-neutral-400 max-w-2xl mx-auto mb-8">
                Ready to join our portfolio of successful projects? Contact us today to discuss your power infrastructure needs.
              </p>
              <div className="flex justify-center">
                <Link to="/contact">
                  <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-black h-11 rounded-md px-8 bg-white hover:bg-neutral-200 w-full sm:w-auto">
                    Contact Our Team
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <InternationalFooter />
    </div>
  );
};

export default InternationalProjects;
