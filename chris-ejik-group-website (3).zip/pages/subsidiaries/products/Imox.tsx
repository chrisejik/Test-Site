
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import PharmaceuticalsHeader from '../../../components/PharmaceuticalsHeader';
import PharmaceuticalsFooter from '../../../components/PharmaceuticalsFooter';

const productImages = [
  {
    url: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=800",
    alt: "Imox Pack Front",
    label: "Front View"
  },
  {
    url: "https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2?auto=format&fit=crop&q=80&w=800",
    alt: "Imox Blister Pack",
    label: "Blister Pack"
  },
  {
    url: "https://images.unsplash.com/photo-1550572017-edd951aa8f72?auto=format&fit=crop&q=80&w=800",
    alt: "Imox Capsule Close-up",
    label: "Capsule View"
  },
   {
    url: "https://images.unsplash.com/photo-1471864190281-a93a3070b6de?auto=format&fit=crop&q=80&w=800",
    alt: "Imox 10x10 Variant Box",
    label: "10x10 Variant"
  }
];

const Imox: React.FC = () => {
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  return (
    <div className="bg-black text-white font-sans min-h-screen flex flex-col">
      <PharmaceuticalsHeader />
      
      <main className="flex-grow pt-20">
        {/* Hero Section */}
        <section className="relative py-16 lg:py-24 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 to-transparent pointer-events-none"></div>
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
          
          <div className="container mx-auto px-4 relative z-10">
            <Link className="inline-flex items-center gap-2 text-neutral-400 hover:text-white mb-8 transition-colors text-sm" to="/subsidiaries/pharmaceuticals/products">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-left w-4 h-4"><path d="m12 19-7-7 7-7"></path><path d="M19 12H5"></path></svg>
              Back to Products
            </Link>
            
            <div className="grid lg:grid-cols-2 gap-12 items-start">
              <div>
                <span className="inline-block bg-blue-900/30 text-blue-400 text-sm px-3 py-1 rounded-full mb-4 border border-blue-900/30 font-medium">Prescription Drug</span>
                <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-4">Imox®</h1>
                <p className="text-xl text-blue-500 mb-6 font-medium">Amoxicillin 500mg Capsules</p>
                <p className="text-neutral-400 leading-relaxed mb-8 text-lg">
                  Each capsule contains Amoxicillin Trihydrate equivalent to Amoxicillin 500mg. A widely used broad-spectrum antibiotic for treating various bacterial infections. Well absorbed orally with excellent bioavailability.
                </p>
                
                <div className="bg-blue-900/10 rounded-xl p-4 border border-blue-900/30 flex items-start gap-3 mb-8">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-circle-alert w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0"><circle cx="12" cy="12" r="10"></circle><line x1="12" x2="12" y1="8" y2="12"></line><line x1="12" x2="12.01" y1="16" y2="16"></line></svg>
                  <div>
                    <p className="text-white font-medium">Prescription Required</p>
                    <p className="text-neutral-400 text-sm">This medication requires a valid prescription from a licensed healthcare provider.</p>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col gap-4">
                {/* Main Active Image */}
                <div className="bg-neutral-900 rounded-2xl border border-neutral-800 p-2 flex items-center justify-center aspect-square relative overflow-hidden group">
                   <div className="absolute inset-0 bg-blue-900/5 group-hover:bg-blue-900/10 transition-colors duration-500 z-10 pointer-events-none"></div>
                   <img 
                     src={productImages[activeImageIndex].url} 
                     alt={productImages[activeImageIndex].alt} 
                     className="w-full h-full object-cover rounded-xl transition-transform duration-500 group-hover:scale-105"
                   />
                </div>

                {/* Thumbnails Gallery */}
                <div className="grid grid-cols-4 gap-4">
                  {productImages.map((image, index) => (
                    <button
                      key={index}
                      onClick={() => setActiveImageIndex(index)}
                      className={`relative aspect-square rounded-xl overflow-hidden border transition-all duration-300 ${
                        activeImageIndex === index 
                          ? 'border-blue-600 ring-2 ring-blue-600/20 opacity-100' 
                          : 'border-neutral-800 opacity-60 hover:opacity-100 hover:border-blue-600/50'
                      }`}
                      aria-label={`View ${image.label}`}
                    >
                      <img 
                        src={image.url} 
                        alt={image.label} 
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Details Section */}
        <section className="py-16 bg-neutral-900/30 border-y border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-8">
              {/* Composition */}
              <div className="bg-neutral-900 rounded-xl p-8 border border-neutral-800 hover:border-blue-600/30 transition-colors">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-blue-900/20 rounded-lg flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-file-text w-5 h-5 text-blue-500"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path><path d="M14 2v4a2 2 0 0 0 2 2h4"></path><path d="M10 9H8"></path><path d="M16 13H8"></path><path d="M16 17H8"></path></svg>
                  </div>
                  <h2 className="text-xl font-display font-semibold text-white">Composition</h2>
                </div>
                <div className="space-y-6">
                  <div>
                    <p className="text-neutral-500 text-xs uppercase tracking-wider mb-2 font-medium">Active Ingredient</p>
                    <p className="text-white text-lg">Amoxicillin Trihydrate equivalent to Amoxicillin 500mg</p>
                  </div>
                  <div className="h-px bg-neutral-800 w-full"></div>
                  <div>
                    <p className="text-neutral-500 text-xs uppercase tracking-wider mb-2 font-medium">Excipients</p>
                    <p className="text-white">Colour Titanium Dioxide B.q.s.</p>
                  </div>
                </div>
              </div>

              {/* Indications */}
              <div className="bg-neutral-900 rounded-xl p-8 border border-neutral-800 hover:border-blue-600/30 transition-colors">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-blue-900/20 rounded-lg flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-pill w-5 h-5 text-blue-500"><path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"></path><path d="m8.5 8.5 7 7"></path></svg>
                  </div>
                  <h2 className="text-xl font-display font-semibold text-white">Indications</h2>
                </div>
                <ul className="grid sm:grid-cols-2 gap-4">
                  {[
                    "Upper respiratory tract infections",
                    "Lower respiratory tract infections",
                    "Urinary tract infections",
                    "Skin and soft tissue infections",
                    "Dental infections",
                    "H. pylori eradication"
                  ].map((item, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-circle-check-big w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0"><path d="M21.801 10A10 10 0 1 1 17 3.335"></path><path d="m9 11 3 3L22 4"></path></svg>
                      <span className="text-neutral-300">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Variants Section */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-display font-bold text-white mb-8 flex items-center gap-3">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-package w-6 h-6 text-blue-500"><path d="M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z"></path><path d="M12 22V12"></path><path d="m3.3 7 7.703 4.734a2 2 0 0 0 1.994 0L20.7 7"></path><path d="m7.5 4.27 9 5.15"></path></svg>
              Available Variants
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-blue-600/30 transition-colors group">
                <div className="flex justify-between items-start mb-4">
                  <div className="w-12 h-12 bg-blue-900/20 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-beaker w-6 h-6 text-blue-500"><path d="M4.5 3h15"></path><path d="M6 3v16a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V3"></path><path d="M6 14h12"></path></svg>
                  </div>
                  <span className="text-xs font-medium bg-neutral-800 text-neutral-400 px-2 py-1 rounded">SKU: IMX-TROP</span>
                </div>
                <h3 className="text-lg font-display font-semibold text-white mb-1 group-hover:text-blue-500 transition-colors">Imox Tropical</h3>
                <p className="text-neutral-400 text-sm mb-4">Amoxicillin 500mg Capsules</p>
                <div className="pt-4 border-t border-neutral-800">
                  <p className="text-blue-400 text-sm font-medium">Tropical pack presentation</p>
                </div>
              </div>

              <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-blue-600/30 transition-colors group">
                <div className="flex justify-between items-start mb-4">
                  <div className="w-12 h-12 bg-blue-900/20 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-beaker w-6 h-6 text-blue-500"><path d="M4.5 3h15"></path><path d="M6 3v16a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V3"></path><path d="M6 14h12"></path></svg>
                  </div>
                  <span className="text-xs font-medium bg-neutral-800 text-neutral-400 px-2 py-1 rounded">SKU: IMX-10X10</span>
                </div>
                <h3 className="text-lg font-display font-semibold text-white mb-1 group-hover:text-blue-500 transition-colors">Imox 10 x 10</h3>
                <p className="text-neutral-400 text-sm mb-4">Amoxicillin 500mg Capsules</p>
                <div className="pt-4 border-t border-neutral-800">
                  <p className="text-blue-400 text-sm font-medium">Pack of 100 capsules (10 strips x 10 capsules)</p>
                </div>
              </div>

              <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800 hover:border-blue-600/30 transition-colors group">
                <div className="flex justify-between items-start mb-4">
                  <div className="w-12 h-12 bg-blue-900/20 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-beaker w-6 h-6 text-blue-500"><path d="M4.5 3h15"></path><path d="M6 3v16a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V3"></path><path d="M6 14h12"></path></svg>
                  </div>
                  <span className="text-xs font-medium bg-neutral-800 text-neutral-400 px-2 py-1 rounded">SKU: IMX-1X21</span>
                </div>
                <h3 className="text-lg font-display font-semibold text-white mb-1 group-hover:text-blue-500 transition-colors">Imox 1 x 21</h3>
                <p className="text-neutral-400 text-sm mb-4">Amoxicillin 500mg Capsules</p>
                <div className="pt-4 border-t border-neutral-800">
                  <p className="text-blue-400 text-sm font-medium">Pack of 21 capsules (1 strip x 21 capsules)</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-neutral-900/30 border-t border-neutral-800">
          <div className="container mx-auto px-4">
            <div className="bg-gradient-to-r from-blue-900/20 to-blue-600/5 rounded-2xl p-12 text-center border border-blue-900/30">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Interested in Imox®?</h2>
              <p className="text-neutral-400 max-w-2xl mx-auto mb-8">Contact us for product availability, pricing, and distribution information.</p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Link to="/contact">
                  <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-white h-11 rounded-md px-8 bg-blue-600 hover:bg-blue-700 w-full sm:w-auto">
                    Contact Sales Team
                  </button>
                </Link>
                <Link to="/subsidiaries/pharmaceuticals/products">
                  <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-neutral-700 bg-transparent hover:bg-neutral-800 text-white h-11 rounded-md px-8 w-full sm:w-auto">
                    View All Products
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <PharmaceuticalsFooter />
    </div>
  );
};

export default Imox;
